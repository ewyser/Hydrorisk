# -*- coding: utf-8 -*-
"""
Lightweight SSE (Server-Sent Events) reader for the Hydrorisk API.
Uses only stdlib http.client — no external dependencies required.
"""
import http.client
import urllib.parse
import json
import threading


class SseThread(threading.Thread):
    """Background daemon thread that reads a ``text/event-stream`` response.

    Parameters
    ----------
    url : str
        Full URL of the SSE endpoint (``http`` or ``https``).
    token : str
        Bearer token inserted in the ``Authorization`` header.
    on_event : callable(dict)
        Called in this thread for each dispatched SSE ``data:`` event.
        The argument is the JSON-decoded payload dict.
        **Must not block** — signal to the Qt UI thread instead.
    on_done : callable()
        Called when the stream ends cleanly (server closed or terminal state).
    on_error : callable(Exception), optional
        Called when the connection fails before any terminal event.
        If omitted, ``on_done`` is invoked instead.
    """

    def __init__(self, url: str, token: str, on_event, on_done, on_error=None):
        super().__init__(daemon=True, name="HydroriskSseThread")
        self._url      = url
        self._token    = token
        self._on_event = on_event
        self._on_done  = on_done
        self._on_error = on_error or (lambda _exc: on_done())
        self._stop_evt = threading.Event()
        self._conn     = None

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def stop(self):
        """Signal the thread to stop and close the underlying connection."""
        self._stop_evt.set()
        conn, self._conn = self._conn, None
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def run(self):
        try:
            self._read_stream()
        except Exception as exc:
            if not self._stop_evt.is_set():
                self._on_error(exc)

    def _read_stream(self):
        parsed  = urllib.parse.urlparse(self._url)
        host    = parsed.hostname
        port    = parsed.port
        path    = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"

        ConnClass = (http.client.HTTPSConnection
                     if parsed.scheme == "https"
                     else http.client.HTTPConnection)

        # Socket timeout must be longer than the server's poll interval (~2 s)
        # but short enough to detect dead connections in reasonable time.
        self._conn = ConnClass(host, port, timeout=10)
        self._conn.request(
            "GET",
            path,
            headers={
                "Accept":        "text/event-stream",
                "Cache-Control": "no-cache",
                "Authorization": f"Bearer {self._token}",
            },
        )
        resp = self._conn.getresponse()

        if resp.status != 200:
            body = resp.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"SSE endpoint returned HTTP {resp.status}: {body}")

        ct = resp.getheader("Content-Type", "")
        if "text/event-stream" not in ct:
            body = resp.read().decode("utf-8", errors="replace")
            raise RuntimeError(
                f"Expected text/event-stream, got {ct!r}. "
                f"Server may not support SSE. Response: {body[:200]}"
            )

        pending_data: str = None

        while not self._stop_evt.is_set():
            try:
                raw = resp.readline()
            except (OSError, EOFError, TimeoutError):
                break
            if not raw:
                break  # server closed the connection

            line = raw.decode("utf-8").rstrip("\r\n")

            if line.startswith("data:"):
                pending_data = line[5:].lstrip(" ")
            elif line.startswith("event:") or line.startswith(":"):
                pass  # ignore event-type fields and SSE comments / heartbeats
            elif line == "":
                # Blank line = event separator
                if pending_data is not None:
                    try:
                        self._on_event(json.loads(pending_data))
                    except Exception:
                        pass
                    pending_data = None

        if not self._stop_evt.is_set():
            self._on_done()

# -*- coding: utf-8 -*-
"""
HrJobMonitorDialog — standalone dialog that lists all jobs owned by the
authenticated user and displays their live status and per-task progress.

OsmotiC.jl drives execution autonomously (it polls the DB for "submitted"
jobs).  This dialog is read-only with respect to execution — no "launch"
or "run" button is present.  The only write action available is deleting
a job.

Update strategy
---------------
On open, a single SSE stream is opened on ``GET /jobs/stream``.  The server
polls ``db_list_jobs`` and pushes the full job list on any change.
If the SSE connection fails, a QTimer fallback polls ``list_jobs()`` every
``_POLL_FALLBACK_MS`` milliseconds instead.

Layout
------
  ┌─ Existing job ──────────────────────────────────────────────────────┐
  │  Filter: [text]  [status ▾]  [🔄]                                   │
  │  Job:    [combo ▾]                                [🗑 Delete job]    │
  │  Status: <icon+summary>      Created at: <ts>                       │
  └─────────────────────────────────────────────────────────────────────┘
  ┌─ Tasks ─────────────────────────────────────────────────────────────┐
  │  prepare:  [░░░░░░░░░]  step  status                                │
  │  execute:  [░░░░░░░░░]  step  status                                │
  │  post:     [░░░░░░░░░]  step  status                                │
  └─────────────────────────────────────────────────────────────────────┘
  ┌─ Error ─────────────────────────────────────────────────────────────┐
  │  <err_msg>  (shown only when the selected job's status is "failed") │
  └─────────────────────────────────────────────────────────────────────┘
  [ ● live  /  ⟳ polling ]                              [ Close ]
"""

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QDialogButtonBox, QMessageBox,
)
from qgis.PyQt.QtCore import QTimer, pyqtSignal

from .groupboxes.existing_job_groupbox import HrExistingJobGroupBox
from .groupboxes.progress_groupbox import HrProgressGroupBox
from .groupboxes.error_groupbox import HrErrorGroupBox
from ..common.connection_store import make_client as _make_client

_POLL_FALLBACK_MS = 5_000   # used only when SSE is unavailable


class HrJobMonitorDialog(QDialog):
    """
    Lists all user jobs and shows per-task progress for the selected job.
    Driven by a persistent SSE stream (``GET /jobs/stream``); falls back to
    QTimer polling if the stream is unavailable.
    """

    # Relay SSE callbacks from the background thread into the GUI thread.
    _sig_sse_event = pyqtSignal(object)   # carries the decoded jobs list
    _sig_sse_done  = pyqtSignal()
    _sig_sse_error = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hydrorisk — Job Monitor")
        self.setMinimumSize(660, 540)

        # ── State ──────────────────────────────────────────────────────
        self._jobs              = []
        self._filtered          = []
        self._stages            = []
        self._task_icons        = {}
        self._terminal_statuses = set()
        self._active_statuses   = set()
        self._sse_thread        = None

        # ── Fallback timer (SSE unavailable) ───────────────────────────
        self._timer = QTimer(self)
        self._timer.setInterval(_POLL_FALLBACK_MS)
        self._timer.timeout.connect(self._poll_fallback)

        # ── SSE signals ────────────────────────────────────────────────
        self._sig_sse_event.connect(self._on_sse_event)
        self._sig_sse_done.connect(self._on_sse_done)
        self._sig_sse_error.connect(self._on_sse_error)

        # ── Layout ─────────────────────────────────────────────────────
        root = QVBoxLayout(self)

        # Job picker group (filter + combo + info labels)
        job_group = HrExistingJobGroupBox(parent=self)
        self._filter_text   = job_group._filter_text
        self._filter_status = job_group._filter_status
        self._refresh_btn   = job_group._refresh_btn
        self._job_combo     = job_group._job_combo
        self._info_status   = job_group._info_status
        self._info_created  = job_group._info_created
        self._status_lbl    = job_group._status_lbl

        self._refresh_btn.clicked.connect(self._manual_refresh)
        self._filter_text.textChanged.connect(self._apply_filters)
        self._filter_status.currentIndexChanged.connect(self._apply_filters)
        self._job_combo.currentIndexChanged.connect(self._on_job_changed)

        root.addWidget(job_group)

        # Action buttons aligned to the right
        action_row = QHBoxLayout()
        self._resubmit_btn = QPushButton("↺  Resubmit job")
        self._resubmit_btn.setEnabled(False)
        self._resubmit_btn.clicked.connect(self._resubmit_selected_job)
        self._delete_btn = QPushButton("🗑  Delete job")
        self._delete_btn.setEnabled(False)
        self._delete_btn.clicked.connect(self._delete_selected_job)
        action_row.addStretch()
        action_row.addWidget(self._resubmit_btn)
        action_row.addWidget(self._delete_btn)
        root.addLayout(action_row)

        # Task progress group (rebuilt when stages change)
        self._progress_layout = QVBoxLayout()
        self._progress_layout.setContentsMargins(0, 0, 0, 0)
        self._progress_group  = None
        self._task_widgets    = {}
        self._rebuild_progress_groupbox(self._stages)
        root.addLayout(self._progress_layout)

        # Error group, below Tasks — not inserted into the layout until a
        # failed job is selected (see _show_error_box/_hide_error_box). A
        # widget that is merely .setVisible(False)'d while still sitting in
        # the layout can keep a stale zero-size geometry from before the
        # layout ever ran, which then renders its title on top of the next
        # group box's title once shown; inserting/removing it avoids that.
        self._root_layout   = root
        self._error_index   = root.count()
        self._error_group   = HrErrorGroupBox(parent=self)
        self._error_inlayout = False

        root.addStretch()

        # Bottom bar: live/fallback indicator + Close
        bottom_row = QHBoxLayout()
        self._conn_lbl = QLabel("Connecting…")
        self._conn_lbl.setStyleSheet("color: gray; font-size: 10px;")
        bottom_row.addWidget(self._conn_lbl)
        bottom_row.addStretch()
        close_box = QDialogButtonBox(QDialogButtonBox.Close)
        close_box.rejected.connect(self.reject)
        bottom_row.addWidget(close_box)
        root.addLayout(bottom_row)

    # ------------------------------------------------------------------
    # Qt lifecycle
    # ------------------------------------------------------------------

    def showEvent(self, event):
        super().showEvent(event)
        self._fetch_task_config()
        self._start_sse()

    def closeEvent(self, event):
        self._timer.stop()
        self._stop_sse()
        super().closeEvent(event)

    # ------------------------------------------------------------------
    # SSE stream (primary update mechanism)
    # ------------------------------------------------------------------

    def _start_sse(self):
        self._stop_sse()
        self._conn_lbl.setText("Connecting…")
        self._conn_lbl.setStyleSheet("color: gray; font-size: 10px;")
        client = _make_client()
        self._sse_thread = client.sse_jobs_stream(
            on_event=lambda data: self._sig_sse_event.emit(data),
            on_done=lambda: self._sig_sse_done.emit(),
            on_error=lambda exc: self._sig_sse_error.emit(str(exc)),
        )

    def _stop_sse(self):
        if self._sse_thread is not None:
            self._sse_thread.stop()
            self._sse_thread = None

    def _on_sse_event(self, jobs: list):
        """Full job list pushed by the server — ingest and refresh UI."""
        self._timer.stop()   # SSE is working; disable fallback timer
        self._conn_lbl.setText("● live")
        self._conn_lbl.setStyleSheet("color: green; font-size: 10px;")
        self._ingest_jobs(jobs)

    def _on_sse_done(self):
        """Stream ended cleanly (server closed) — reconnect."""
        self._sse_thread = None
        if self.isVisible():
            self._start_sse()

    def _on_sse_error(self, _err: str):
        """SSE unavailable — fall back to QTimer polling."""
        self._sse_thread = None
        self._conn_lbl.setText("⟳ polling")
        self._conn_lbl.setStyleSheet("color: orange; font-size: 10px;")
        if not self._timer.isActive():
            self._poll_fallback()       # immediate first poll
            self._timer.start()

    # ------------------------------------------------------------------
    # Fallback polling (QTimer, only when SSE is unavailable)
    # ------------------------------------------------------------------

    def _poll_fallback(self):
        try:
            jobs = _make_client().list_jobs()
            self._ingest_jobs(jobs)
        except Exception as exc:
            self._status_lbl.setText(f"❌  Could not load jobs: {exc}")
            self._status_lbl.setStyleSheet("color: red;")

    def _manual_refresh(self):
        """Refresh button — reconnect SSE (or force a poll in fallback mode)."""
        if self._timer.isActive():
            self._poll_fallback()
        else:
            self._start_sse()

    # ------------------------------------------------------------------
    # Task-config fetch (stages + icons)
    # ------------------------------------------------------------------

    def _fetch_task_config(self):
        try:
            config    = _make_client().task_config()
            stages    = config.get("stages") or []
            icons_raw = config.get("status_icons") or {}
            if stages:
                changed = stages != self._stages
                self._stages = stages
                if icons_raw:
                    self._task_icons = {
                        k: (v["icon"], v["color"]) for k, v in icons_raw.items()
                    }
                if changed:
                    self._rebuild_progress_groupbox(self._stages)
            terminal = config.get("terminal_statuses") or []
            active   = config.get("active_statuses")   or []
            if terminal:
                self._terminal_statuses = set(terminal)
            if active:
                self._active_statuses = set(active)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Error groupbox
    # ------------------------------------------------------------------

    def _show_error_box(self, message: str):
        if not self._error_inlayout:
            self._root_layout.insertWidget(self._error_index, self._error_group)
            self._error_inlayout = True
        self._error_group.show_error(message)
        # Inserting a widget into an already-shown dialog's layout does not
        # by itself grow the window — Qt would otherwise squeeze the other
        # group boxes down to fit the unchanged window height, which is what
        # caused the "Tasks" title to render inside the error box. Force a
        # relayout and let the dialog grow to fit the new content.
        self._root_layout.activate()
        self.adjustSize()

    def _hide_error_box(self):
        if self._error_inlayout:
            self._root_layout.removeWidget(self._error_group)
            self._error_inlayout = False
        self._error_group.clear_error()
        self._root_layout.activate()
        self.adjustSize()

    # ------------------------------------------------------------------
    # Progress groupbox
    # ------------------------------------------------------------------

    def _rebuild_progress_groupbox(self, stages: list):
        if self._progress_group is not None:
            self._progress_layout.removeWidget(self._progress_group)
            self._progress_group.deleteLater()
        self._progress_group = HrProgressGroupBox(stages, parent=self)
        self._task_widgets   = self._progress_group._task_widgets
        # Hide the abort buttons — this dialog is monitoring-only
        for w in self._task_widgets.values():
            w["abort"].setVisible(False)
            w["row"].setVisible(True)
        self._progress_layout.addWidget(self._progress_group)

    def _apply_tasks(self, job: dict):
        tasks_data = {t["name"]: t for t in (job.get("tasks") or []) if t.get("name")}
        for task_name, w in self._task_widgets.items():
            t       = tasks_data.get(task_name, {})
            pct     = t.get("percent") or 0.0
            step    = t.get("step")    or "—"
            tstatus = t.get("status")  or "unknown"
            if tstatus not in self._task_icons:
                tstatus = "unknown"
            w["bar"].setValue(int(pct))
            w["step"].setText(step)
            w["status"].setText(tstatus)
            c = self._task_icons.get(tstatus, self._task_icons.get("unknown", ("?", "gray")))[1]
            w["status"].setStyleSheet(f"color: {c}; font-weight: bold;")

    def _clear_tasks(self):
        for w in self._task_widgets.values():
            w["bar"].setValue(0)
            w["step"].setText("—")
            w["status"].setText("—")
            w["status"].setStyleSheet("color: gray; font-weight: bold;")

    # ------------------------------------------------------------------
    # Job list ingestion (shared by SSE handler and fallback poller)
    # ------------------------------------------------------------------

    def _ingest_jobs(self, jobs: list):
        """Update internal job list and refresh filter/combo, preserving selection."""
        idx = self._job_combo.currentIndex()
        keep_id = None
        if 0 <= idx < len(self._filtered):
            keep_id = self._filtered[idx].get("id_hash")

        self._jobs = jobs or []

        if not self._jobs:
            self._status_lbl.setText("No jobs found.")
            self._status_lbl.setStyleSheet("color: orange;")

        # Rebuild status filter
        seen = []
        for j in self._jobs:
            s = j.get("status") or ""
            if s and s not in seen:
                seen.append(s)
        self._filter_status.blockSignals(True)
        prev_status = self._filter_status.currentData()
        self._filter_status.clear()
        self._filter_status.addItem("All statuses", None)
        for s in seen:
            self._filter_status.addItem(s, s)
        restore = self._filter_status.findData(prev_status)
        self._filter_status.setCurrentIndex(max(restore, 0))
        self._filter_status.blockSignals(False)

        self._apply_filters(keep_id=keep_id)

    def _apply_filters(self, keep_id: str = None):
        text_filter   = self._filter_text.text().strip().lower()
        status_filter = self._filter_status.currentData()

        self._filtered = [
            j for j in self._jobs
            if (not text_filter or
                text_filter in (j.get("prefix") or "").lower() or
                text_filter in (j.get("id_hash") or "").lower())
            and (status_filter is None or j.get("status") == status_filter)
        ]

        self._job_combo.blockSignals(True)
        self._job_combo.clear()
        restore_idx = 0
        for i, j in enumerate(self._filtered):
            label  = j.get("prefix") or (j.get("id_hash") or "?")[:8]
            status = j.get("status") or ""
            self._job_combo.addItem(f"{label}  [{status}]")
            if keep_id and j.get("id_hash") == keep_id:
                restore_idx = i
        if not self._filtered:
            self._job_combo.addItem("— no matching jobs —")
        self._job_combo.blockSignals(False)

        total   = len(self._jobs)
        matched = len(self._filtered)
        self._status_lbl.setText(
            f"{matched} of {total} job(s)." if self._jobs else "No jobs found."
        )
        self._status_lbl.setStyleSheet("color: gray;" if matched else "color: orange;")

        if self._filtered:
            self._job_combo.setCurrentIndex(restore_idx)
            if restore_idx == 0:
                self._on_job_changed(0)
        else:
            self._on_job_changed(-1)

    # ------------------------------------------------------------------
    # Job selection
    # ------------------------------------------------------------------

    def _task_summary(self, tasks: list) -> str:
        task_status = {t["name"]: t.get("status") for t in (tasks or []) if t.get("name")}
        parts = []
        for name in self._stages:
            ts   = task_status.get(name)
            icon, colour = self._task_icons.get(ts or "unknown",
                                                self._task_icons.get("unknown", ("?", "gray")))
            parts.append(f"<span style='color:{colour}'>{icon} {name}</span>")
        return "&nbsp;&nbsp;".join(parts)

    def _on_job_changed(self, index):
        if 0 <= index < len(self._filtered):
            j       = self._filtered[index]
            status  = str(j.get("status") or "—")
            created = (j.get("created_at") or "—")[:19]
            colour  = self._task_icons.get(status,
                          self._task_icons.get("unknown", ("?", "gray")))[1]
            summary = self._task_summary(j.get("tasks"))
            self._info_status.setText(
                f"<span style='color:{colour}; font-weight:bold'>{status}</span>"
                f"&nbsp;&nbsp;{summary}"
            )
            self._info_status.setStyleSheet("")
            self._info_created.setText(created)
            self._resubmit_btn.setEnabled(True)
            self._delete_btn.setEnabled(True)
            self._apply_tasks(j)

            err_msg = j.get("err_msg") or ""
            if status == "failed" and err_msg:
                self._show_error_box(err_msg)
            else:
                self._hide_error_box()
        else:
            self._info_status.setText("—")
            self._info_status.setStyleSheet("color: gray;")
            self._info_created.setText("—")
            self._info_created.setStyleSheet("color: gray;")
            self._resubmit_btn.setEnabled(False)
            self._delete_btn.setEnabled(False)
            self._clear_tasks()
            self._hide_error_box()

    # ------------------------------------------------------------------
    # Resubmit
    # ------------------------------------------------------------------

    def _resubmit_selected_job(self):
        idx = self._job_combo.currentIndex()
        if idx < 0 or idx >= len(self._filtered):
            return
        job   = self._filtered[idx]
        label = job.get("prefix") or (job.get("id_hash") or "?")[:8]
        reply = QMessageBox.question(
            self, "Resubmit job",
            f"Resubmit job '{label}'?  Its status will be reset so OsmotiC picks it up again.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        try:
            _make_client().resubmit_job(job.get("id_hash", ""))
        except Exception as exc:
            self._status_lbl.setText(f"❌  {exc}")
            self._status_lbl.setStyleSheet("color: red;")
            return
        # The SSE stream will push the updated list automatically.
        # In fallback-polling mode do an immediate refresh.
        if self._timer.isActive():
            self._poll_fallback()

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    def _delete_selected_job(self):
        idx = self._job_combo.currentIndex()
        if idx < 0 or idx >= len(self._filtered):
            return
        job   = self._filtered[idx]
        label = job.get("prefix") or (job.get("id_hash") or "?")[:8]
        reply = QMessageBox.question(
            self, "Delete job",
            f"Delete job '{label}'? This cannot be undone.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        try:
            _make_client().delete_job(job.get("id_hash", ""))
        except Exception as exc:
            self._status_lbl.setText(f"❌  {exc}")
            self._status_lbl.setStyleSheet("color: red;")
            return
        # The SSE stream will push the updated list automatically.
        # In fallback-polling mode do an immediate refresh.
        if self._timer.isActive():
            self._poll_fallback()

# -*- coding: utf-8 -*-
"""
HrErrorGroupBox — read-only group box showing a failed job's error message.

Hidden by default; the owning dialog shows it (and sets its text) only when
the selected job's status is a failure and `err_msg` is non-empty.

Exposes:
    _text    QTextEdit
"""
from qgis.PyQt.QtWidgets import QGroupBox, QVBoxLayout, QTextEdit, QSizePolicy
from qgis.PyQt.QtGui import QFont


class HrErrorGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Error", parent)
        vbox = QVBoxLayout(self)

        self._text = QTextEdit()
        self._text.setReadOnly(True)
        self._text.setFont(QFont("Courier", 9))
        self._text.setStyleSheet(
            "QTextEdit { background-color: #fff0f0; color: #a00000; }"
        )
        self._text.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._text.setMaximumHeight(120)
        vbox.addWidget(self._text)

        self.setVisible(False)

    def show_error(self, message: str):
        self._text.setPlainText(message or "")
        self.setVisible(True)

    def clear_error(self):
        self._text.clear()
        self.setVisible(False)

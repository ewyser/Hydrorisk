# -*- coding: utf-8 -*-
"""
Simulation settings page for Hydrorisk wizards.

HrSimSettingsPage — scrollable solver + export fields page used by HrJobWizard.
Accepts a ``next_page`` constructor argument.
"""
import os
import json
from qgis.PyQt.QtWidgets import QWizardPage, QVBoxLayout, QLabel
from .groupboxes.solver_groupbox import HrSolverGroupBox
from .groupboxes.export_fields_groupbox import HrExportFieldsGroupBox
from ..common.connection_store import make_client as _make_client

_DEFAULTS_PATH = os.path.join(
    os.path.dirname(__file__), "..", "wizard", "cfg_wizard_defaults.json"
)
with open(_DEFAULTS_PATH, encoding="utf-8") as _f:
    _DEFAULTS = json.load(_f)

_DEFAULT_SAVE_GROUPS = set(_DEFAULTS["default_save_groups"])


# ─────────────────────────────────────────────────────────────────────────────
# Full version — Job Manager wizard
# ─────────────────────────────────────────────────────────────────────────────

class HrSimSettingsPage(QWizardPage):
    """
    Solver + export-fields page (full version).

    Requires the wizard to expose ``seed_config() -> dict`` for pre-fill;
    falls back to empty dict if the method is absent (safe to use standalone).

    Connection page is assumed to be page 0.
    """

    def __init__(self, parent=None, next_page=-1):
        super().__init__(parent)
        self._next_page = next_page
        self.setTitle("Simulation settings")
        self.setSubTitle("Set solver options and export fields.")

        outer = QVBoxLayout(self)

        # ── Solver ────────────────────────────────────────────────────────────
        solver_group      = HrSolverGroupBox(show_infilt=False, parent=self)
        self._threads     = solver_group._threads
        self._precision   = solver_group._precision
        self._riemann     = solver_group._riemann
        self._hydrostatic = solver_group._hydrostatic
        outer.addWidget(solver_group)

        # ── Export ────────────────────────────────────────────────────────────
        self._export_gb         = HrExportFieldsGroupBox(
            scrollable=True, default_save_groups=_DEFAULT_SAVE_GROUPS, parent=self
        )
        self._freq              = self._export_gb._freq
        self._save_checks       = self._export_gb._save_checks
        self._save_field_checks = self._export_gb._save_field_checks
        self._save_fields       = self._export_gb._save_fields
        outer.addWidget(self._export_gb, 1)

    def initializePage(self):
        try:
            self._save_fields = _make_client().db_export_catalog()
        except Exception:
            self._save_fields = {}

        seed = getattr(self.wizard(), "seed_config", lambda: {})()
        seed_save_groups = set(seed.get("general", {}).get("instr", {}).get("save", {}).get("what", []))
        seed_save_struct = (seed or {}).get("save", {})
        self._export_gb.load_fields(self._save_fields, seed_save_groups, seed_save_struct)
        # keep aliases in sync after load_fields rebuilds them
        self._save_checks       = self._export_gb._save_checks
        self._save_field_checks = self._export_gb._save_field_checks

        if seed:
            instr = seed.get("general", {}).get("instr", {})
            dtype = str(instr.get("dtype", ""))
            if dtype in ("32", "64"):
                self._precision.setCurrentText(dtype)
            riemann = instr.get("solver", {}).get("riemann", "")
            if riemann:
                idx = self._riemann.findText(riemann)
                if idx >= 0:
                    self._riemann.setCurrentIndex(idx)
            state = instr.get("solver", {}).get("state", "")
            if state:
                idx = self._hydrostatic.findText(state)
                if idx >= 0:
                    self._hydrostatic.setCurrentIndex(idx)
            tc = seed.get("general", {}).get("param", {}).get("tC")
            if tc is not None:
                self._freq.setValue(int(tc))

    def validatePage(self):
        return True

    def values(self):
        return {
            "threads":     self._threads.value(),
            "precision":   int(self._precision.currentText()),
            "riemann":     self._riemann.currentText(),
            "hydrostatic": self._hydrostatic.currentText(),
            "frequency":   self._freq.value(),
        }

    def selected_save_groups(self):
        return self._export_gb.selected_save_groups()

    def build_save_structure(self):
        return self._export_gb.build_save_structure()

    def save_what_list(self):
        return self._export_gb.save_what_list()

    def nextId(self):
        return self._next_page

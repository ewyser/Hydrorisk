# -*- coding: utf-8 -*-
"""
HrUploadDialog — modal dialog for uploading a dataset to the Hydrorisk DB.

Used by HrDataInputsPage (Job Manager) and any other page that needs
in-wizard file upload for a specific DB category.
"""
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton,
    QGroupBox, QProgressBar, QRadioButton, QButtonGroup,
    QFileDialog, QPlainTextEdit,
)
from qgis.PyQt.QtCore import QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont

from ..common.upload_worker import UploadWorker


class HrUploadDialog(QDialog):
    """Modal dialog for uploading a dataset to the server DB for a given category."""

    # Bridge signals: SSE thread → Qt main thread
    _log_line_received  = pyqtSignal(str)
    _sse_upload_complete = pyqtSignal()

    # Human-readable names for known extensions
    _EXT_LABELS = {
        "csv":     "CSV tables",
        "tif":     "GeoTIFF rasters",
        "tiff":    "GeoTIFF rasters",
        "h5":      "HDF5 files",
        "hdf5":    "HDF5 files",
        "shp":     "Shapefiles (auto-bundles sidecars)",
        "geojson": "GeoJSON",
    }

    def __init__(self, db_cat: str, cat_label: str, client, formats: list = None,
                 parent=None, folder_capable: bool = False):
        super().__init__(parent)
        self.setWindowTitle(f"Upload dataset — {cat_label}")
        self.setMinimumWidth(500)
        self._client          = client
        self._db_cat          = db_cat
        self._formats         = formats or []
        self._folder_capable  = folder_capable
        self._uploaded_table  = None
        self._local_file_path = None
        self._thread          = None
        self._worker          = None
        self._sse_thread      = None

        layout = QVBoxLayout(self)

        # ── Source type (file vs folder) ──────────────────────────────────
        if folder_capable:
            type_group  = QGroupBox("Source type")
            type_layout = QHBoxLayout(type_group)
            self._rb_file   = QRadioButton("File / Layer")
            self._rb_folder = QRadioButton("Folder  (multiband raster)")
            self._rb_file.setChecked(True)
            self._type_btn_group = QButtonGroup(self)
            self._type_btn_group.addButton(self._rb_file,   0)
            self._type_btn_group.addButton(self._rb_folder, 1)
            type_layout.addWidget(self._rb_file)
            type_layout.addWidget(self._rb_folder)
            type_layout.addStretch()
            layout.addWidget(type_group)
            self._type_btn_group.idToggled.connect(self._on_type_toggled)
        else:
            self._rb_file   = None
            self._rb_folder = None

        # ── Local file ────────────────────────────────────────────────────
        self._local_group = QGroupBox("Local file")
        local_layout = QHBoxLayout(self._local_group)
        self._local_path_label = QLabel("No file selected.")
        self._local_path_label.setWordWrap(True)
        self._browse_btn = QPushButton("Browse…")
        self._browse_btn.setFixedWidth(80)
        local_layout.addWidget(self._local_path_label, 1)
        local_layout.addWidget(self._browse_btn)
        layout.addWidget(self._local_group)

        # ── Status + progress ─────────────────────────────────────────────
        self._status_label = QLabel("")
        self._status_label.setWordWrap(True)
        layout.addWidget(self._status_label)

        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setVisible(False)
        layout.addWidget(self._progress_bar)

        # ── Live import log ───────────────────────────────────────────────
        self._log_pane = QPlainTextEdit()
        self._log_pane.setReadOnly(True)
        self._log_pane.setVisible(False)
        self._log_pane.setMinimumHeight(140)
        mono = QFont("Monospace")
        mono.setStyleHint(QFont.Monospace)
        self._log_pane.setFont(mono)
        layout.addWidget(self._log_pane)

        # ── Buttons ───────────────────────────────────────────────────────
        btn_layout = QHBoxLayout()
        self._upload_btn = QPushButton("Upload")
        self._close_btn  = QPushButton("Close")
        btn_layout.addStretch()
        btn_layout.addWidget(self._upload_btn)
        btn_layout.addWidget(self._close_btn)
        layout.addLayout(btn_layout)

        # ── Connections ───────────────────────────────────────────────────
        self._browse_btn.clicked.connect(self._browse)
        self._upload_btn.clicked.connect(self._do_upload)
        self._close_btn.clicked.connect(self.reject)
        self._log_line_received.connect(self._append_log_line)
        self._sse_upload_complete.connect(self._on_sse_complete)

    # ------------------------------------------------------------------
    # Helpers

    def _is_folder_mode(self) -> bool:
        return self._rb_folder is not None and self._rb_folder.isChecked()

    def _on_type_toggled(self, btn_id, checked):
        if not checked:
            return
        folder = btn_id == 1
        label = "No folder selected." if folder else "No file selected."
        self._local_path_label.setText(label)
        self._local_file_path = None
        btn_text = "Browse folder…" if folder else "Browse…"
        self._browse_btn.setText(btn_text)

    def _browse(self):
        if self._is_folder_mode():
            path = QFileDialog.getExistingDirectory(
                self, "Select folder to upload", "",
                QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
            )
            if path:
                self._local_file_path = path
                self._local_path_label.setText(path)
        else:
            parts = []
            for ext in self._formats:
                label = self._EXT_LABELS.get(ext.lower(), f"{ext.upper()} files")
                parts.append(f"{label} (*.{ext.lower()})")
            if len(parts) > 1:
                combined = "Supported formats (" + " ".join(f"*.{e.lower()}" for e in self._formats) + ")"
                filter_str = combined + ";;" + ";;".join(parts) + ";;All files (*)"
            elif parts:
                filter_str = parts[0] + ";;All files (*)"
            else:
                filter_str = "All files (*)"
            path, _ = QFileDialog.getOpenFileName(self, "Select file", "", filter_str)
            if path:
                self._local_file_path = path
                self._local_path_label.setText(path)

    def _do_upload(self):
        if not self._local_file_path:
            noun = "folder" if self._is_folder_mode() else "file"
            self._status_label.setText(f"❌  Please select a {noun} first.")
            self._status_label.setStyleSheet("color: red;")
            return

        self._upload_btn.setEnabled(False)
        self._close_btn.setEnabled(False)
        self._progress_bar.setValue(0)
        self._progress_bar.setVisible(True)
        self._status_label.setText("Uploading…")
        self._status_label.setStyleSheet("color: orange;")

        self._thread = QThread(self)
        self._worker = UploadWorker(
            self._client,
            self._local_file_path,
            self._db_cat,
            folder_mode=self._is_folder_mode(),
        )
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.upload_started.connect(self._on_upload_started)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_upload_done)
        self._worker.error.connect(self._on_upload_error)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._thread.finished.connect(self._worker.deleteLater)
        self._thread.start()

    def _on_upload_started(self, upload_id: str):
        """Called as soon as upload_id is known — start SSE log stream immediately."""
        self._log_pane.setVisible(True)
        self._log_pane.clear()
        self._status_label.setText("Transferring file…")
        try:
            self._sse_thread = self._client.sse_upload_logs(
                upload_id,
                on_event=lambda ev: self._log_line_received.emit(
                    f"[{ev.get('level','info').upper()}] {ev.get('msg','')}"),
                on_done=self._on_sse_done,
                on_error=lambda exc: self._log_line_received.emit(f"[SSE ERROR] {exc}"),
            )
        except Exception as exc:
            self._log_line_received.emit(f"[SSE] Could not start log stream: {exc}")

    def _append_log_line(self, line: str):
        self._log_pane.appendPlainText(line)
        self._log_pane.verticalScrollBar().setValue(
            self._log_pane.verticalScrollBar().maximum())

    def _on_sse_done(self):
        self._log_line_received.emit("[SSE] Stream closed.")
        self._sse_upload_complete.emit()

    def _on_progress(self, sent: int, total: int):
        if total > 0:
            pct = int(sent * 100 / total)
            self._progress_bar.setValue(pct)
            kb_sent  = sent  // 1024
            kb_total = total // 1024
            label = f"Transferring… {pct}%  ({kb_sent} / {kb_total} KB)"
            if pct == 100:
                label = "Importing on server…"
            self._status_label.setText(label)

    def _on_upload_done(self, result: dict):
        # 202 — file transferred; server is processing asynchronously.
        # SSE will fire _on_sse_complete when the import finishes.
        self._progress_bar.setValue(100)
        self._status_label.setText("Importing on server…")
        self._status_label.setStyleSheet("color: orange;")

    def _on_sse_complete(self):
        self._status_label.setText("✅  Import complete.")
        self._status_label.setStyleSheet("color: green;")
        self._close_btn.setEnabled(True)
        self._close_btn.setText("Done")
        self._close_btn.clicked.disconnect()
        self._close_btn.clicked.connect(self.accept)
        self._sse_thread = None

    def _on_upload_error(self, msg: str):
        if self._sse_thread is not None:
            self._sse_thread.stop()
            self._sse_thread = None
        self._progress_bar.setVisible(False)
        self._status_label.setText(f"❌  Upload failed: {msg}")
        self._status_label.setStyleSheet("color: red;")
        self._upload_btn.setEnabled(True)
        self._close_btn.setEnabled(True)

    def uploaded_table(self) -> str:
        return self._uploaded_table or ""

    def reject(self):
        if self._sse_thread is not None:
            self._sse_thread.stop()
            self._sse_thread = None
        super().reject()

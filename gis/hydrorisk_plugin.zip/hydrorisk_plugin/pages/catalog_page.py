# -*- coding: utf-8 -*-
"""
ManagerCatalogPage — dataset catalog browser for the Dataset Manager wizard.

Displays all datasets in the DB as a tree (category → dataset), with
Upload, Remove and Load-in-QGIS buttons. Navigates to an upload page via wiz.next().
"""
import urllib.error

from qgis.PyQt.QtWidgets import (
    QWizard, QWizardPage, QVBoxLayout, QHBoxLayout,
    QGroupBox, QLabel, QPushButton, QRadioButton, QButtonGroup,
    QSizePolicy, QTreeWidget, QTreeWidgetItem,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont

from ..common.connection_store import make_client as _make_client


class ManagerCatalogPage(QWizardPage):
    """
    Dataset catalog page.

    Constructor arguments
    ---------------------
    next_page : int
        Page ID of the upload page (reached via wiz.next() / Upload button).
    """

    def __init__(self, parent=None, next_page=-1):
        super().__init__(parent)
        self._next_page       = next_page
        self._catalog_cache   = None  # raw {category: [ds, ...]} from API
        self._catalog_columns = []
        self._catalog_msg     = ""
        self.setTitle("Dataset catalog")
        self.setSubTitle("Datasets currently in the database, grouped by category.")

        layout = QVBoxLayout(self)

        # ── Catalog group ─────────────────────────────────────────────
        catalog_group = QGroupBox("Catalog", self)
        catalog_vbox  = QVBoxLayout(catalog_group)

        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Show:"))
        self._rb_input  = QRadioButton("Inputs")
        self._rb_result = QRadioButton("Results")
        self._rb_input.setChecked(True)
        self._filter_group = QButtonGroup(self)
        self._filter_group.addButton(self._rb_input,  0)
        self._filter_group.addButton(self._rb_result, 1)
        for rb in (self._rb_input, self._rb_result):
            filter_row.addWidget(rb)
        filter_row.addStretch()
        catalog_vbox.addLayout(filter_row)

        ctrl_row = QHBoxLayout()
        self._refresh_btn = QPushButton("↻ Refresh")
        self._catalog_lbl = QLabel("")   # catalog load / network status
        ctrl_row.addWidget(self._refresh_btn)
        ctrl_row.addWidget(self._catalog_lbl, 1)
        catalog_vbox.addLayout(ctrl_row)

        self._tree = QTreeWidget()
        self._tree.setColumnCount(1)
        self._tree.setHeaderLabels(["Category / Dataset"])
        self._tree.setAlternatingRowColors(True)
        self._tree.setSortingEnabled(True)
        self._tree.setRootIsDecorated(True)
        self._tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self._tree.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        catalog_vbox.addWidget(self._tree, 1)

        layout.addWidget(catalog_group, 1)

        # ── Actions group ─────────────────────────────────────────────
        actions_group = QGroupBox("Actions", self)
        actions_vbox  = QVBoxLayout(actions_group)

        btn_row = QHBoxLayout()
        self._upload_btn    = QPushButton("⬆  Upload new data")
        self._remove_btn    = QPushButton("🗑  Remove selected")
        self._load_qgis_btn = QPushButton("🗺  Load in QGIS")
        btn_row.addWidget(self._upload_btn)
        btn_row.addWidget(self._remove_btn)
        btn_row.addWidget(self._load_qgis_btn)
        btn_row.addStretch()
        actions_vbox.addLayout(btn_row)

        self._action_lbl = QLabel("")    # action feedback (load / remove)
        actions_vbox.addWidget(self._action_lbl)

        layout.addWidget(actions_group)

        # ── Wiring ────────────────────────────────────────────────────
        self._refresh_btn.clicked.connect(self._fetch_catalog)
        self._upload_btn.clicked.connect(self._go_to_upload)
        self._remove_btn.clicked.connect(self._remove_selected)
        self._load_qgis_btn.clicked.connect(self._load_selected_in_qgis)
        self._filter_group.buttonClicked.connect(lambda _: self._rebuild_tree())
        self._remove_btn.setEnabled(False)
        self._load_qgis_btn.setEnabled(False)
        self._tree.currentItemChanged.connect(self._update_action_buttons)
        self._tree.itemSelectionChanged.connect(self._update_action_buttons_selection)
        self._tree.itemDoubleClicked.connect(self._on_item_double_clicked)

    # ------------------------------------------------------------------

    def initializePage(self):
        wiz = self.wizard()
        wiz.button(QWizard.NextButton).setVisible(False)
        wiz.button(QWizard.NextButton).setEnabled(False)
        # Reuse cache if already populated; Refresh button forces a new fetch
        if self._catalog_cache is None:
            self._fetch_catalog()
        else:
            self._rebuild_tree()

    def _go_to_upload(self):
        wiz = self.wizard()
        wiz.button(QWizard.NextButton).setVisible(True)
        wiz.button(QWizard.NextButton).setEnabled(True)
        wiz.next()

    def _update_action_buttons(self, current, _previous):
        is_dataset = current is not None and current.parent() is not None
        self._load_qgis_btn.setEnabled(is_dataset)
        # remove button: any selected dataset item is sufficient
        selected_datasets = [i for i in self._tree.selectedItems() if i.parent() is not None]
        self._remove_btn.setEnabled(len(selected_datasets) > 0)

    def _update_action_buttons_selection(self):
        selected_datasets = [i for i in self._tree.selectedItems() if i.parent() is not None]
        self._remove_btn.setEnabled(len(selected_datasets) > 0)

    def _on_item_double_clicked(self, item, _column):
        if item is not None and item.parent() is not None:
            self._load_selected_in_qgis()

    def _set_action_status(self, text, color=""):
        self._action_lbl.setText(text)
        self._action_lbl.setStyleSheet(f"color: {color};" if color else "")

    def _get_geom_column(self, data_table: str) -> str:
        """Query the Hydrorisk API for the geometry column name of a vector table."""
        try:
            return _make_client().geom_column(data_table)
        except Exception:
            return "geom"

    def _load_selected_in_qgis(self):
        item = self._tree.currentItem()
        if item is None or item.parent() is None:
            self._set_action_status("⚠  Select a dataset (not a category) to load.", "orange")
            return

        ds = item.data(0, Qt.UserRole + 1)
        if ds is None:
            self._set_action_status("⚠  No dataset info available for selected item.", "orange")
            return

        data_table = ds.get("data_table", "")
        if not data_table:
            self._set_action_status("⚠  No data table associated with this dataset.", "orange")
            return
        layer_name = ds.get("name") or data_table
        fmt        = ds.get("format", "")

        try:
            from qgis.core import (
                QgsRasterLayer, QgsVectorLayer,
                QgsProject, QgsMessageLog, Qgis,
            )
            import os, tempfile
            ext      = {"raster": ".tif", "vector": ".zip"}.get(fmt, ".csv")
            tmp_path = os.path.join(tempfile.gettempdir(), f"{data_table}{ext}")
            self._set_action_status(f"⏳  Downloading {fmt}…")
            _make_client().download_data(data_table, tmp_path)

            if fmt == "raster":
                layer = QgsRasterLayer(tmp_path, layer_name, "gdal")
            elif fmt == "vector":
                # Shapefile is zipped; use GDAL /vsizip/ virtual FS to load directly
                layer = QgsVectorLayer(f"/vsizip/{tmp_path}/{data_table}.shp", layer_name, "ogr")
            else:
                uri   = f"file:///{tmp_path}?type=csv&maxFields=10000&detectTypes=yes"
                layer = QgsVectorLayer(uri, layer_name, "delimitedtext")

            QgsMessageLog.logMessage(
                f"[Hydrorisk] Load in QGIS — fmt={fmt!r} table={data_table!r}",
                "Hydrorisk", Qgis.Info,
            )

            if not layer.isValid():
                err_msg = layer.error().message() if layer.error() else "unknown error"
                QgsMessageLog.logMessage(
                    f"[Hydrorisk] Layer invalid: {err_msg}",
                    "Hydrorisk", Qgis.Warning,
                )
                self._set_action_status(
                    f"❌  Could not load '{layer_name}': {err_msg or 'check QGIS log for details'}.",
                    "red",
                )
                return

            QgsProject.instance().addMapLayer(layer)
            self._set_action_status(f"✅  '{layer_name}' added to QGIS layers.", "green")
        except Exception as exc:
            self._set_action_status(f"❌  {exc}", "red")

    def _remove_selected(self):
        from qgis.PyQt.QtWidgets import QMessageBox
        selected_items = [i for i in self._tree.selectedItems() if i.parent() is not None]
        if not selected_items:
            self._set_action_status("⚠  Select one or more datasets (not categories) to remove.", "orange")
            return

        data_tables = []
        for item in selected_items:
            dt = item.data(0, Qt.UserRole)
            if dt:
                data_tables.append(dt)
        if not data_tables:
            self._set_action_status("⚠  Could not determine data_table for selected items.", "orange")
            return

        if len(data_tables) == 1:
            msg = f"Permanently remove\n{data_tables[0]}\nfrom the database?"
        else:
            listing = "\n".join(f"  • {dt}" for dt in data_tables)
            msg = f"Permanently remove {len(data_tables)} datasets from the database?\n\n{listing}"

        reply = QMessageBox.question(
            self,
            "Confirm removal",
            msg,
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        errors = []
        removed = []
        client = _make_client()
        for data_table in data_tables:
            self._set_action_status(f"Removing {data_table}…")
            try:
                client.remove_data(data_table)
                removed.append(data_table)
                for cat_key, datasets in list(self._catalog_cache.items()):
                    items_list = datasets if isinstance(datasets, list) else list(datasets.values())
                    filtered = [d for d in items_list if str(d.get("data_table", "")) != data_table]
                    self._catalog_cache[cat_key] = filtered
            except Exception as exc:
                errors.append(f"{data_table}: {exc}")

        self._rebuild_tree()
        if errors:
            self._set_action_status(
                f"⚠  Removed {len(removed)}, {len(errors)} failed: " + "; ".join(errors), "orange"
            )
        else:
            self._set_action_status(f"✅  Removed {len(removed)} dataset(s).", "green")

    def _fetch_catalog(self):
        """Fetch catalog from the API, cache it, then rebuild the tree."""
        self._catalog_cache   = None
        self._catalog_columns = []
        self._catalog_msg     = ""
        self._tree.clear()
        self._catalog_lbl.setText("Loading…")
        self._catalog_lbl.setStyleSheet("")

        try:
            client   = _make_client()
            response = client.db_data_catalog()
            data     = response.get("data", {})
            msg      = response.get("msg", "")
        except urllib.error.URLError as exc:
            self._catalog_lbl.setText(f"❌  Network error: {exc.reason}")
            self._catalog_lbl.setStyleSheet("color: red;")
            return
        except Exception as exc:
            self._catalog_lbl.setText(f"❌  {exc}")
            self._catalog_lbl.setStyleSheet("color: red;")
            return

        if not data:
            self._catalog_lbl.setText("No datasets found.")
            return

        def _displayable(v):
            return v is not None and not isinstance(v, (list, dict))

        columns = []
        for datasets in data.values():
            if isinstance(datasets, list) and datasets:
                columns = [k for k, v in datasets[0].items() if _displayable(v)]
                break
            elif isinstance(datasets, dict) and datasets:
                columns = [k for k, v in next(iter(datasets.values())).items() if _displayable(v)]
                break

        self._catalog_cache   = data
        self._catalog_columns = columns
        self._catalog_msg     = msg
        self._rebuild_tree()

    def _rebuild_tree(self):
        """Rebuild the tree from the cache applying the current filter — no network call."""
        self._tree.clear()
        if not self._catalog_cache:
            return

        data    = self._catalog_cache
        columns = self._catalog_columns
        fid     = self._filter_group.checkedId()

        self._tree.setColumnCount(len(columns) + 1)
        self._tree.setHeaderLabels(
            ["Job / Dataset" if fid == 1 else "Category / Dataset"] + columns
        )

        bold = QFont()
        bold.setBold(True)

        self._upload_btn.setVisible(fid != 1)

        if fid == 1:
            # Flatten all datasets, keep results only, then group by job
            all_ds = [
                d
                for datasets in data.values()
                for d in (datasets if isinstance(datasets, list) else list(datasets.values()))
                if d.get("result") is True
            ]
            jobs: dict = {}
            for ds in all_ds:
                jlabel = ds.get("job_prefix") or (ds.get("job_id_hash") or "")[:8] or "— no job —"
                jobs.setdefault(jlabel, []).append(ds)

            for jlabel in sorted(jobs.keys()):
                job_item = QTreeWidgetItem([jlabel])
                job_item.setFont(0, bold)
                self._tree.addTopLevelItem(job_item)
                for ds in jobs[jlabel]:
                    row        = [ds.get(col, "") for col in columns]
                    label      = str(ds.get("name", "—"))
                    data_table = str(ds.get("data_table", ""))
                    ds_item = QTreeWidgetItem(
                        ["  " + label] + [str(v) if v is not None else "" for v in row]
                    )
                    ds_item.setData(0, Qt.UserRole,     data_table)
                    ds_item.setData(0, Qt.UserRole + 1, ds)
                    job_item.addChild(ds_item)
                job_item.setExpanded(True)
        else:
            # Inputs: group by category (existing behaviour)
            for category in sorted(data.keys()):
                datasets = data[category]
                items = datasets if isinstance(datasets, list) else list(datasets.values())
                items = [d for d in items if d.get("input") is True]

                if not items:
                    continue

                cat_item = QTreeWidgetItem([category])
                cat_item.setFont(0, bold)
                self._tree.addTopLevelItem(cat_item)

                for ds in items:
                    row        = [ds.get(col, "") for col in columns]
                    label      = str(ds.get("name", "—"))
                    data_table = str(ds.get("data_table", ""))
                    ds_item = QTreeWidgetItem(
                        ["  " + label] + [str(v) if v is not None else "" for v in row]
                    )
                    ds_item.setData(0, Qt.UserRole,     data_table)
                    ds_item.setData(0, Qt.UserRole + 1, ds)
                    cat_item.addChild(ds_item)

                cat_item.setExpanded(True)

        self._tree.resizeColumnToContents(0)
        self._catalog_lbl.setText(self._catalog_msg)
        self._catalog_lbl.setStyleSheet("color: green;")

    # ------------------------------------------------------------------

    def nextId(self):
        return self._next_page

    def isComplete(self):
        return True

# -*- coding: utf-8 -*-
"""
HrRunnerWizard — 3-page QWizard for running the OsmotiC workflow.

Pages
-----
0  HrTmConnectionPage    — API URL + token
1  HrTmTaskSelectionPage — pick an existing job + choose pipeline stages
2  HrTmMonitorPage       — launch run_job, poll job_status, show live progress
"""
from qgis.PyQt.QtWidgets import QWizard
from qgis.PyQt.QtCore import QSize

from .base_wizard import HrBaseWizard
from ..pages.task_selection_page import HrTmTaskSelectionPage
from ..pages.monitor_page import HrTmMonitorPage

# ─────────────────────────────────────────────────────────────────────────────
PAGE_TASK_SELECTION = 0
PAGE_MONITOR        = 1

# ─────────────────────────────────────────────────────────────────────────────
# Job selection + pipeline stages
# ─────────────────────────────────────────────────────────────────────────────


class HrRunnerWizard(HrBaseWizard):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hydrorisk — Runner")
        self.setMinimumSize(QSize(620, 520))
        self.setWizardStyle(QWizard.ModernStyle)

        self.setPage(PAGE_TASK_SELECTION, HrTmTaskSelectionPage(self, next_page=PAGE_MONITOR))
        self.setPage(PAGE_MONITOR,        HrTmMonitorPage(self, next_page=-1))

        self.setOption(QWizard.NoDefaultButton, False)
        self.setButtonText(QWizard.FinishButton, "Close")

        self.finished.connect(self._on_close)

    def _on_close(self, _result):
        # Ensure polling timer is stopped if user closes mid-run
        monitor = self.page(PAGE_MONITOR)
        if monitor and monitor._timer.isActive():
            monitor._timer.stop()

# -*- coding: utf-8 -*-
"""
BaseDataInputsPage — shared catalog-driven data-input page for Hydrorisk wizards.

Used by both cfg_wizard and job_manager_wizard.

Extension points
----------------
_setup_header(layout)
    Called in ``__init__`` before the scroll area.  Override to inject widgets
    above the form (e.g. a usage-statistics group box).

_build_row_widget(db_cat, combo, col_combo, cat_meta) -> QWidget
    Returns the widget placed in the right-hand column of each form row.
    Override to inject extra controls such as a per-category upload button.

_on_catalog_loaded(seed)
    Called at the end of ``initializePage`` after the form is fully built.
    Override for seed pre-fill, stats refresh, etc.

_extra_clear()
    Called at the end of ``_clear_all``.  Override to clear subclass-specific
    dicts (e.g. ``_upload_btns``).
"""
import json

from qgis.PyQt.QtWidgets import (
    QWizardPage,
    QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QComboBox, QCheckBox, QWidget,
)
from .groupboxes.dataset_inputs_groupbox import HrDatasetInputsGroupBox
from ..common.connection_store import make_client as _make_client


class BaseDataInputsPage(QWizardPage):
    """
    Scrollable form with one row per dataset category:
      checkbox (left)  +  dataset combo  [+ optional column combo]  (right)

    Mandatory categories are pre-checked and locked; optional ones start unchecked.
    Column picker visibility is controlled by the ``select_col`` / ``has_field``
    key in the category metadata (both names are recognised).
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        self._combos            = {}   # db_cat → QComboBox (dataset)
        self._fields            = {}   # db_cat → QComboBox (column)
        self._checks            = {}   # db_cat → QCheckBox
        self._catalog           = {}   # db_cat → [ds, …]
        self._all_categories    = []
        self._categories_meta   = {}
        self._folder_categories = {}   # db_cat → [formats] for folder-capable categories

        self._status = QLabel("Fetching catalog…")

        outer = QVBoxLayout(self)
        self._setup_header(outer)

        inputs_group = HrDatasetInputsGroupBox(parent=self)
        self._inputs_group = inputs_group  # exposed so subclasses can toggle visibility
        self._status = inputs_group._status
        self._form   = inputs_group._form
        outer.addWidget(inputs_group, 1)

    # ------------------------------------------------------------------
    # Extension hooks

    def _setup_header(self, layout):
        """Hook: inject widgets above the form (e.g. stats group)."""

    def _build_row_widget(self, db_cat, combo, col_combo, cat_meta):
        """
        Build the right-hand widget for a form row.
        Default: [combo  col_combo].  Override to add extra controls.
        """
        row = QWidget()
        rl  = QHBoxLayout(row)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(6)
        rl.addWidget(combo,     2)
        rl.addWidget(col_combo, 1)
        return row

    def _on_catalog_loaded(self, seed):
        """Hook: called after the form is built. Override for seed pre-fill."""

    def _extra_clear(self):
        """Hook: called at end of _clear_all. Override to clear subclass dicts."""

    # ------------------------------------------------------------------
    # Core initializePage

    def initializePage(self):
        self._status.setText("Fetching catalog from server…")
        self._status.setStyleSheet("")
        self._clear_all()

        # PAGE_CONNECTION is always page 0 in every wizard
        conn_page = self.wizard().page(0)
        try:
            response = _make_client().db_data_catalog()
            self._catalog = {
                cat: (raw if isinstance(raw, list) else list(raw.values()))
                for cat, raw in response.get("data", {}).items()
            }
            cats = response.get("categories", {})
            self._categories_meta = cats if isinstance(cats, dict) else {}
            self._all_categories = (
                list(self._categories_meta.keys())
                if self._categories_meta
                else list(self._catalog.keys())
            )
            try:
                self._folder_categories = _make_client().db_folder_categories()
            except Exception:
                self._folder_categories = {}
        except Exception as exc:
            self._status.setText(f"❌  Could not load catalog: {exc}")
            self._status.setStyleSheet("color: red;")
            return

        for db_cat in self._all_categories:
            available  = bool(self._catalog.get(db_cat))
            cat_meta   = self._categories_meta.get(db_cat, {})
            label      = cat_meta.get("desc") or db_cat.replace("_", " ").capitalize()
            optional   = cat_meta.get("optional", True)
            req_marker = "" if optional else " *"

            # ── Checkbox ─────────────────────────────────────────────────
            cb = QCheckBox(f"{label}{req_marker}")
            if not available:
                cb.setChecked(False)
                cb.setEnabled(False)
                cb.setStyleSheet("color: grey; text-decoration: line-through;")
            elif not optional:
                cb.setChecked(True)
                cb.setEnabled(False)
            else:
                cb.setChecked(False)
            self._checks[db_cat] = cb

            # ── Dataset combo ─────────────────────────────────────────────
            combo = QComboBox()
            if not optional:
                combo.addItem("— select —", None)
            for ds in self._catalog.get(db_cat, []):
                combo.addItem(ds.get("name", ds.get("data_table", "?")), ds)
            combo.setEnabled(cb.isChecked())
            self._combos[db_cat] = combo

            # ── Column combo (hidden until needed) ────────────────────────
            col_combo = QComboBox()
            col_combo.setEnabled(False)
            col_combo.setVisible(False)
            col_combo.addItem("— attribute —")
            self._fields[db_cat] = col_combo

            # ── Row widget (hook) ─────────────────────────────────────────
            row_widget = self._build_row_widget(db_cat, combo, col_combo, cat_meta)
            self._form.addRow(cb, row_widget)

            combo.currentIndexChanged.connect(self.completeChanged.emit)
            combo.currentIndexChanged.connect(
                lambda _, dc=db_cat: self._load_columns(dc)
            )
            cb.toggled.connect(lambda checked, dc=db_cat: self._on_toggle(dc, checked))

        n_avail = sum(bool(v) for v in self._catalog.values())
        self._status.setText(f"✅  {n_avail} category(ies) available in the catalog.")
        self._status.setStyleSheet("color: green;")

        seed = getattr(self.wizard(), "seed_config", lambda: {})()
        self._on_catalog_loaded(seed)
        self.completeChanged.emit()

    # ------------------------------------------------------------------
    # Internal helpers

    def _on_toggle(self, db_cat, checked):
        combo = self._combos.get(db_cat)
        if combo:
            combo.setEnabled(checked)
        col_combo = self._fields.get(db_cat)
        if col_combo:
            if not checked:
                col_combo.setVisible(False)
                col_combo.setEnabled(False)
            else:
                self._load_columns(db_cat)
        self.completeChanged.emit()

    def _load_columns(self, db_cat):
        col_combo = self._fields.get(db_cat)
        if col_combo is None:
            return

        cat_meta   = self._categories_meta.get(db_cat, {})
        select_col = cat_meta.get("select_col", cat_meta.get("has_field", False))
        if not select_col:
            col_combo.setVisible(False)
            col_combo.setEnabled(False)
            return

        ds = self._combos[db_cat].currentData()
        col_combo.clear()
        if ds is None:
            col_combo.setVisible(False)
            col_combo.setEnabled(False)
            return

        columns = []
        raw = ds.get("columns") or []
        if isinstance(raw, list):
            columns = raw
        elif isinstance(raw, str):
            s = raw.strip()
            try:
                parsed = json.loads(s)
                columns = parsed if isinstance(parsed, list) else []
            except Exception:
                if s.startswith("{") and s.endswith("}"):
                    inner = s[1:-1]
                    columns = [c.strip().strip('"') for c in inner.split(",") if c.strip()]

        if columns:
            col_combo.setVisible(True)
            col_combo.setEnabled(True)
            for col in columns:
                col_combo.addItem(str(col))
        else:
            col_combo.addItem("— no columns available —")
            col_combo.setVisible(True)
            col_combo.setEnabled(False)

    def _clear_all(self):
        self._combos.clear()
        self._fields.clear()
        self._checks.clear()
        self._catalog.clear()
        self._categories_meta.clear()
        self._all_categories.clear()
        self._folder_categories.clear()
        while self._form.rowCount():
            self._form.removeRow(0)
        self._extra_clear()

    # ------------------------------------------------------------------
    # QWizardPage interface

    def isComplete(self):
        for db_cat in self._all_categories:
            optional = self._categories_meta.get(db_cat, {}).get("optional", True)
            if not optional and db_cat in self._combos:
                if self._combos[db_cat].currentData() is None:
                    return False
        return True

    def validatePage(self):
        return self.isComplete()

    def get_inputs(self):
        """Return ``{cfg_key: {"id": …, "name": …, "field": …}}`` for checked and selected inputs."""
        result = {}
        for db_cat in self._all_categories:
            # Only include if checkbox is checked
            checkbox = self._checks.get(db_cat)
            if checkbox is None or not checkbox.isChecked():
                continue
            if db_cat not in self._combos:
                continue
            ds = self._combos[db_cat].currentData()
            if ds is None:
                continue
            cat_meta = self._categories_meta.get(db_cat, {})
            cfg_key  = cat_meta.get("cfg_key", db_cat)
            entry = {
                "id":   ds.get("data_table", ""),
                "name": ds.get("name", ds.get("data_table", "")),
            }
            field_combo = self._fields.get(db_cat)
            if field_combo:
                field = field_combo.currentText().strip()
                if field and not field.startswith("—"):
                    entry["field"] = field
            result[cfg_key] = entry
        return result

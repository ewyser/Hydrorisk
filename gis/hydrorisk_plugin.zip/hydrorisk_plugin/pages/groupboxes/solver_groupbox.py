# -*- coding: utf-8 -*-
"""
HrSolverGroupBox — solver options group box (shared by both sim-settings variants).

The ``show_infilt`` flag adds the infiltration-solver combo (used by HrCfgSimSettingsPage).

Exposes:
    _threads        QSpinBox
    _precision      QComboBox
    _riemann        QComboBox
    _hydrostatic    QComboBox
    _infilt_solver  QComboBox   (only when show_infilt=True)
"""
import multiprocessing

from qgis.PyQt.QtWidgets import QGroupBox, QFormLayout, QComboBox, QSpinBox


class HrSolverGroupBox(QGroupBox):
    def __init__(self, show_infilt: bool = False, parent=None):
        super().__init__("Solver", parent)
        form = QFormLayout(self)

        self._threads = QSpinBox()
        self._threads.setRange(1, multiprocessing.cpu_count())
        self._threads.setValue(1)
        form.addRow("Threads:", self._threads)

        self._precision = QComboBox()
        self._precision.addItems(["32", "64"])
        form.addRow("Precision (bits):", self._precision)

        self._riemann = QComboBox()
        self._riemann.addItems(["HLL", "HLLC"])
        form.addRow("Riemann solver:", self._riemann)

        self._hydrostatic = QComboBox()
        self._hydrostatic.addItems(["CN", "Aud"])
        form.addRow("Hydrostatic reconstruction:", self._hydrostatic)

        self._infilt_solver = None
        if show_infilt:
            self._infilt_solver = QComboBox()
            self._infilt_solver.addItems(["none", "GA"])
            form.addRow("Infiltration solver:", self._infilt_solver)

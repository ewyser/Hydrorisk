# -*- coding: utf-8 -*-
"""
Thin QgsProcessingAlgorithm wrapper that opens HrJobMonitorDialog.

OsmotiC.jl polls the database autonomously and processes jobs flagged as
"submitted".  This tool simply lets the user watch all their jobs and their
per-task progress in real time.
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingAlgorithm


class HrRunnerAlgorithm(QgsProcessingAlgorithm):
    """Opens the Job Monitor dialog."""

    def tr(self, string):
        return QCoreApplication.translate("Processing", string)

    def createInstance(self):
        return HrRunnerAlgorithm()

    def name(self):
        return "hydrorisk_runner"

    def displayName(self):
        return self.tr("Job Monitor")

    def group(self):
        return self.tr("Manager")

    def groupId(self):
        return "hydrorisk_manager"

    def shortHelpString(self):
        return self.tr(
            "Opens the Job Monitor dialog.\n\n"
            "Lists all jobs owned by the authenticated user and shows their "
            "status and per-task progress in real time.  Jobs are executed "
            "automatically by OsmotiC.jl — no manual launch is required."
        )

    def flags(self):
        from ..common.connection_store import store as _conn_store
        base = super().flags() | QgsProcessingAlgorithm.FlagNoThreading
        if not _conn_store.url:
            return base | QgsProcessingAlgorithm.FlagHideFromToolbox
        return base

    def initAlgorithm(self, config=None):
        pass

    def processAlgorithm(self, parameters, context, feedback):
        from qgis.PyQt.QtWidgets import QApplication
        from ..pages.job_monitor_dialog import HrJobMonitorDialog

        parent = QApplication.activeWindow()
        dlg = HrJobMonitorDialog(parent)
        dlg.exec_()
        return {}

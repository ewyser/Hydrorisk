# -*- coding: utf-8 -*-
"""
Thin QgsProcessingAlgorithm wrapper that opens the DbManagerWizard.
Browse existing datasets and optionally upload new ones — loops until done.
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingAlgorithm


class DbManagerAlgorithm(QgsProcessingAlgorithm):
    """Opens the Dataset Manager wizard."""

    def tr(self, string):
        return QCoreApplication.translate("Processing", string)

    def createInstance(self):
        return DbManagerAlgorithm()

    def name(self):
        return "hydrorisk_db_manager"

    def displayName(self):
        return self.tr("Dataset")

    def group(self):
        return self.tr("Manager")

    def groupId(self):
        return "hydrorisk_manager"

    def shortHelpString(self):
        return self.tr(
            "Opens a wizard that connects to a running Hydrorisk.jl server instance, "
            "displays all datasets in the database, and lets you upload new "
            "data files repeatedly until you choose to stop.\n\n"
            "Steps:\n"
            "  1. Configure the API URL and bearer token\n"
            "  2. Browse the current dataset catalog\n"
            "  3. Tick 'I want to upload new data' → provide a server-side file path and category\n"
            "  4. After upload, click '↩ Upload another' to go back to the catalog, "
            "or Finish to close."
        )

    def flags(self):
        from ..common.connection_store import store as _conn_store
        base = super().flags() | QgsProcessingAlgorithm.FlagNoThreading
        if not _conn_store.url:
            return base | QgsProcessingAlgorithm.FlagHideFromToolbox
        return base

    def initAlgorithm(self, config=None):
        pass

    def processAlgorithm(self, parameters, context, feedback):
        from qgis.PyQt.QtWidgets import QApplication
        from ..wizard.db_manager_wizard import DbManagerWizard

        parent = QApplication.activeWindow()
        wizard = DbManagerWizard(parent)
        wizard.exec_()
        return {}

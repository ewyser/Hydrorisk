# -*- coding: utf-8 -*-
"""
HTTP client for the Hydrorisk.jl API.
Uses only stdlib urllib so it works inside QGIS without extra dependencies.
"""
import os
import io
import json
import glob
import zipfile
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Callable


class _ProgressReader:
    """File-like wrapper that reports how many bytes have been read.

    Passed as ``data`` to ``urllib.request.Request`` so that http.client
    reads the multipart body in 8 KB chunks and we can track progress.
    Content-Length must be set explicitly in the request headers.
    """

    def __init__(self, data: bytes, callback: Callable[[int, int], None]):
        self._buf      = memoryview(data)
        self._pos      = 0
        self._total    = len(data)
        self._callback = callback

    def read(self, n: int = -1) -> bytes:
        if n < 0:
            chunk = bytes(self._buf[self._pos:])
            self._pos = self._total
        else:
            chunk = bytes(self._buf[self._pos:self._pos + n])
            self._pos += len(chunk)
        self._callback(self._pos, self._total)
        return chunk

    def __len__(self) -> int:
        return self._total


class HydroriskClient:
    """Thin wrapper around the Hydrorisk.jl REST API."""

    def __init__(self, base_url: str, token: str):
        self.base_url = base_url.rstrip("/")
        self._token   = token
        self._headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

    # ------------------------------------------------------------------
    # Internal helper
    # ------------------------------------------------------------------

    def _get(self, path: str, timeout: int = 10) -> Any:
        url = f"{self.base_url}{path}"
        req = urllib.request.Request(url, headers=self._headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(body)
                msg = payload.get("msg", body)
            except Exception:
                msg = body or str(exc)
            raise RuntimeError(msg) from exc

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _get_bytes(self, path: str, timeout: int = 30) -> bytes:
        """GET a binary response (no JSON parsing)."""
        url = f"{self.base_url}{path}"
        req = urllib.request.Request(url, headers=self._headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body).get("msg", body)
            except Exception:
                msg = body or str(exc)
            raise RuntimeError(msg) from exc

    def check_auth(self) -> Dict:
        """GET /auth — verify the token is valid."""
        return self._get("/auth")

    def db_catalogs(self) -> Dict:
        """GET /query/db-catalogs — returns all catalogs keyed by name (export_catalog, import_catalog, instr_catalog)."""
        return self._get("/query/db-catalogs")

    def db_categories(self) -> Dict:
        """Convenience: returns the import_catalog entry from db_catalogs."""
        return self.db_catalogs().get("import_catalog", {})

    def db_folder_categories(self) -> dict:
        """Derive {category: [products]} from assimilation_catalog for folder-upload gating.

        The catalog uses a flat product-keyed structure:
            "folder": { "CPC": {"category": "precipitation", ...}, "INCA": {...} }
        This rebuilds the {category: [products]} form expected by the plugin.
        """
        raw = self.db_catalogs().get("assimilation_catalog", {})
        if isinstance(raw, dict):
            folder_cats = raw.get("folder", {})
            if isinstance(folder_cats, dict):
                result: dict = {}
                for product, meta in folder_cats.items():
                    if isinstance(meta, dict):
                        cat = meta.get("category")
                        if cat:
                            result.setdefault(cat, []).append(product)
                return result
        return {}

    def db_export_catalog(self) -> Dict:
        """Convenience: returns the export_catalog entry from db_catalogs."""
        return self.db_catalogs().get("export_catalog", {})

    def task_config(self) -> Dict:
        """GET /query/task-config — returns stages list and status_icons map."""
        return self._get("/query/task-config")

    def db_data_catalog(self) -> Dict:
        """GET /query/db-data-catalog — returns {msg, status, data: category => [...]}."""
        return self._get("/query/db-data-catalog")

    def db_info(self) -> Dict:
        """GET /query/db-info — returns {host, port, user, dbname} of the server DB."""
        return self._get("/query/db-info")

    def user_stats(self) -> Dict:
        """GET /query/user-stats — returns upload stats for the authenticated user."""
        return self._get("/query/user-stats").get("stats", {})

    def upload_file_content(self, local_path: str, category: str,
                            progress_cb: Callable[[int, int], None] = None,
                            upload_id: str = None) -> Dict:
        """POST /data/upload — stream a local file as multipart/form-data.

        Shapefiles (.shp) are automatically bundled with their sidecar files
        (.shx, .dbf, .prj, .cpg, …) into a zip before uploading.

        If *upload_id* is provided it is sent as a form field so the server can
        route ``NOTIFY`` log messages to ``/data/upload/{upload_id}/stream``.
        If *progress_cb* is provided it is called as ``progress_cb(sent, total)``
        each time urllib reads a chunk (~8 KB) from the request body.
        """
        import uuid
        upload_id = upload_id or str(uuid.uuid4())
        ext = os.path.splitext(local_path)[1].lower()
        if ext == ".shp":
            # Collect all sidecar files sharing the same stem.
            # glob.glob with the escaped stem avoids all path-separator and
            # case-sensitivity issues that arise with os.listdir on Windows.
            stem = os.path.splitext(local_path)[0]
            buf  = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for entry_path in glob.glob(glob.escape(stem) + ".*"):
                    if os.path.isfile(entry_path):
                        zf.write(entry_path, os.path.basename(entry_path))
            upload_bytes = buf.getvalue()
            filename     = os.path.basename(stem) + ".zip"
        else:
            with open(local_path, "rb") as f:
                upload_bytes = f.read()
            filename = os.path.basename(local_path)

        body, headers = self._build_upload_body(category, upload_id, "file", upload_bytes, filename)
        data = _ProgressReader(body, progress_cb) if progress_cb else body
        url  = f"{self.base_url}/data/upload"
        req  = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def upload_folder_content(self, local_folder: str, category: str,
                              progress_cb: Callable[[int, int], None] = None,
                              upload_id: str = None) -> Dict:
        """POST /data/upload — zip a local folder and upload it as a multiband raster.

        The server will extract the archive into a temp directory and pass that
        directory to ``OsmotiC.db_add_data`` so all raster bands are imported.

        If *upload_id* is provided it is sent as a form field so the server can
        route ``NOTIFY`` log messages to ``/data/upload/{upload_id}/stream``.
        If *progress_cb* is provided it is called as ``progress_cb(sent, total)``.
        """
        import uuid
        upload_id   = upload_id or str(uuid.uuid4())
        folder_name = os.path.basename(local_folder.rstrip("/\\"))
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, _dirs, files in os.walk(local_folder):
                for fname in files:
                    full_path = os.path.join(root, fname)
                    arcname   = os.path.relpath(full_path, start=local_folder)
                    zf.write(full_path, arcname)
        upload_bytes = buf.getvalue()
        filename     = folder_name + ".zip"

        body, headers = self._build_upload_body(category, upload_id, "folder", upload_bytes, filename)
        data = _ProgressReader(body, progress_cb) if progress_cb else body
        url  = f"{self.base_url}/data/upload"
        req  = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def _build_upload_body(self, category: str,
                           upload_id: str, source_type: str,
                           upload_bytes: bytes, filename: str):
        """Build multipart body bytes and matching headers dict."""
        boundary = b"----HydroriskBoundary" + os.urandom(16).hex().encode()
        body  = b""
        body += b"--" + boundary + b"\r\n"
        body += b'Content-Disposition: form-data; name="source_type"\r\n\r\n'
        body += source_type.encode() + b"\r\n"
        body += b"--" + boundary + b"\r\n"
        body += f'Content-Disposition: form-data; name="category"\r\n\r\n'.encode()
        body += category.encode() + b"\r\n"
        body += b"--" + boundary + b"\r\n"
        body += b'Content-Disposition: form-data; name="upload_id"\r\n\r\n'
        body += upload_id.encode() + b"\r\n"
        body += b"--" + boundary + b"\r\n"
        body += f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'.encode()
        body += b"Content-Type: application/octet-stream\r\n\r\n"
        body += upload_bytes + b"\r\n"
        body += b"--" + boundary + b"--\r\n"
        headers = dict(self._headers)
        headers["Content-Type"]   = f"multipart/form-data; boundary={boundary.decode()}"
        headers["Content-Length"] = str(len(body))
        return body, headers

    def submit_job(self, config: dict) -> Dict:
        """POST /jobs/submit — create a job in the DB; returns the job record."""
        url  = f"{self.base_url}/jobs/submit"
        body = json.dumps(config).encode("utf-8")
        req  = urllib.request.Request(url, data=body, headers=self._headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def list_jobs(self) -> list:
        """GET /jobs/list — return all jobs for the authenticated user."""
        return self._get("/jobs/list")

    def run_job(self, id_hash: str, tasks: list = None) -> Dict:
        """POST /jobs/run — execute a previously submitted job asynchronously.

        Parameters
        ----------
        id_hash : str
            Job identifier returned by submit_job().
        tasks : list of str, optional
            Pipeline stages to run: any subset of ["prepare", "execute", "post", "move"].
            Defaults to ["prepare", "execute", "post"] when omitted.

        Returns
        -------
        dict
            Contains ``id_hash`` and ``msg``.  Poll job_status() to track progress.
        """
        url  = f"{self.base_url}/jobs/run"
        body_dict = {"id_hash": id_hash}
        if tasks is not None:
            body_dict["tasks"] = tasks
        body = json.dumps(body_dict).encode("utf-8")
        req  = urllib.request.Request(url, data=body, headers=self._headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def run_task(self, id_hash: str, task_name: str) -> Dict:
        """POST /jobs/tasks/{task_name}/run — start a pending task for the first time."""
        url  = f"{self.base_url}/jobs/tasks/{task_name}/run"
        body = json.dumps({"id_hash": id_hash}).encode("utf-8")
        req  = urllib.request.Request(url, data=body, headers=self._headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def restart_task(self, id_hash: str, task_name: str) -> Dict:
        """POST /jobs/tasks/{task_name}/restart — force-re-run a single task, even if already completed."""
        url  = f"{self.base_url}/jobs/tasks/{task_name}/restart"
        body = json.dumps({"id_hash": id_hash}).encode("utf-8")
        req  = urllib.request.Request(url, data=body, headers=self._headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def job_status(self, id_hash: str) -> Dict:
        """GET /jobs/status/<id_hash> — poll the execution status of a job."""
        return self._get(f"/jobs/status/{id_hash}")

    def download_data(
        self,
        data_table: str,
        dest_path: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        timeout: int = 120,
    ) -> str:
        """GET /data/download — download a dataset as a file.

        The server detects the format from ``metadata.dataset`` and returns:
        - raster → GeoTIFF
        - vector → GeoJSON
        - table  → CSV

        Parameters
        ----------
        data_table : str
            Dataset table name (with or without ``data.`` prefix).
        dest_path : str
            Local file path where the file will be written.
        start : str, optional
            ISO-8601 datetime; raster only — keep bands with ``start_ts >= start``.
        end : str, optional
            ISO-8601 datetime; raster only — keep bands with ``end_ts <= end``.
        timeout : int
            HTTP timeout in seconds (default 120).

        Returns
        -------
        str
            The absolute path to the written file (*dest_path*).
        """
        import urllib.parse
        qs = {"data_table": data_table}
        if start is not None:
            qs["start"] = start
        if end is not None:
            qs["end"] = end
        path = "/data/download?" + urllib.parse.urlencode(qs)
        data_bytes = self._get_bytes(path, timeout=timeout)
        with open(dest_path, "wb") as f:
            f.write(data_bytes)
        return dest_path

    def sse_upload_logs(self, upload_id: str, on_event, on_done, on_error=None):
        """Open a live SSE log stream for *upload_id* and return a started ``SseThread``.

        Streams ``@info``/``@warn``/``@error`` messages emitted by OsmotiC during
        import, forwarded by Hydrorisk via ``/data/upload/{upload_id}/stream``.
        Each event dict has keys: ``upload_id``, ``level``, ``msg``, ``ts``.
        The stream closes automatically when OsmotiC emits its terminal message.
        """
        from .sse_client import SseThread
        url    = f"{self.base_url}/data/upload/{upload_id}/stream"
        thread = SseThread(url, self._token, on_event, on_done, on_error)
        thread.start()
        return thread

    def sse_jobs_stream(self, on_event, on_done, on_error=None):
        """Open a live SSE stream for **all** user jobs (``GET /jobs/stream``).

        The server polls ``db_list_jobs`` every few seconds and pushes the full
        job list whenever anything changes.  ``on_event`` receives a Python
        ``list`` of job dicts (same shape as ``list_jobs()``).
        """
        from .sse_client import SseThread
        url    = f"{self.base_url}/jobs/stream"
        thread = SseThread(url, self._token, on_event, on_done, on_error)
        thread.start()
        return thread

    def sse_job_status(self, id_hash: str, on_event, on_done, on_error=None):
        """Open a live SSE stream for *id_hash* and return a started ``SseThread``.

        The thread calls ``on_event(data: dict)`` for every status update,
        ``on_done()`` when the stream ends, and ``on_error(exc)`` on failure.
        Call ``thread.stop()`` to close the connection early.
        """
        from .sse_client import SseThread
        url    = f"{self.base_url}/jobs/status/{id_hash}/stream"
        thread = SseThread(url, self._token, on_event, on_done, on_error)
        thread.start()
        return thread

    def delete_job(self, id_hash: str) -> Dict:
        """DELETE /jobs/<id_hash> — delete a job owned by the authenticated user."""
        url = f"{self.base_url}/jobs/{id_hash}"
        req = urllib.request.Request(url, headers=self._headers, method="DELETE")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def resubmit_job(self, id_hash: str) -> Dict:
        """POST /jobs/resubmit — reset job status to 'resubmitted' so OsmotiC picks it up again."""
        url  = f"{self.base_url}/jobs/resubmit"
        body = json.dumps({"job": {"hash": id_hash}}).encode("utf-8")
        req  = urllib.request.Request(url, data=body, headers=self._headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def abort_task(self, id_hash: str, task_name: str) -> None:
        """POST /jobs/tasks/{task_name}/abort — fire-and-forget signal to abort a running task."""
        url  = f"{self.base_url}/jobs/tasks/{task_name}/abort"
        body = json.dumps({"id_hash": id_hash}).encode("utf-8")
        req  = urllib.request.Request(url, data=body, headers=self._headers, method="POST")
        try:
            urllib.request.urlopen(req, timeout=30).close()
        except Exception:
            pass  # best-effort; next poll will confirm aborted state

    def remove_data(self, data_table: str) -> Dict:
        """DELETE /query/db-remove-data?data_table=... — drop table + metadata entry."""
        import urllib.parse
        qs  = urllib.parse.urlencode({"data_table": data_table})
        url = f"{self.base_url}/query/db-remove-data?{qs}"
        req = urllib.request.Request(url, headers=self._headers, method="DELETE")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_txt = exc.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(body_txt).get("msg", body_txt)
            except Exception:
                msg = body_txt or str(exc)
            raise RuntimeError(msg) from exc

    def raster_meta(self, data_table: str) -> Dict:
        """GET /query/raster-meta — returns {n_bands, timestamps} for a raster table."""
        import urllib.parse
        qs = urllib.parse.urlencode({"data_table": data_table})
        return self._get(f"/query/raster-meta?{qs}", timeout=30)

    def raster_band(self, data_table: str, band: int) -> bytes:
        """GET /query/raster-band — returns raw GeoTIFF bytes for one raster band."""
        import urllib.parse
        qs = urllib.parse.urlencode({"data_table": data_table, "band": band})
        return self._get_bytes(f"/query/raster-band?{qs}", timeout=60)

    def geom_column(self, data_table: str) -> str:
        """GET /query/geom-column — returns the geometry column name for a vector table."""
        import urllib.parse
        qs = urllib.parse.urlencode({"data_table": data_table})
        return self._get(f"/query/geom-column?{qs}").get("geom_column", "geom")

    def temporal_bounds(self, data_table: str, col: str) -> Dict:
        """GET /query/temporal-bounds — returns {start, end} for a timestamp column."""
        import urllib.parse
        qs = urllib.parse.urlencode({"data_table": data_table, "col": col})
        return self._get(f"/query/temporal-bounds?{qs}")

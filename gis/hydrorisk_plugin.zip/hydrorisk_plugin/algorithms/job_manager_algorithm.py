# -*- coding: utf-8 -*-
"""
Thin QgsProcessingAlgorithm wrapper that opens the HrJobWizard.
Guides the user through submitting a Hydrorisk.jl job.
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingAlgorithm

# Module-level reference keeps the wizard alive after processAlgorithm returns.
_active_wizard = None


class HrJobAlgorithm(QgsProcessingAlgorithm):
    """Opens the Job Manager."""

    def tr(self, string):
        return QCoreApplication.translate("Processing", string)

    def createInstance(self):
        return HrJobAlgorithm()

    def name(self):
        return "hydrorisk_job"

    def displayName(self):
        return self.tr("Job")

    def group(self):
        return self.tr("Manager")

    def groupId(self):
        return "hydrorisk_manager"

    def shortHelpString(self):
        return self.tr(
            "Opens a wizard that connects to a running Hydrorisk.jl server instance "
            "and guides you through submitting a simulation job.\n\n"
            "Steps:\n"
            "  1. Configure the API URL and bearer token\n"
            "  2. Choose to create a new job or base one on an existing job\n"
            "  3. Assign catalog datasets to each simulation input (DEM, land use, …)\n"
            "  4. Set run prefix, output folder, solver options, and export fields\n"
            "  5. Optionally restrict the spatial and temporal extent\n"
            "  6. Review the generated JSON and submit the job to the server"
        )

    def flags(self):
        from ..common.connection_store import store as _conn_store
        base = super().flags() | QgsProcessingAlgorithm.FlagNoThreading
        if not _conn_store.url:
            return base | QgsProcessingAlgorithm.FlagHideFromToolbox
        return base

    def initAlgorithm(self, config=None):
        pass

    def processAlgorithm(self, parameters, context, feedback):
        global _active_wizard
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.PyQt.QtCore import Qt
        from ..wizard.job_manager_wizard import HrJobWizard

        parent = QApplication.activeWindow()
        wizard = HrJobWizard(parent)
        wizard.setWindowModality(Qt.NonModal)
        wizard.setAttribute(Qt.WA_DeleteOnClose, True)
        wizard.destroyed.connect(lambda: globals().update(_active_wizard=None))
        _active_wizard = wizard
        wizard.show()
        wizard.raise_()
        wizard.activateWindow()
        return {}

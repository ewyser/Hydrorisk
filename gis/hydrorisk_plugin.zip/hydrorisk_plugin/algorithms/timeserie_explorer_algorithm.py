# -*- coding: utf-8 -*-
"""
Thin QgsProcessingAlgorithm wrapper that opens the Timeserie Explorer dialog.
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingAlgorithm

_active_dialog = None


class HrTimeserieExplorerAlgorithm(QgsProcessingAlgorithm):
    """Opens the interactive time-series band explorer."""

    def tr(self, string):
        return QCoreApplication.translate("Processing", string)

    def createInstance(self):
        return HrTimeserieExplorerAlgorithm()

    def name(self):
        return "hydrorisk_timeserie_explorer"

    def displayName(self):
        return self.tr("Timeserie Explorer")

    def group(self):
        return self.tr("Tools")

    def groupId(self):
        return "hydrorisk_tools"

    def shortHelpString(self):
        return self.tr(
            "Opens an interactive dialog to explore multiband time-series rasters "
            "stored in the Hydrorisk database.\n\n"
            "Features:\n"
            "  - Dataset selector (only datasets with temporal metadata)\n"
            "  - Band slider with prev/next navigation\n"
            "  - Timestamp label (start → end for the current band)\n"
            "  - Auto-play with configurable frame speed\n"
            "  - Color ramp selector\n"
            "  - Opacity control\n\n"
            "Each band is fetched on demand and rendered as a temporary raster "
            "layer in the QGIS canvas."
        )

    def flags(self):
        from ..common.connection_store import store as _conn_store
        base = super().flags() | QgsProcessingAlgorithm.FlagNoThreading
        if not _conn_store.url:
            return base | QgsProcessingAlgorithm.FlagHideFromToolbox
        return base

    def initAlgorithm(self, config=None):
        pass

    def processAlgorithm(self, parameters, context, feedback):
        global _active_dialog
        from qgis.PyQt.QtWidgets import QApplication
        from ..dialogs.timeserie_explorer_dialog import HrTimeserieExplorerDialog

        parent = QApplication.activeWindow()
        _active_dialog = HrTimeserieExplorerDialog(parent)
        _active_dialog.setWindowModality(False)   # non-blocking — user can pan map
        _active_dialog.show()
        _active_dialog.raise_()
        _active_dialog.activateWindow()
        return {}

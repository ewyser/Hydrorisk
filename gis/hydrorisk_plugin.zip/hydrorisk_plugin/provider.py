# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .algorithms.connection_algorithm import HrConnectionAlgorithm
from .algorithms.db_manager_algorithm import DbManagerAlgorithm
from .algorithms.job_manager_algorithm import HrJobAlgorithm
from .algorithms.runner_algorithm import HrRunnerAlgorithm
from .algorithms.timeserie_explorer_algorithm import HrTimeserieExplorerAlgorithm

class HydroriskProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(HrConnectionAlgorithm())
        self.addAlgorithm(DbManagerAlgorithm())
        self.addAlgorithm(HrJobAlgorithm())
        self.addAlgorithm(HrRunnerAlgorithm())
        self.addAlgorithm(HrTimeserieExplorerAlgorithm())

    def id(self):
        return "hydrorisk"

    def name(self):
        return "Hydrorisk"

    def longName(self):
        return "Hydrorisk – Hydrorisk.jl tools"

    def icon(self):
        return QgsProcessingProvider.icon(self)

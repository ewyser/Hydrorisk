# -*- coding: utf-8 -*-
"""
BaseConnectionPage — shared URL + token authentication page for all Hydrorisk wizards.

Usage
-----
Subclass and set title/subtitle in ``__init__``, then define ``nextId()`` when the
destination page is not the sequential next one.

Override ``_on_auth_success(client, result)`` for wizard-specific post-auth logic,
and ``_on_auth_reset()`` to react when credentials change and auth is cleared.

The ``self._api_form`` (QFormLayout) and ``self._conn_layout`` (QVBoxLayout) are
exposed so subclasses can append extra rows / widget groups.
"""
import os
import json
import urllib.error
from datetime import datetime

from qgis.PyQt.QtWidgets import (
    QWizardPage,
    QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QPushButton, QGroupBox,
)
from qgis.PyQt.QtCore import Qt

from ..common.api_client import HydroriskClient
from ..common.connection_store import store as _conn_store
from .groupboxes.api_groupbox import HrApiGroupBox

_DEFAULTS_PATH = os.path.join(
    os.path.dirname(__file__), "..", "wizard", "cfg_wizard_defaults.json"
)
with open(_DEFAULTS_PATH, encoding="utf-8") as _f:
    _DEFAULTS = json.load(_f)

_DEFAULT_URL   = _DEFAULTS["connection"]["default_url"]
_DEFAULT_TOKEN = _DEFAULTS["connection"]["default_token"]

_QGIS_CONN_NAME = "Hydrorisk"


def _remove_qgis_pg_connection() -> None:
    """Remove the Hydrorisk entry from QGIS's PostGIS connection registry."""
    try:
        from qgis.core import QgsSettings
        import qgis.utils
        QgsSettings().remove(f"PostgreSQL/connections/{_QGIS_CONN_NAME}")
        iface = qgis.utils.iface
        if iface is not None:
            iface.browserModel().reload()
    except Exception:
        pass


class BaseConnectionPage(QWizardPage):
    """
    Reusable URL + token authentication wizard page.

    Constructor keyword arguments
    -----------------------------
    use_defaults : bool
        When True (default), pre-fill URL and token from cfg_wizard_defaults.json.
        Set False to start with blank / generic defaults (e.g. task_manager).
    """

    def __init__(self, parent=None, *, use_defaults=True):
        super().__init__(parent)
        self._auth_ok = False

        # Prefer previously-used credentials; fall back to defaults
        default_url   = _conn_store.url   or (_DEFAULT_URL   if use_defaults else "http://localhost:8000")
        default_token = _conn_store.token or (_DEFAULT_TOKEN if use_defaults else "")

        # ── API credentials group ──────────────────────────────────────────
        api_group = HrApiGroupBox(default_url, default_token, parent=self)
        self._api_group    = api_group          # exposed so subclasses can toggle visibility
        self._api_form     = api_group._api_form
        self._url_edit     = api_group._url_edit
        self._token_edit   = api_group._token_edit
        self._token_toggle = api_group._token_toggle
        self._test_btn       = api_group._test_btn
        self._test_msg       = api_group._test_msg
        self._test_msg_extra = api_group._test_msg_extra

        # ── Compact session badge (shown instead of credentials when already connected) ──
        self._session_badge = QLabel()
        self._session_badge.setWordWrap(True)
        self._session_badge.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._session_badge.setStyleSheet(
            "color: green; padding: 6px; border: 1px solid #b2dfdb; "
            "border-radius: 4px; background: #e8f5e9;"
        )
        self._session_badge.hide()

        # Main layout — subclasses append further groups / stretch to this
        self._conn_layout = QVBoxLayout(self)
        self._conn_layout.addWidget(self._session_badge)
        self._conn_layout.addWidget(api_group)

        self._test_btn.clicked.connect(self._test_connection)
        self._url_edit.textChanged.connect(self._reset_auth)
        self._token_edit.textChanged.connect(self._reset_auth)

    # ------------------------------------------------------------------
    # Auto-test on page open when stored credentials are already filled in

    def initializePage(self):
        url   = self._url_edit.text().strip()
        token = self._token_edit.text().strip()
        if url and token and url == _conn_store.url and token == _conn_store.token:
            self._test_connection()
        self._update_session_badge()

    def _update_session_badge(self):
        """Show compact badge and hide credentials form when store has a live session."""
        if _conn_store.url and self._auth_ok:
            text = _conn_store.badge or "  ·  ".join(
                p for p in [
                    f"✅  {_conn_store.username or _conn_store.url}",
                    _conn_store.msg_extra,
                ] if p
            )
            self._session_badge.setText(text)
            self._session_badge.show()
            self._api_group.hide()
        else:
            self._session_badge.hide()
            self._api_group.show()

    # ------------------------------------------------------------------
    # Extension hooks

    def _on_auth_success(self, client, result: dict):
        """Called immediately after a successful connection test. Override to add behaviour."""

    def _on_auth_reset(self):
        """Called when credentials change and auth state is cleared. Override to react."""

    # ------------------------------------------------------------------
    # Core logic (not intended for override)

    def _reset_auth(self):
        if self._auth_ok:
            self._auth_ok = False
            self._test_msg.setText("")
            self._test_msg.setStyleSheet("")
            self._test_msg_extra.setText("")
            _conn_store.username     = ""
            _conn_store.badge        = ""
            _conn_store.msg_extra    = ""
            _conn_store.connected_at = None
            _conn_store.db_host      = ""
            _conn_store.db_port      = 5432
            _conn_store.db_name      = ""
            _conn_store.pg_user      = ""
            _conn_store.pg_password  = ""
            _remove_qgis_pg_connection()
            self._on_auth_reset()
            self._update_session_badge()
            self.completeChanged.emit()

    def _test_connection(self):
        try:
            client = self._make_client()
            result = client.check_auth()
            self._test_msg.setText(result.get("msg") or str(result))
            self._test_msg.setStyleSheet("color: green;")
            extra = result.get("msg_extra", "") or ""
            self._test_msg_extra.setText(extra)
            self._auth_ok = True
            _conn_store.url          = self._url_edit.text().strip()
            _conn_store.token        = self._token_edit.text().strip()
            _conn_store.username     = result.get("user", {}).get("name", "")
            _conn_store.badge        = result.get("badge", "") or ""
            _conn_store.msg_extra    = result.get("msg_extra", "") or ""
            _conn_store.connected_at = datetime.now()
            # Store direct DB credentials returned by /auth.
            # These are used exclusively for QgsDataSourceUri (QGIS layer rendering).
            db = result.get("db") or {}
            _conn_store.db_host     = db.get("host", "")
            _conn_store.db_port     = int(db.get("port", 5432))
            _conn_store.db_name     = db.get("name", "")
            _conn_store.pg_user     = db.get("pg_user", "")
            _conn_store.pg_password = db.get("pg_password", "")
            if _conn_store.pg_user:
                _remove_qgis_pg_connection()  # clean up any previously registered connection
            self._on_auth_success(client, result)
            self._update_session_badge()
        except urllib.error.URLError as exc:
            self._test_msg.setText(f"❌  {exc.reason}")
            self._test_msg.setStyleSheet("color: red;")
            self._test_msg_extra.setText("")
            self._auth_ok = False
        except Exception as exc:
            self._test_msg.setText(str(exc))
            self._test_msg.setStyleSheet("color: red;")
            self._test_msg_extra.setText("")
            self._auth_ok = False
        self.completeChanged.emit()

    def _make_client(self):
        return HydroriskClient(
            self._url_edit.text().strip(),
            self._token_edit.text().strip(),
        )

    def api_url(self):   return self._url_edit.text().strip()
    def api_token(self): return self._token_edit.text().strip()
    def client(self):    return self._make_client()

    def isComplete(self):
        return self._auth_ok

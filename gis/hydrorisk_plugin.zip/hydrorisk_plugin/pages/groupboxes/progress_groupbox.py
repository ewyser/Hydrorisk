# -*- coding: utf-8 -*-
"""
HrProgressGroupBox — per-task progress bars + job status info group box.

The list of task names is passed at construction so this box is not
coupled to a specific set of pipeline stages.

Exposes:
    _status_val     QLabel
    _created_val    QLabel
    _done_val       QLabel
    _task_widgets   dict[name → {bar, step, status, abort}]
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QProgressBar, QWidget,
)
from qgis.PyQt.QtCore import Qt


class HrProgressGroupBox(QGroupBox):
    def __init__(self, task_names: list, parent=None):
        super().__init__("Tasks", parent)
        vbox = QVBoxLayout(self)

        # Hidden labels kept for monitor_page.py compatibility
        self._status_val  = QLabel("—")
        self._status_val.setTextFormat(Qt.RichText)
        self._created_val = QLabel("—")
        self._done_val    = QLabel("—")

        self._task_widgets = {}
        tasks_vbox = QVBoxLayout()
        tasks_vbox.setSpacing(4)
        for task_name in task_names:
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(0)
            bar.setFixedHeight(14)
            bar.setTextVisible(True)

            step_lbl = QLabel("—")
            step_lbl.setStyleSheet("color: gray; font-size: 10px;")

            status_lbl = QLabel("—")
            status_lbl.setStyleSheet("color: gray; font-weight: bold;")
            status_lbl.setFixedWidth(80)

            abort_btn = QPushButton("✕")
            abort_btn.setFixedSize(20, 20)
            abort_btn.setToolTip(f"Abort {task_name}")
            abort_btn.setEnabled(False)

            name_lbl = QLabel(f"{task_name}:")
            name_lbl.setFixedWidth(100)

            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.addWidget(abort_btn)
            row.addWidget(name_lbl)
            row.addWidget(status_lbl)
            row.addWidget(bar,        3)
            row.addWidget(step_lbl,   4)

            row_widget = QWidget()
            row_widget.setLayout(row)
            tasks_vbox.addWidget(row_widget)

            self._task_widgets[task_name] = {
                "bar": bar, "step": step_lbl,
                "status": status_lbl, "abort": abort_btn,
                "row": row_widget,
            }
        vbox.addLayout(tasks_vbox)

# -*- coding: utf-8 -*-
"""
HrConnectionWizard — standalone single-page wizard for the global connection step.

Opened by HrConnectionAlgorithm before the user can access any other module.
On success the credentials are saved into connection_store and the Processing
provider refreshes so the other algorithms become visible in the toolbox.
"""
from qgis.PyQt.QtWidgets import QWizard, QGroupBox, QVBoxLayout, QPushButton, QLabel
from qgis.PyQt.QtCore import QSize
from qgis.PyQt.QtGui import QFont

from ..pages.connection_page import BaseConnectionPage
from ..common.connection_store import store as _conn_store


# ─────────────────────────────────────────────────────────────────────────────
# Sole page
# ─────────────────────────────────────────────────────────────────────────────

class _ConnectionPage(BaseConnectionPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Connect to Hydrorisk server")
        self.setSubTitle(
            "Enter the server address and authentication token.\n"
            "A successful connection is required to unlock the other tools."
        )

        # ── Disconnect section (shown only when already connected) ─────────
        self._disconnect_box = QGroupBox("Active session")
        disc_layout = QVBoxLayout(self._disconnect_box)

        self._session_label = QLabel()
        self._session_label.setWordWrap(True)
        disc_layout.addWidget(self._session_label)

        self._badge_label = QLabel()
        self._badge_label.setWordWrap(True)
        self._badge_label.setStyleSheet(
            "padding: 4px 8px; color: #1b5e20; "
            "background: #e8f5e9; border-radius: 4px; border: 1px solid #a5d6a7;"
        )
        disc_layout.addWidget(self._badge_label)

        self._disconnect_btn = QPushButton("🔌  Disconnect")
        font = QFont()
        font.setBold(True)
        self._disconnect_btn.setFont(font)
        self._disconnect_btn.setStyleSheet("color: red;")
        self._disconnect_btn.clicked.connect(self._do_disconnect)
        disc_layout.addWidget(self._disconnect_btn)

        self._conn_layout.addWidget(self._disconnect_box)
        self._conn_layout.addStretch()

        self._refresh_disconnect_box()

    # ------------------------------------------------------------------

    def initializePage(self):
        self._refresh_disconnect_box()
        super().initializePage()

    def _on_auth_success(self, client, result):
        self._refresh_disconnect_box()

    def _on_auth_reset(self):
        self._refresh_disconnect_box()

    def _refresh_disconnect_box(self):
        connected = bool(_conn_store.url)
        self._disconnect_box.setVisible(connected)
        if connected:
            badge = _conn_store.badge or f"✅  {_conn_store.username or _conn_store.url}"
            self._badge_label.setText(badge)
            ts = (
                _conn_store.connected_at.strftime("%Y-%m-%d  %H:%M:%S")
                if _conn_store.connected_at else "—"
            )
            lines = [
                f"<b>Server:</b>  {_conn_store.url}",
                f"<b>User:</b>  {_conn_store.username or '—'}",
                f"<b>Connected at:</b>  {ts}",
            ]
            if _conn_store.msg_extra:
                lines.append(f"<b>Stats:</b>  {_conn_store.msg_extra}")
            self._session_label.setText("<br>".join(lines))
        # Hide the API credentials group when already connected
        self._api_group.setVisible(not connected)

    def _do_disconnect(self):
        from ..pages.connection_page import _remove_qgis_pg_connection
        _conn_store.url          = ""
        _conn_store.token        = ""
        _conn_store.username     = ""
        _conn_store.badge        = ""
        _conn_store.msg_extra    = ""
        _conn_store.connected_at = None
        _conn_store.db_host      = ""
        _conn_store.db_port      = 5432
        _conn_store.db_name      = ""
        _conn_store.pg_user      = ""
        _conn_store.pg_password  = ""
        _remove_qgis_pg_connection()
        self._refresh_disconnect_box()
        self.completeChanged.emit()
        # Close the wizard; the algorithm will call refreshAlgorithms()
        self.wizard().reject()

    def nextId(self):
        return -1   # only page → Finish button

    def _update_session_badge(self):
        # Visibility is managed by _refresh_disconnect_box in this wizard
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Wizard
# ─────────────────────────────────────────────────────────────────────────────

class HrConnectionWizard(QWizard):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hydrorisk — Connection")
        self.setMinimumSize(QSize(520, 320))
        self.setWizardStyle(QWizard.ModernStyle)
        self.setOption(QWizard.NoBackButtonOnStartPage, True)

        self.setPage(0, _ConnectionPage(self))

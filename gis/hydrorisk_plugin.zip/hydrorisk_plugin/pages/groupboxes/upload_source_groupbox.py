# -*- coding: utf-8 -*-
"""
HrUploadSourceGroupBox — file/layer picker + category selector group box.

Supports two source modes:
  - File / Layer : pick a single spatial file or an existing QGIS layer
  - Folder       : pick a directory whose contents will be zipped and imported
                   as a multiband raster dataset

Does NOT install the _DropFilter (that requires a parent widget reference);
the page is responsible for attaching it to _path_combo.lineEdit().

Exposes:
    _path_combo             QComboBox  (editable — used for file path in file mode)
    _browse_btn             QPushButton
    _refresh_layers_btn     QPushButton
    _browse_folder_btn      QPushButton (visible only in folder mode)
    _category_combo         QComboBox
    _fetch_cats_btn         QPushButton
    is_folder_mode()        bool
    source_type_changed     pyqtSignal
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QFormLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QRadioButton, QButtonGroup, QWidget,
)
from qgis.PyQt.QtCore import pyqtSignal


class HrUploadSourceGroupBox(QGroupBox):

    source_type_changed = pyqtSignal(bool)  # True = folder mode

    def __init__(self, parent=None):
        super().__init__("Source", parent)
        form = QFormLayout(self)

        # ── Source type selector ──────────────────────────────────────────
        self._radio_file   = QRadioButton("File / Layer")
        self._radio_folder = QRadioButton("Folder (multiband raster)")
        self._radio_file.setChecked(True)

        self._type_group = QButtonGroup(self)
        self._type_group.addButton(self._radio_file,   0)
        self._type_group.addButton(self._radio_folder, 1)

        type_row = QHBoxLayout()
        type_row.setContentsMargins(0, 0, 0, 0)
        type_row.addWidget(self._radio_file)
        type_row.addWidget(self._radio_folder)
        type_row.addStretch()
        form.addRow("Source type:", type_row)

        # ── Path / layer row ──────────────────────────────────────────────
        self._path_combo = QComboBox()
        self._path_combo.setEditable(True)
        self._path_combo.setInsertPolicy(QComboBox.NoInsert)
        self._path_combo.lineEdit().setPlaceholderText(
            " drag & drop file [here] / folder browser → / drop-down QGIS layer ↓"
        )
        le = self._path_combo.lineEdit()
        le.setAcceptDrops(True)

        self._browse_btn = QPushButton("📂")
        self._browse_btn.setFixedWidth(32)
        self._browse_btn.setToolTip("Browse for a file")

        self._refresh_layers_btn = QPushButton("↻")
        self._refresh_layers_btn.setFixedWidth(30)
        self._refresh_layers_btn.setToolTip("Refresh QGIS layer list")

        self._browse_folder_btn = QPushButton("📁")
        self._browse_folder_btn.setFixedWidth(32)
        self._browse_folder_btn.setToolTip("Browse for a folder")
        self._browse_folder_btn.setVisible(False)

        path_row = QHBoxLayout()
        path_row.setContentsMargins(0, 0, 0, 0)
        path_row.addWidget(self._path_combo,         1)
        path_row.addWidget(self._browse_btn)
        path_row.addWidget(self._refresh_layers_btn)
        path_row.addWidget(self._browse_folder_btn)
        form.addRow("Source:", path_row)

        # ── Category row (file mode) ──────────────────────────────────────
        self._category_combo = QComboBox()
        self._fetch_cats_btn = QPushButton("↻")
        self._fetch_cats_btn.setFixedWidth(30)
        self._fetch_cats_btn.setToolTip("Fetch categories from API")

        self._cat_widget = QWidget()
        cat_layout = QHBoxLayout(self._cat_widget)
        cat_layout.setContentsMargins(0, 0, 0, 0)
        cat_layout.addWidget(self._category_combo, 1)
        cat_layout.addWidget(self._fetch_cats_btn)
        self._cat_label = QLabel("Category:")
        form.addRow(self._cat_label, self._cat_widget)

        # ── Product row (folder mode) ─────────────────────────────────────
        self._product_combo = QComboBox()
        self._fetch_prods_btn = QPushButton("↻")
        self._fetch_prods_btn.setFixedWidth(30)
        self._fetch_prods_btn.setToolTip("Fetch products from API")

        self._prod_widget = QWidget()
        prod_layout = QHBoxLayout(self._prod_widget)
        prod_layout.setContentsMargins(0, 0, 0, 0)
        prod_layout.addWidget(self._product_combo, 1)
        prod_layout.addWidget(self._fetch_prods_btn)
        self._prod_label = QLabel("Product:")
        form.addRow(self._prod_label, self._prod_widget)
        self._prod_label.setVisible(False)
        self._prod_widget.setVisible(False)

        # ── Connect mode toggle ───────────────────────────────────────────
        self._type_group.idToggled.connect(self._on_type_toggled)

        # Folder mode is always available — user selects manually

    def is_folder_mode(self) -> bool:
        return self._radio_folder.isChecked()

    def set_folder_available(self, available: bool):
        """Show or hide the Folder radio button based on the selected category.

        When the folder option is hidden the widget resets to file mode so no
        stale state is carried forward.
        """
        self._radio_folder.setVisible(available)
        if not available and self._radio_folder.isChecked():
            self._radio_file.setChecked(True)

    def _on_type_toggled(self, btn_id, checked):
        if not checked:
            return
        folder = btn_id == 1
        self._browse_folder_btn.setVisible(folder)
        self._browse_btn.setVisible(not folder)
        self._refresh_layers_btn.setVisible(not folder)
        self._cat_label.setVisible(not folder)
        self._cat_widget.setVisible(not folder)
        self._prod_label.setVisible(folder)
        self._prod_widget.setVisible(folder)
        placeholder = (
            " browse for a folder →"
            if folder else
            " drag & drop file [here] / folder browser → / drop-down QGIS layer ↓"
        )
        self._path_combo.lineEdit().setPlaceholderText(placeholder)
        self.source_type_changed.emit(folder)


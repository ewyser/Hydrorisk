# -*- coding: utf-8 -*-
"""
HrLogGroupBox — read-only monospaced log output group box.

Exposes:
    _log    QTextEdit
"""
from qgis.PyQt.QtWidgets import QGroupBox, QVBoxLayout, QTextEdit, QSizePolicy
from qgis.PyQt.QtGui import QFont


class HrLogGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Log", parent)
        vbox = QVBoxLayout(self)

        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setFont(QFont("Courier", 9))
        self._log.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        vbox.addWidget(self._log)

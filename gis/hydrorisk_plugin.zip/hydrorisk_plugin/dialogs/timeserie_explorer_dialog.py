# -*- coding: utf-8 -*-
"""
HrTimeserieExplorerDialog — interactive time-series band explorer.

Fetches raster band metadata and pixel data via the Hydrorisk API,
renders each band as a temporary QgsRasterLayer in the QGIS canvas with a user-selected
color ramp and opacity, and lets the user navigate bands via slider, prev/next
buttons, or auto-play.
"""
import json

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QComboBox, QSlider, QPushButton,
    QGroupBox, QSizePolicy, QSpinBox, QDoubleSpinBox, QCheckBox,
)
from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QFont

from ..common.connection_store import make_client as _make_client, store as _conn_store
# _conn_store used only for token-presence check (connection guard)


# VSIMEM path reused across band loads — avoids accumulating temp files
_VSIMEM_PATH = "/vsimem/hr_ts_explorer.tif"
# Layer name displayed in the QGIS layer panel
_LAYER_NAME  = "TS Explorer"


class HrTimeserieExplorerDialog(QDialog):
    """
    Dialog with:
      - Dataset selector (only datasets with timestamps)
      - Band slider + prev/next buttons + index label
      - Timestamp label (start → end for current band)
      - Auto-play with configurable speed
      - Color ramp selector
      - Opacity slider
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Timeserie Explorer")
        self.setMinimumWidth(520)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)

        self._datasets         = []   # list of dataset dicts
        self._timestamps       = []   # list of {"start": ..., "end": ...}
        self._rids             = []   # actual rid values for each navigable band
        self._n_bands          = 0
        self._current          = 1    # 1-based band index
        self._temp_layer       = None
        self._timer            = QTimer(self)
        self._timer.timeout.connect(self._auto_step)

        self._build_ui()
        self._load_datasets()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(8)

        # ── Dataset selection ─────────────────────────────────────────
        ds_group  = QGroupBox("Dataset")
        ds_form   = QFormLayout(ds_group)
        self._ds_combo = QComboBox()
        self._ds_combo.currentIndexChanged.connect(self._on_dataset_changed)
        ds_form.addRow("Dataset:", self._ds_combo)
        self._ds_status = QLabel("Loading…")
        self._ds_status.setStyleSheet("color: gray;")
        ds_form.addRow("", self._ds_status)
        root.addWidget(ds_group)

        # ── Band navigation ───────────────────────────────────────────
        nav_group  = QGroupBox("Navigation")
        nav_layout = QVBoxLayout(nav_group)

        # Timestamp display
        self._ts_label = QLabel("—")
        self._ts_label.setAlignment(Qt.AlignCenter)
        bold = QFont()
        bold.setBold(True)
        self._ts_label.setFont(bold)
        nav_layout.addWidget(self._ts_label)

        # Slider row
        slider_row = QHBoxLayout()
        self._btn_prev = QPushButton("◀")
        self._btn_prev.setFixedWidth(32)
        self._btn_prev.clicked.connect(self._go_prev)
        self._slider = QSlider(Qt.Horizontal)
        self._slider.setMinimum(1)
        self._slider.setMaximum(1)
        self._slider.setValue(1)
        self._slider.setTracking(False)
        self._slider.valueChanged.connect(self._on_slider_changed)
        self._btn_next = QPushButton("▶")
        self._btn_next.setFixedWidth(32)
        self._btn_next.clicked.connect(self._go_next)
        self._band_label = QLabel("1 / 1")
        self._band_label.setFixedWidth(60)
        self._band_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        slider_row.addWidget(self._btn_prev)
        slider_row.addWidget(self._slider, 1)
        slider_row.addWidget(self._btn_next)
        slider_row.addWidget(self._band_label)
        nav_layout.addLayout(slider_row)

        # Auto-play row
        play_row = QHBoxLayout()
        self._btn_play = QPushButton("▶  Play")
        self._btn_play.setCheckable(True)
        self._btn_play.toggled.connect(self._on_play_toggled)
        play_row.addWidget(self._btn_play)
        play_row.addWidget(QLabel("Speed:"))
        self._speed_spin = QSpinBox()
        self._speed_spin.setRange(100, 5000)
        self._speed_spin.setValue(500)
        self._speed_spin.setSuffix(" ms/frame")
        self._speed_spin.setSingleStep(100)
        self._speed_spin.valueChanged.connect(self._on_speed_changed)
        play_row.addWidget(self._speed_spin)
        play_row.addStretch()
        nav_layout.addLayout(play_row)
        root.addWidget(nav_group)

        # ── Display settings ──────────────────────────────────────────
        disp_group = QGroupBox("Display")
        disp_form  = QFormLayout(disp_group)

        self._ramp_combo = QComboBox()
        self._ramp_combo.addItems(self._available_ramps())
        default_idx = self._ramp_combo.findText("Blues")
        if default_idx >= 0:
            self._ramp_combo.setCurrentIndex(default_idx)
        self._ramp_combo.currentIndexChanged.connect(self._refresh_renderer)
        disp_form.addRow("Color ramp:", self._ramp_combo)

        # Min / Max range
        self._auto_check = QCheckBox("Auto")
        self._auto_check.setChecked(False)
        self._auto_check.toggled.connect(self._on_auto_changed)
        self._min_spin = QDoubleSpinBox()
        self._min_spin.setRange(-1e9, 1e9)
        self._min_spin.setDecimals(4)
        self._min_spin.setValue(0.0)
        self._min_spin.setEnabled(True)
        self._min_spin.valueChanged.connect(self._refresh_renderer)
        self._max_spin = QDoubleSpinBox()
        self._max_spin.setRange(-1e9, 1e9)
        self._max_spin.setDecimals(4)
        self._max_spin.setValue(1.0)
        self._max_spin.setEnabled(True)
        self._max_spin.valueChanged.connect(self._refresh_renderer)
        self._sym_check = QCheckBox("Symmetric")
        self._sym_check.setChecked(False)
        self._sym_check.toggled.connect(self._on_sym_changed)
        minmax_row = QHBoxLayout()
        minmax_row.addWidget(self._auto_check)
        minmax_row.addWidget(self._sym_check)
        minmax_row.addWidget(QLabel("Min:"))
        minmax_row.addWidget(self._min_spin)
        minmax_row.addWidget(QLabel("Max:"))
        minmax_row.addWidget(self._max_spin)
        disp_form.addRow("Range:", minmax_row)

        self._opacity_slider = QSlider(Qt.Horizontal)
        self._opacity_slider.setRange(10, 100)
        self._opacity_slider.setValue(80)
        self._opacity_slider.setTracking(True)
        self._opacity_slider.valueChanged.connect(self._on_opacity_changed)
        self._opacity_label = QLabel("80 %")
        self._opacity_label.setFixedWidth(40)
        opacity_row = QHBoxLayout()
        opacity_row.addWidget(self._opacity_slider, 1)
        opacity_row.addWidget(self._opacity_label)
        disp_form.addRow("Opacity:", opacity_row)

        self._transp_zero_check = QCheckBox("Transparent zeros")
        self._transp_zero_check.setChecked(True)
        self._transp_zero_check.toggled.connect(self._refresh_renderer)
        disp_form.addRow("", self._transp_zero_check)

        root.addWidget(disp_group)

        # ── Error display ─────────────────────────────────────────────
        self._error_label = QLabel("")
        self._error_label.setStyleSheet("color: red;")
        self._error_label.setWordWrap(True)
        root.addWidget(self._error_label)

        self._set_controls_enabled(False)

    # ------------------------------------------------------------------
    # Dataset loading
    # ------------------------------------------------------------------

    def _load_datasets(self):
        try:
            catalog = _make_client().db_data_catalog()
            all_ds = [
                ds
                for datasets in catalog.get("data", {}).values()
                for ds in (datasets if isinstance(datasets, list) else datasets.values())
                if ds.get("format") == "raster" and ds.get("has_timeseries")
            ]
            self._datasets = all_ds
        except Exception as exc:
            self._ds_status.setText(f"❌  {exc}")
            self._ds_status.setStyleSheet("color: red;")
            return

        self._ds_combo.blockSignals(True)
        self._ds_combo.clear()
        if not self._datasets:
            self._ds_status.setText("No time-series raster datasets found in catalog.")
            self._ds_status.setStyleSheet("color: orange;")
        else:
            for ds in self._datasets:
                label = ds.get("name") or ds.get("data_table", "?")
                self._ds_combo.addItem(label, ds)
            self._ds_status.setText(f"{len(self._datasets)} raster dataset(s) available.")
            self._ds_status.setStyleSheet("color: green;")
        self._ds_combo.blockSignals(False)
        if self._datasets:
            self._on_dataset_changed(0)

    def _on_dataset_changed(self, _index):
        ds = self._ds_combo.currentData()
        if ds is None:
            return
        data_table = ds.get("data_table", "")
        self._ds_status.setText("Fetching band metadata…")
        self._ds_status.setStyleSheet("color: gray;")
        self._set_controls_enabled(False)
        try:
            self._n_bands, self._timestamps, self._rids = self._fetch_meta_from_db(data_table)
        except Exception as exc:
            self._ds_status.setText(f"❌  {exc}")
            self._ds_status.setStyleSheet("color: red;")
            return
        if self._n_bands == 0:
            self._ds_status.setText("Dataset has no bands.")
            self._ds_status.setStyleSheet("color: orange;")
            return
        self._slider.setMaximum(self._n_bands)
        self._slider.setValue(1)
        self._current = 1
        self._set_controls_enabled(True)
        self._ds_status.setText(f"{self._n_bands} band(s) — use slider to navigate.")
        self._ds_status.setStyleSheet("color: green;")
        self._update_labels()
        self._load_band(1)

    def _fetch_meta_from_db(self, data_table: str):
        """Fetch n_bands, timestamps, and rids via the Hydrorisk API."""
        if not _conn_store.token:
            raise RuntimeError("No active session — please connect first.")
        result = _make_client().raster_meta(data_table)
        n_bands    = result.get("n_bands", 0) or 0
        timestamps = result.get("timestamps", []) or []
        rids       = result.get("rids", []) or []
        return n_bands, timestamps, rids

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _go_prev(self):
        if self._current > 1:
            self._go_to(self._current - 1)

    def _go_next(self):
        if self._current < self._n_bands:
            self._go_to(self._current + 1)

    def _on_slider_changed(self, value: int):
        if value != self._current:
            self._go_to(value)

    def _go_to(self, band: int):
        self._current = band
        self._slider.blockSignals(True)
        self._slider.setValue(band)
        self._slider.blockSignals(False)
        self._update_labels()
        self._load_band(band)

    def _update_labels(self):
        self._band_label.setText(f"{self._current} / {self._n_bands}")
        if self._timestamps and self._current <= len(self._timestamps):
            ts    = self._timestamps[self._current - 1]
            start = ts.get("start") or ""
            end   = ts.get("end")   or ""
            if start and end and start != end:
                ts_str = f"{start} → {end}"
            else:
                ts_str = start or end or ""
            if ts_str:
                self._ts_label.setText(f"Band {self._current}: {ts_str}")
            else:
                self._ts_label.setText(f"Band {self._current} / {self._n_bands}")
        else:
            self._ts_label.setText(f"Band {self._current} / {self._n_bands}")

    # ------------------------------------------------------------------
    # Auto-play
    # ------------------------------------------------------------------

    def _on_play_toggled(self, playing: bool):
        if playing:
            self._btn_play.setText("⏹  Stop")
            self._timer.start(self._speed_spin.value())
        else:
            self._timer.stop()
            self._btn_play.setText("▶  Play")

    def _on_speed_changed(self, ms: int):
        if self._timer.isActive():
            self._timer.setInterval(ms)

    def _auto_step(self):
        nxt = self._current + 1
        if nxt > self._n_bands:
            nxt = 1  # loop back to start
        self._go_to(nxt)

    # ------------------------------------------------------------------
    # Band fetching + QGIS layer rendering
    # ------------------------------------------------------------------

    def _load_band(self, band: int):
        """Fetch one raster band directly from PostgreSQL and render it."""
        ds = self._ds_combo.currentData()
        if ds is None:
            return
        data_table = ds.get("data_table", "")
        self._error_label.setText("")
        # Resolve the 1-based band index to the actual rid in the database
        rid = self._rids[band - 1] if self._rids and 0 < band <= len(self._rids) else band
        try:
            self._fetch_band_to_vsimem(data_table, rid)
        except Exception as exc:
            self._error_label.setText(f"❌  {exc}")
            return
        self._render_from_path(_VSIMEM_PATH)

    def _fetch_band_to_vsimem(self, data_table: str, band: int):
        """Fetch GeoTIFF bytes for one raster band via the Hydrorisk API and write to /vsimem/."""
        if not _conn_store.token:
            raise RuntimeError("No active session — please connect via the Hydrorisk wizard first.")
        from osgeo import gdal
        tiff_bytes = _make_client().raster_band(data_table, band)
        if not tiff_bytes:
            raise ValueError(f"No data returned for table '{data_table}' band {band}")
        vsi_file = gdal.VSIFOpenL(_VSIMEM_PATH, "wb")
        gdal.VSIFWriteL(tiff_bytes, 1, len(tiff_bytes), vsi_file)
        gdal.VSIFCloseL(vsi_file)

    def _render_from_path(self, path: str):
        """Load a raster file/vsimem path as a temporary QgsRasterLayer."""
        from qgis.core import (
            QgsRasterLayer, QgsProject,
            QgsSingleBandPseudoColorRenderer, QgsColorRampShader,
            QgsRasterShader, QgsStyle,
        )
        if self._temp_layer is not None:
            try:
                QgsProject.instance().removeMapLayer(self._temp_layer.id())
            except Exception:
                pass
            self._temp_layer = None

        layer = QgsRasterLayer(path, _LAYER_NAME)
        if not layer.isValid():
            self._error_label.setText("❌  Could not load raster band.")
            return

        self._apply_renderer(layer)
        layer.setOpacity(self._opacity_slider.value() / 100.0)
        # Preserve the current map extent before adding the layer so QGIS
        # does not zoom to the raster extent and discard the user's view.
        from qgis.utils import iface
        canvas = iface.mapCanvas()
        saved_extent = canvas.extent()
        has_extent = saved_extent and not saved_extent.isNull() and not saved_extent.isEmpty()
        QgsProject.instance().addMapLayer(layer)
        if has_extent:
            canvas.setExtent(saved_extent)
        canvas.refresh()
        self._temp_layer = layer

    def _apply_renderer(self, layer):
        from qgis.core import (
            QgsSingleBandPseudoColorRenderer, QgsColorRampShader,
            QgsRasterShader, QgsStyle,
        )
        ramp_name = self._ramp_combo.currentText()
        style     = QgsStyle.defaultStyle()
        ramp      = style.colorRamp(ramp_name)
        if ramp is None:
            return  # unknown ramp — leave default

        if self._auto_check.isChecked():
            stats = layer.dataProvider().bandStatistics(1)
            vmin  = stats.minimumValue
            vmax  = stats.maximumValue
        else:
            vmin = self._min_spin.value()
            vmax = self._max_spin.value()

        if self._sym_check.isChecked():
            absmax = max(abs(vmin), abs(vmax))
            vmin   = -absmax
            vmax   =  absmax

        self._min_spin.blockSignals(True)
        self._max_spin.blockSignals(True)
        self._min_spin.setValue(vmin)
        self._max_spin.setValue(vmax)
        self._min_spin.blockSignals(False)
        self._max_spin.blockSignals(False)

        shader = QgsColorRampShader(vmin, vmax, ramp)
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.classifyColorRamp(classes=10)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)

        from qgis.core import QgsRasterTransparency
        transp = QgsRasterTransparency()
        if self._transp_zero_check.isChecked():
            pixel = QgsRasterTransparency.TransparentSingleValuePixel()
            pixel.min = 0.0
            pixel.max = 0.0
            pixel.percentTransparent = 100.0
            transp.setTransparentSingleValuePixelList([pixel])
        renderer.setRasterTransparency(transp)

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def _on_auto_changed(self, checked: bool):
        self._min_spin.setEnabled(not checked and not self._sym_check.isChecked())
        self._max_spin.setEnabled(not checked)
        self._refresh_renderer()

    def _on_sym_changed(self, checked: bool):
        # Min is always derived when symmetric is on
        self._min_spin.setEnabled(not checked and not self._auto_check.isChecked())
        # Lock/unlock the color ramp to RdBu for diverging palettes
        if checked:
            self._saved_ramp = self._ramp_combo.currentText()
            idx = self._ramp_combo.findText("RdBu")
            if idx >= 0:
                self._ramp_combo.setCurrentIndex(idx)
            self._ramp_combo.setEnabled(False)
        else:
            self._ramp_combo.setEnabled(True)
            if hasattr(self, "_saved_ramp"):
                idx = self._ramp_combo.findText(self._saved_ramp)
                if idx >= 0:
                    self._ramp_combo.setCurrentIndex(idx)
        self._refresh_renderer()

    def _refresh_renderer(self):
        if self._temp_layer is not None:
            self._apply_renderer(self._temp_layer)
            self._temp_layer.triggerRepaint()

    def _on_opacity_changed(self, value: int):
        self._opacity_label.setText(f"{value} %")
        if self._temp_layer is not None:
            self._temp_layer.setOpacity(value / 100.0)
            self._temp_layer.triggerRepaint()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _set_controls_enabled(self, enabled: bool):
        for w in (self._slider, self._btn_prev, self._btn_next,
                  self._btn_play, self._speed_spin):
            w.setEnabled(enabled)

    @staticmethod
    def _available_ramps() -> list:
        """Return color ramp names from the default QGIS style."""
        try:
            from qgis.core import QgsStyle
            names = QgsStyle.defaultStyle().colorRampNames()
            return sorted(names) if names else _FALLBACK_RAMPS
        except Exception:
            return _FALLBACK_RAMPS

    # ------------------------------------------------------------------
    # Cleanup on close
    # ------------------------------------------------------------------

    def closeEvent(self, event):
        self._timer.stop()
        self._cleanup_layer()
        # Release /vsimem/ buffer
        try:
            from osgeo import gdal
            gdal.Unlink(_VSIMEM_PATH)
        except Exception:
            pass
        super().closeEvent(event)

    def _cleanup_layer(self):
        """Remove the TS Explorer layer from the QGIS project and refresh the canvas."""
        from qgis.core import QgsProject
        project = QgsProject.instance()

        # Primary: remove by tracked object ID
        if self._temp_layer is not None:
            layer_id = self._temp_layer.id()
            self._temp_layer = None
            if project.mapLayer(layer_id) is not None:
                project.removeMapLayer(layer_id)

        # Fallback: sweep by name in case a previous instance was orphaned
        for layer in project.mapLayersByName(_LAYER_NAME):
            project.removeMapLayer(layer.id())

        # Refresh the canvas so the raster disappears immediately
        try:
            from qgis.utils import iface
            iface.mapCanvas().refresh()
        except Exception:
            pass


_FALLBACK_RAMPS = [
    "Blues", "Greens", "Reds", "RdYlBu", "Viridis", "Plasma",
    "Magma", "Inferno", "Spectral", "YlOrRd",
]

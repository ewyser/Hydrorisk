# -*- coding: utf-8 -*-
"""
HrSpatialExtentGroupBox — spatial extent selector group box.

Exposes:
    _spatial_cb     QCheckBox
    _extent         QgsExtentWidget
"""
from qgis.PyQt.QtWidgets import QGroupBox, QFormLayout, QCheckBox
from qgis.gui import QgsExtentWidget
from qgis.utils import iface


class HrSpatialExtentGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Spatial extent", parent)
        form = QFormLayout(self)

        self._spatial_cb = QCheckBox("Restrict to spatial extent")
        self._spatial_cb.setChecked(False)

        self._extent = QgsExtentWidget()
        if iface and iface.mapCanvas():
            canvas = iface.mapCanvas()
            self._extent.setMapCanvas(canvas)
            self._extent.setOriginalExtent(canvas.extent(), canvas.mapSettings().destinationCrs())
            self._extent.setCurrentExtent(canvas.extent(), canvas.mapSettings().destinationCrs())
        self._extent.setEnabled(False)

        self._spatial_cb.toggled.connect(self._extent.setEnabled)

        form.addRow("Active:", self._spatial_cb)
        form.addRow("Extent:", self._extent)

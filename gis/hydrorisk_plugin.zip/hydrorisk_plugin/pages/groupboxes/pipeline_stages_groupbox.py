# -*- coding: utf-8 -*-
"""
HrPipelineStagesGroupBox — pipeline stage checkboxes group box.

The stage list is passed at construction.

Exposes:
    _mode_full      QRadioButton  — "Full pipeline" option
    _mode_custom    QRadioButton  — "Custom stages" option
    _stage_checks   dict[stage_name → QCheckBox]
    _stage_legend   QLabel
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QVBoxLayout, QHBoxLayout,
    QLabel, QCheckBox, QRadioButton, QButtonGroup, QWidget,
)


class HrPipelineStagesGroupBox(QGroupBox):
    def __init__(self, stages: list, parent=None):
        super().__init__("Workflow tasks", parent)
        vbox = QVBoxLayout(self)

        # ── Mode radio buttons ────────────────────────────────────────────
        self._mode_full   = QRadioButton("Full pipeline")
        self._mode_custom = QRadioButton("Custom tasks")
        self._mode_full.setChecked(True)

        self._mode_group = QButtonGroup(self)
        self._mode_group.addButton(self._mode_full,   0)
        self._mode_group.addButton(self._mode_custom, 1)

        radio_row = QHBoxLayout()
        radio_row.setContentsMargins(0, 0, 0, 0)
        radio_row.addWidget(self._mode_full)
        radio_row.addWidget(self._mode_custom)
        radio_row.addStretch()
        vbox.addLayout(radio_row)

        # ── Stage checkboxes (shown only in Custom mode) ──────────────────
        self._checks_widget = QWidget()
        checks_layout = QVBoxLayout(self._checks_widget)
        checks_layout.setContentsMargins(0, 4, 0, 0)
        checks_layout.addWidget(QLabel("Select which tasks to execute (in order):"))

        self._stage_checks = {}
        checks_row = QHBoxLayout()
        checks_row.setContentsMargins(0, 0, 0, 0)
        for stage in stages:
            cb = QCheckBox(stage)
            cb.setChecked(True)
            self._stage_checks[stage] = cb
            checks_row.addWidget(cb)
        checks_row.addStretch()
        checks_layout.addLayout(checks_row)

        self._stage_legend = QLabel("")
        self._stage_legend.setStyleSheet("color: gray; font-size: 10px;")
        checks_layout.addWidget(self._stage_legend)

        self._checks_widget.setVisible(False)
        vbox.addWidget(self._checks_widget)

        # Wire radio toggle
        self._mode_full.toggled.connect(
            lambda checked: self._checks_widget.setVisible(not checked)
        )

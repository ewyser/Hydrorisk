# -*- coding: utf-8 -*-
"""
HrTmMonitorPage — job launcher + live status polling page for the Runner wizard.
"""
import threading
from datetime import datetime

from qgis.PyQt.QtWidgets import QWizardPage, QVBoxLayout
from qgis.PyQt.QtCore import QTimer, pyqtSignal
from .groupboxes.job_launch_groupbox import HrJobLaunchGroupBox
from .groupboxes.progress_groupbox import HrProgressGroupBox
from .groupboxes.log_groupbox import HrLogGroupBox
from ..common.connection_store import make_client as _make_client
_POLL_INTERVAL_MS = 3000


class HrTmMonitorPage(QWizardPage):
    """
    Live-monitoring page: launch a job, then monitor its progress via SSE
    (Server-Sent Events) with automatic fallback to QTimer polling.

    Constructor arguments
    ---------------------
    next_page : int
        Page ID to advance to after this page (-1 = last page).
    task_selection_page : int
        Page ID of the task-selection page (default 0).
    """

    # Qt signals used to safely relay SSE callbacks from the background thread
    # into the GUI thread (PyQt queues cross-thread signals automatically).
    _sig_sse_event = pyqtSignal(object)   # carries the decoded job-status dict
    _sig_sse_done  = pyqtSignal()         # stream ended cleanly
    _sig_sse_error = pyqtSignal(str)      # connection failed — fall back to QTimer
    _sig_refresh   = pyqtSignal()         # one-shot poll after abort to refresh button states

    def __init__(self, parent=None, next_page=-1, task_selection_page=0):
        super().__init__(parent)
        self._next_page           = next_page
        self._task_selection_page = task_selection_page
        self.setTitle("Run & Monitor")
        self.setSubTitle("Launch the job and monitor its progress in real time.")

        self._id_hash         = None
        self._running         = False
        self._poll_errors     = 0
        self._selected_stages = []
        self._sse_thread      = None
        self._full_pipeline   = True  # set from task-selection page on initializePage

        self._timer = QTimer(self)
        self._timer.setInterval(_POLL_INTERVAL_MS)
        self._timer.timeout.connect(self._poll_status)

        # Wire SSE signals — these are dispatched in the GUI thread
        self._sig_sse_event.connect(self._on_sse_event)
        self._sig_sse_done.connect(self._on_sse_done)
        self._sig_sse_error.connect(self._on_sse_error)
        self._sig_refresh.connect(self._poll_status)

        layout = QVBoxLayout(self)

        # ── Job summary + launch ───────────────────────────────────────────
        job_group         = HrJobLaunchGroupBox(parent=self)
        self._summary_lbl = job_group._summary_lbl
        self._launch_btn  = job_group._launch_btn
        self._launch_btn.clicked.connect(self._launch)
        layout.addWidget(job_group)

        # ── Progress ──────────────────────────────────────────────────────
        self._stages              = []
        self._task_icons          = {}
        self._terminal_statuses   = set()
        self._active_statuses     = set()
        self._progress_layout = QVBoxLayout()
        self._progress_layout.setContentsMargins(0, 0, 0, 0)
        self._progress_group  = None
        self._status_val      = None
        self._created_val     = None
        self._done_val        = None
        self._task_widgets    = {}
        self._rebuild_progress_groupbox(self._stages)
        layout.addLayout(self._progress_layout)

        # ── Log ───────────────────────────────────────────────────────────
        log_group = HrLogGroupBox(parent=self)
        self._log = log_group._log
        layout.addWidget(log_group, 1)

    def _rebuild_progress_groupbox(self, stages: list):
        """(Re)build HrProgressGroupBox for the given stage list."""
        if self._progress_group is not None:
            self._progress_layout.removeWidget(self._progress_group)
            self._progress_group.deleteLater()
        self._progress_group = HrProgressGroupBox(stages, parent=self)
        self._status_val     = self._progress_group._status_val
        self._created_val    = self._progress_group._created_val
        self._done_val       = self._progress_group._done_val
        self._task_widgets   = self._progress_group._task_widgets
        for task_name, w in self._task_widgets.items():
            w["btn_mode"] = "abort"
            w["abort"].clicked.connect(
                lambda _checked, n=task_name: self._on_task_btn(n)
            )
        self._progress_layout.addWidget(self._progress_group)

    def _fetch_task_config(self):
        """Fetch stages + status_icons + terminal/active statuses from API."""
        try:
            client    = _make_client()
            config    = client.task_config()
            stages    = config.get("stages") or []
            icons_raw = config.get("status_icons") or {}
            if stages:
                changed          = stages != self._stages
                self._stages     = stages
                if icons_raw:
                    self._task_icons = {
                        k: (v["icon"], v["color"]) for k, v in icons_raw.items()
                    }
                if changed:
                    self._rebuild_progress_groupbox(self._stages)
            terminal = config.get("terminal_statuses") or []
            active   = config.get("active_statuses")   or []
            if terminal:
                self._terminal_statuses = set(terminal)
            if active:
                self._active_statuses = set(active)
        except Exception:
            pass  # keep current state

    # ------------------------------------------------------------------
    # Monitoring helpers (SSE with QTimer fallback)
    # ------------------------------------------------------------------

    def _start_monitoring(self):
        """Start live monitoring via SSE; fall back to QTimer if SSE is unavailable."""
        if not self._id_hash:
            return
        self._stop_monitoring()
        client = _make_client()
        self._sse_thread = client.sse_job_status(
            self._id_hash,
            on_event=lambda data: self._sig_sse_event.emit(data),
            on_done=lambda: self._sig_sse_done.emit(),
            on_error=lambda exc: self._sig_sse_error.emit(str(exc)),
        )

    def _stop_monitoring(self):
        """Stop the SSE thread (if running) and the fallback QTimer."""
        self._timer.stop()
        if self._sse_thread is not None:
            self._sse_thread.stop()
            self._sse_thread = None

    # ------------------------------------------------------------------
    # SSE slots — always called in the GUI thread via Qt signal queuing
    # ------------------------------------------------------------------

    def _on_sse_event(self, job: dict):
        """Handle a single status update pushed by the server."""
        self._poll_errors = 0
        err_msg = job.get("err_msg", "") or ""
        status  = self._render_status(job)
        self._log_line(
            f"status={status}"
            + (f"  err={err_msg}" if err_msg else "")
        )
        if status in self._terminal_statuses:
            self._stop_monitoring()
            self._running = False
            if err_msg:
                self._log_line(f"❌  Error: {err_msg}")
            if status == "completed":
                self._log_line("✅  Job completed.")
            self.completeChanged.emit()

    def _on_sse_done(self):
        """SSE stream ended without an error event — treat as terminal."""
        self._sse_thread = None
        if self._running:
            self._running = False
            self.completeChanged.emit()

    def _on_sse_error(self, err_msg: str):
        """SSE connection failed — log it and fall back to QTimer polling."""
        self._sse_thread = None
        self._log_line(f"⚠  SSE unavailable ({err_msg}), falling back to polling.")
        self._poll_errors = 0
        self._timer.start()

    def cleanupPage(self):
        self._stop_monitoring()

    def initializePage(self):
        self._stop_monitoring()
        self._fetch_task_config()
        self._id_hash    = None
        self._running    = False
        self._poll_errors = 0
        for w in self._task_widgets.values():
            w["bar"].setValue(0)
            w["step"].setText("—")
            w["status"].setText("—")
            w["status"].setStyleSheet("color: gray; font-weight: bold;")
            w["abort"].setText("✕")
            w["btn_mode"] = "abort"
            w["abort"].setEnabled(False)
        self._log.clear()
        for lbl in (self._status_val, self._created_val, self._done_val):
            lbl.setText("—")

        self._launch_btn.setEnabled(True)
        self._launch_btn.setText("▶  Launch")

        sel_page = self.wizard().page(self._task_selection_page)
        job      = sel_page.selected_job()
        self._selected_stages = sel_page.selected_stages() or list(self._stages)
        self._full_pipeline   = (
            sel_page._stages_group is not None
            and sel_page._stages_group._mode_full.isChecked()
        )
        label    = job.get("prefix") or (job.get("id_hash") or "?")[:8]
        self._summary_lbl.setText(label)

        # Full pipeline → show launch button, hide per-task rows
        # Custom stages → hide launch button, show per-task rows
        self._launch_btn.parentWidget().setVisible(self._full_pipeline)

        # Show selected rows immediately as pending (orange) before the server fetch
        for task_name, w in self._task_widgets.items():
            if task_name in self._selected_stages:
                w["row"].setVisible(True)
                w["status"].setText("pending")
                w["status"].setStyleSheet("color: orange; font-weight: bold;")
                if self._full_pipeline:
                    # visible but not individually actionable
                    w["abort"].setText("—")
                    w["btn_mode"] = "locked"
                    w["abort"].setEnabled(False)
                else:
                    w["abort"].setText("▶")
                    w["btn_mode"] = "run"
                    w["abort"].setEnabled(True)
            else:
                w["row"].setVisible(False)

        id_hash = job.get("id_hash", "")
        if id_hash:
            self._id_hash = id_hash
            client = _make_client()
            try:
                response = client.job_status(id_hash)
                job_data = response.get("job", response) if isinstance(response, dict) else response
                status   = self._render_status(job_data)
                if status in self._active_statuses:
                    self._running = True
                    self._launch_btn.setEnabled(False)
                    self._launch_btn.setText("Running…")
                if status not in self._terminal_statuses:
                    self._start_monitoring()
            except Exception as exc:
                self._log_line(f"⚠  Could not fetch job status: {exc}")

        self.completeChanged.emit()

    def _log_line(self, text: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self._log.append(f"[{ts}]  {text}")

    def _launch(self):
        sel_page = self.wizard().page(self._task_selection_page)
        job      = sel_page.selected_job()
        stages   = sel_page.selected_stages()

        if not job:
            self._log_line("❌  No job selected.")
            return

        id_hash = job.get("id_hash", "")
        if not id_hash:
            self._log_line("❌  Selected job has no id_hash.")
            return

        client = _make_client()

        self._launch_btn.setEnabled(False)
        self._launch_btn.setText("Running…")
        self._log_line(
            f"Submitting job '{job.get('prefix') or id_hash[:8]}' "
            f"with tasks: {stages}…"
        )

        try:
            result = client.run_job(id_hash, stages)
        except Exception as exc:
            self._log_line(f"❌  Launch failed: {exc}")
            self._launch_btn.setEnabled(True)
            self._launch_btn.setText("▶  Retry")
            return

        self._id_hash    = result.get("id_hash") or result.get("id", "")
        self._running    = True
        self._poll_errors = 0
        self._selected_stages = stages or list(self._stages)
        self._log_line(f"✅  Job queued — id_hash: {self._id_hash}")
        self._log_line(result.get("msg", ""))
        self._start_monitoring()
        self.completeChanged.emit()

    def _poll_status(self):
        """Timer callback — fetch /jobs/status and update UI."""
        if not self._id_hash:
            self._timer.stop()
            return
        client = _make_client()
        try:
            response = client.job_status(self._id_hash)
            job      = response.get("job", response) if isinstance(response, dict) else response
            self._poll_errors = 0
        except Exception as exc:
            self._poll_errors += 1
            self._log_line(f"⚠  Poll error ({self._poll_errors}): {exc}")
            if self._poll_errors >= 5:
                self._timer.stop()
                self._running = False
                self.completeChanged.emit()
            return

        err_msg = job.get("err_msg", "") or ""
        status  = self._render_status(job)
        active_task = next(
            (n for n, w in self._task_widgets.items()
             if w.get("btn_mode") == "abort" and w["abort"].isEnabled()),
            None,
        )
        self._log_line(
            f"status={status}  active={active_task or '—'}"
            + (f"  err={err_msg}" if err_msg else "")
        )
        if status in self._terminal_statuses:
            self._timer.stop()
            self._running = False
            if err_msg:
                self._log_line(f"❌  Error: {err_msg}")
            if status == "completed":
                self._log_line("✅  Job completed.")
            self.completeChanged.emit()

    def _render_status(self, job: dict) -> str:
        """Apply a job-status dict to all progress widgets. Returns the job status string."""
        status  = job.get("status",        "—")
        created = (job.get("created_at")   or "—")[:19]
        done    = (job.get("completed_at") or "—")[:19]

        self._status_val.setText(status)
        self._created_val.setText(created)
        self._done_val.setText(done)

        colour = self._task_icons.get(status, self._task_icons.get("unknown", ("?", "gray")))[1]
        self._status_val.setStyleSheet(f"color: {colour};")

        tasks_data = {t["name"]: t for t in job.get("tasks") or [] if t.get("name")}
        visible_tasks = set(self._selected_stages)
        for task_name, w in self._task_widgets.items():
            visible = task_name in visible_tasks
            w["row"].setVisible(visible)
            if not visible:
                continue
            t       = tasks_data.get(task_name, {})
            pct     = t.get("percent") or 0.0
            step    = t.get("step")    or "—"
            tstatus = t.get("status") or "unknown"
            if tstatus not in self._task_icons:
                tstatus = "unknown"
            w["bar"].setValue(int(pct))
            w["bar"].setStyleSheet("")   # reset any locking style from previous render
            w["step"].setText(step)
            w["status"].setText(tstatus)
            tc = self._task_icons.get(tstatus, self._task_icons.get("unknown", ("?", "gray")))[1]
            w["status"].setStyleSheet(f"color: {tc}; font-weight: bold;")
            if self._full_pipeline:
                # In full-pipeline mode buttons are always disabled — job-level launch only
                w["abort"].setText("—")
                w["btn_mode"] = "locked"
                w["abort"].setEnabled(False)
            elif tstatus == "in-progress":
                w["abort"].setText("✕")
                w["btn_mode"] = "abort"
                w["abort"].setEnabled(True)
            elif tstatus in ("aborted", "completed", "failed"):
                w["abort"].setText("↺")
                w["btn_mode"] = "restart"
                w["abort"].setEnabled(True)
            elif tstatus == "pending":
                w["abort"].setText("▶")
                w["btn_mode"] = "run"
                w["abort"].setEnabled(True)
            else:
                w["abort"].setText("✕")
                w["btn_mode"] = "abort"
                w["abort"].setEnabled(False)

        # If any task is actively running, disable all non-abort buttons
        # so the user cannot start a second task in parallel.
        # Grey out locked stages — only relevant in custom mode.
        if not self._full_pipeline:
            any_active = any(
                tasks_data.get(n, {}).get("status") in self._active_statuses
                for n in visible_tasks
            )
            if any_active:
                for task_name, w in self._task_widgets.items():
                    if w["btn_mode"] in ("run", "restart"):
                        w["abort"].setEnabled(False)

            # Grey out stages whose predecessor (in pipeline order) is not completed
            stages_in_order = [s for s in self._stages if s in visible_tasks]
            for i, task_name in enumerate(stages_in_order):
                if i == 0:
                    continue
                prev_status = tasks_data.get(stages_in_order[i - 1], {}).get("status") or "unknown"
                if prev_status != "completed":
                    w = self._task_widgets[task_name]
                    w["abort"].setEnabled(False)
                    w["abort"].setText("—")
                    w["btn_mode"] = "locked"
                    w["status"].setStyleSheet("color: #888888; font-weight: bold;")
                    w["bar"].setStyleSheet(
                        "QProgressBar { color: #888888; }"
                        "QProgressBar::chunk { background: #cccccc; }"
                    )

        return status

    def _on_task_btn(self, task_name: str):
        w = self._task_widgets[task_name]
        mode = w.get("btn_mode")
        if mode in ("restart", "run"):
            self._restart_task(task_name, mode)
        else:
            self._abort_task(task_name)

    def _abort_task(self, task_name: str):
        self._stop_monitoring()
        self._running    = False
        self._poll_errors = 0
        for name, w in self._task_widgets.items():
            if name == task_name:
                w["abort"].setText("↺")
                w["btn_mode"] = "restart"
                w["abort"].setEnabled(True)
            else:
                w["abort"].setEnabled(False)
        self._log_line(f"⛔  Aborting {task_name}…")
        if self._id_hash:
            client   = _make_client()
            id_hash  = self._id_hash
            log_line = self._log_line
            def _do_abort():
                try:
                    client.abort_task(id_hash, task_name)
                    log_line(f"✅  Task '{task_name}' marked as aborted.")
                except Exception:
                    pass  # next poll will confirm state
                finally:
                    self._sig_refresh.emit()  # refresh all button states in the GUI thread
            threading.Thread(target=_do_abort, daemon=True).start()
        self.completeChanged.emit()

    def _restart_task(self, task_name: str, mode: str = "restart"):
        w = self._task_widgets[task_name]
        w["abort"].setEnabled(False)
        # Lock all other task buttons immediately while this task runs
        for name, other in self._task_widgets.items():
            if name != task_name:
                other["abort"].setEnabled(False)
        verb = "Starting" if mode == "run" else "Restarting"
        self._log_line(f"▶  {verb} {task_name}…")
        if not self._id_hash:
            return
        client = _make_client()
        try:
            if mode == "run":
                client.run_task(self._id_hash, task_name)
            else:
                client.restart_task(self._id_hash, task_name)
            self._log_line(f"✅  Task '{task_name}' {'started' if mode == 'run' else 'restarted'}.")
            w["abort"].setText("✕")
            w["btn_mode"] = "abort"
            self._running    = True
            self._poll_errors = 0
            self._start_monitoring()
            self.completeChanged.emit()
        except Exception as exc:
            self._log_line(f"⚠  Could not restart task: {exc}")
            w["abort"].setEnabled(True)

    def isComplete(self):
        if not self._id_hash:
            return True
        return not self._running

    def validatePage(self):
        if self._running:
            self._stop_monitoring()
        return True

    def nextId(self):
        return self._next_page

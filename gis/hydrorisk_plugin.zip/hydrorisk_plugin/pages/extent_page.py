# -*- coding: utf-8 -*-
"""
HrExtentPage — shared spatial + temporal extent page for Hydrorisk wizards.

Used by both cfg_wizard and job_manager_wizard.  Seed pre-fill is supported
transparently: if the host wizard exposes a ``seed_config()`` method that returns
a non-empty dict, temporal and spatial extent are pre-filled from it on
``initializePage``.
"""
from qgis.PyQt.QtWidgets import QWizardPage, QVBoxLayout
from .groupboxes.spatial_extent_groupbox import HrSpatialExtentGroupBox
from .groupboxes.temporal_extent_groupbox import HrTemporalExtentGroupBox


class HrExtentPage(QWizardPage):
    """
    Spatial (QgsExtentWidget) + temporal (date/time pickers) extent page.

    Title and subtitle should be set by the host wizard or a thin subclass.
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        layout = QVBoxLayout(self)

        # ── Spatial ───────────────────────────────────────────────────────
        spatial_group    = HrSpatialExtentGroupBox(parent=self)
        self._spatial_cb = spatial_group._spatial_cb
        self._extent     = spatial_group._extent
        layout.addWidget(spatial_group)

        # ── Temporal ──────────────────────────────────────────────────────
        temporal_group    = HrTemporalExtentGroupBox(parent=self)
        self._temporal_cb = temporal_group._temporal_cb
        self._date_start  = temporal_group._date_start
        self._time_start  = temporal_group._time_start
        self._date_end    = temporal_group._date_end
        self._time_end    = temporal_group._time_end
        layout.addWidget(temporal_group)
        layout.addStretch()

    # ------------------------------------------------------------------

    def initializePage(self):
        try:
            self._extent.toggleDialogVisibility.connect(self._toggle_wizard)
        except RuntimeError:
            pass  # signal already connected on re-entry

        # Pre-fill from seed if the wizard exposes seed_config()
        seed = getattr(self.wizard(), "seed_config", lambda: {})()
        if not seed:
            return

        temporal = seed.get("source", {}).get("extent", {}).get("temporal")
        if temporal:
            from qgis.PyQt.QtCore import QDate, QTime
            date_block = temporal.get("date", {})
            time_block = temporal.get("time", {})
            start_date = QDate.fromString(date_block.get("start", ""), "yyyy-MM-dd")
            end_date   = QDate.fromString(date_block.get("end",   ""), "yyyy-MM-dd")
            start_time = QTime.fromString(time_block.get("start", ""), "HH:mm:ss")
            end_time   = QTime.fromString(time_block.get("end",   ""), "HH:mm:ss")
            if any(x.isValid() for x in (start_date, end_date, start_time, end_time)):
                self._temporal_cb.setChecked(True)
                if start_date.isValid(): self._date_start.setText(start_date.toString("yyyy-MM-dd"))
                if end_date.isValid():   self._date_end.setText(end_date.toString("yyyy-MM-dd"))
                if start_time.isValid(): self._time_start.setText(start_time.toString("HH:mm:ss"))
                if end_time.isValid():   self._time_end.setText(end_time.toString("HH:mm:ss"))

        spatial = seed.get("source", {}).get("extent", {}).get("spatial")
        if spatial:
            try:
                from qgis.core import QgsRectangle, QgsCoordinateReferenceSystem
                feats = spatial.get("features", [])
                if feats:
                    props = feats[0].get("properties", {})
                    rect  = QgsRectangle(
                        props.get("MINX", 0), props.get("MINY", 0),
                        props.get("MAXX", 0), props.get("MAXY", 0),
                    )
                    crs_name = spatial.get("crs", {}).get("properties", {}).get("name", "")
                    crs = (
                        QgsCoordinateReferenceSystem(crs_name)
                        if crs_name
                        else QgsCoordinateReferenceSystem()
                    )
                    self._extent.setOutputExtentFromUser(rect, crs)
                    self._spatial_cb.setChecked(True)
            except Exception:
                pass

    def _toggle_wizard(self, visible):
        wiz = self.wizard()
        if visible:
            wiz.show()
            wiz.raise_()
            wiz.activateWindow()
        else:
            wiz.hide()

    # ------------------------------------------------------------------
    # Data accessors

    def extent_geojson(self):
        if not self._spatial_cb.isChecked() or self._extent.outputExtent().isNull():
            return None
        rect = self._extent.outputExtent()
        crs  = self._extent.outputCrs()
        xmin, ymin = rect.xMinimum(), rect.yMinimum()
        xmax, ymax = rect.xMaximum(), rect.yMaximum()
        ring = [[xmin, ymin], [xmin, ymax], [xmax, ymax], [xmax, ymin], [xmin, ymin]]
        return {
            "type": "FeatureCollection",
            "name": "extent",
            "crs":  {"type": "name", "properties": {
                "name": (
                    f"urn:ogc:def:crs:EPSG::{crs.postgisSrid()}"
                    if crs.isValid() else "urn:ogc:def:crs:EPSG::2056"
                )
            }},
            "features": [{"type": "Feature", "properties": {
                "MINX": xmin, "MINY": ymin, "MAXX": xmax, "MAXY": ymax,
                "CNTX": (xmin + xmax) / 2, "CNTY": (ymin + ymax) / 2,
                "AREA": rect.area(), "PERIM": rect.perimeter(),
                "HEIGHT": rect.height(), "WIDTH": rect.width(),
            }, "geometry": {"type": "MultiPolygon", "coordinates": [[ring]]}}],
        }

    def temporal_extent(self):
        return {
            "date": {
                "format": "yyyy-mm-dd",
                "start":  self._date_start.text().strip(),
                "end":    self._date_end.text().strip(),
            },
            "time": {
                "format": "HH:MM:SS",
                "start":  self._time_start.text().strip(),
                "end":    self._time_end.text().strip(),
            },
        }

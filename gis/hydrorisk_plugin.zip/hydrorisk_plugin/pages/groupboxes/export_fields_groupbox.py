# -*- coding: utf-8 -*-
"""
HrExportFieldsGroupBox — export-fields selector group box.

Two display modes, selected at construction:
  - scrollable=True  (full version, Job Manager): columnar QGroupBox-per-section
    layout with sub-field checkboxes and a frequency spinner.
  - scrollable=False (simple version, Config Wizard): flat vertical checkbox list,
    no frequency spinner.

Exposes (both modes):
    _save_checks        dict[group_key → QCheckBox]
    _save_fields        dict  (populated externally via load_fields())

Exposes (scrollable=True only):
    _freq               QSpinBox
    _save_field_checks  dict[group_key → {field_name: QCheckBox}]
    _save_cols_layout   QHBoxLayout
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QVBoxLayout, QHBoxLayout, QFormLayout,
    QWidget, QScrollArea, QCheckBox, QSpinBox, QLabel,
)
from qgis.PyQt.QtCore import Qt


class HrExportFieldsGroupBox(QGroupBox):
    def __init__(self, scrollable: bool = True, default_save_groups: set = None, parent=None):
        super().__init__("Export fields", parent)
        self._scrollable          = scrollable
        self._default_save_groups = default_save_groups or set()
        self._save_checks         = {}
        self._save_field_checks   = {}
        self._save_fields         = {}
        self._freq                = None

        outer = QVBoxLayout(self)

        if scrollable:
            freq_form = QFormLayout()
            self._freq = QSpinBox()
            self._freq.setRange(1, 999999)
            self._freq.setValue(60)
            self._freq.setSuffix(" s")
            freq_form.addRow("Export interval (tC):", self._freq)
            outer.addLayout(freq_form)

            self._save_cols_widget = QWidget()
            self._save_cols_layout = QHBoxLayout(self._save_cols_widget)
            self._save_cols_layout.setContentsMargins(0, 0, 0, 0)
            self._save_cols_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)

            save_scroll = QScrollArea()
            save_scroll.setWidgetResizable(True)
            save_scroll.setFrameShape(QScrollArea.NoFrame)
            save_scroll.setWidget(self._save_cols_widget)
            outer.addWidget(save_scroll, 1)
        else:
            # Simple flat layout — checkboxes added dynamically
            self._save_vbox = QVBoxLayout()
            outer.addLayout(self._save_vbox)

    # ------------------------------------------------------------------
    # Public API

    def load_fields(self, save_fields: dict, seed_save_groups: set = None,
                    seed_save_struct: dict = None):
        """Rebuild checkbox widgets from an API export-catalog dict."""
        self._save_fields = save_fields
        seed_save_groups  = seed_save_groups  or set()
        seed_save_struct  = seed_save_struct  or {}

        if self._scrollable:
            self._rebuild_scrollable(seed_save_groups, seed_save_struct)
        else:
            self._rebuild_flat(seed_save_groups)

    def _rebuild_scrollable(self, seed_save_groups, seed_save_struct):
        while self._save_cols_layout.count():
            item = self._save_cols_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self._save_checks.clear()
        self._save_field_checks.clear()

        for section, groups in self._save_fields.items():
            col_box  = QGroupBox(section)
            col_vbox = QVBoxLayout(col_box)
            col_vbox.setAlignment(Qt.AlignTop)

            for group_key, fields in groups.items():
                initially_checked = (
                    group_key in seed_save_groups if seed_save_groups
                    else group_key in self._default_save_groups
                )
                cb = QCheckBox(group_key)
                cb.setChecked(initially_checked)
                self._save_checks[group_key] = cb
                col_vbox.addWidget(cb)

                sub_fields = (
                    [str(f) for f in fields if f] if isinstance(fields, list)
                    else list(fields.keys())
                )
                if sub_fields:
                    self._save_field_checks[group_key] = {}
                    seed_group_fields = None
                    for sec_val in seed_save_struct.values():
                        if isinstance(sec_val, dict) and group_key in sec_val:
                            seed_group_fields = sec_val[group_key]
                            break

                    sub_box = QWidget()
                    sub_lay = QVBoxLayout(sub_box)
                    sub_lay.setContentsMargins(20, 0, 0, 4)
                    sub_lay.setSpacing(2)
                    for fname in sub_fields:
                        label = (fields.get(fname) or fname
                                 if isinstance(fields, dict) else fname)
                        fcb = QCheckBox(label)
                        fcb.setToolTip(fname)
                        if seed_group_fields is not None:
                            fcb.setChecked(
                                fname in seed_group_fields
                                if isinstance(seed_group_fields, (list, dict))
                                else initially_checked
                            )
                        else:
                            fcb.setChecked(initially_checked)
                        self._save_field_checks[group_key][fname] = fcb
                        fcb.toggled.connect(
                            lambda _, gk=group_key: self._on_subfield_toggled(gk)
                        )
                        sub_lay.addWidget(fcb)

                    sub_box.setEnabled(initially_checked)
                    cb.toggled.connect(
                        lambda checked, gk=group_key, sw=sub_box:
                            self._on_group_toggled(gk, checked, sw)
                    )
                    col_vbox.addWidget(sub_box)

            col_vbox.addStretch()
            self._save_cols_layout.addWidget(col_box)

    def _rebuild_flat(self, seed_save_groups):
        while self._save_vbox.count():
            item = self._save_vbox.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._save_checks.clear()

        for section, groups in self._save_fields.items():
            lbl = QLabel(f"<b>{section}</b>")
            self._save_vbox.addWidget(lbl)
            for group_key in groups:
                cb = QCheckBox(f"  {group_key}")
                cb.setChecked(group_key in self._default_save_groups)
                self._save_checks[group_key] = cb
                self._save_vbox.addWidget(cb)

    # ── Sub-field / group toggle helpers ─────────────────────────────────

    def _on_group_toggled(self, group_key: str, checked: bool, sub_widget):
        sub_widget.setEnabled(checked)
        if checked and group_key in self._save_field_checks:
            field_checks = self._save_field_checks[group_key]
            if not any(fcb.isChecked() for fcb in field_checks.values()):
                for fcb in field_checks.values():
                    fcb.blockSignals(True)
                    fcb.setChecked(True)
                    fcb.blockSignals(False)

    def _on_subfield_toggled(self, group_key: str):
        field_checks = self._save_field_checks.get(group_key, {})
        cb = self._save_checks.get(group_key)
        if not cb or not field_checks:
            return
        any_checked = any(fcb.isChecked() for fcb in field_checks.values())
        cb.blockSignals(True)
        cb.setChecked(any_checked)
        cb.blockSignals(False)

    # ── Data accessors ────────────────────────────────────────────────────

    def selected_save_groups(self) -> set:
        return {k for k, cb in self._save_checks.items() if cb.isChecked()}

    def save_what_list(self) -> list:
        return sorted(self.selected_save_groups())

    def build_save_structure(self) -> dict:
        selected = self.selected_save_groups()
        result   = {}
        for section, groups in self._save_fields.items():
            kept = {}
            for gk, fields in groups.items():
                if gk not in selected:
                    continue
                if gk in self._save_field_checks:
                    checked_names = {
                        fn for fn, fcb in self._save_field_checks[gk].items()
                        if fcb.isChecked()
                    }
                    if isinstance(fields, list):
                        kept[gk] = [f for f in fields if str(f) in checked_names]
                    elif isinstance(fields, dict):
                        kept[gk] = {k: v for k, v in fields.items() if k in checked_names}
                    else:
                        kept[gk] = fields
                else:
                    kept[gk] = fields
            if kept:
                result[section] = kept
        return result

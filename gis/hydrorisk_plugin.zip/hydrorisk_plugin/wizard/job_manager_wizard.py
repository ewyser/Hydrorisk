# -*- coding: utf-8 -*-
"""
HrJobWizard — multi-page QWizard for submitting a Hydrorisk.jl job.

Pages
-----
0  HrConnectionPage  — API URL + token + job mode (new / base on existing) + prefix
1  HrDataInputsPage  — pick one dataset per simulation input from DB catalog
2  HrSimSettingsPage — solver options + save/export fields
3  HrExtentPage      — spatial (QgsExtentWidget) + temporal (date/time)
4  HrSummaryPage     — JSON preview + submit to server
"""
import os
import json
import uuid
from datetime import datetime

from qgis.PyQt.QtWidgets import (
    QWizard, QWizardPage, QDialog,
    QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QPushButton, QComboBox,
    QGroupBox, QTextEdit,
    QCheckBox, QFileDialog, QWidget,
    QRadioButton, QButtonGroup,
)
from qgis.PyQt.QtCore import QSize
from qgis.PyQt.QtGui import QFont

from ..pages.extent_page import HrExtentPage as _HrExtentPageBase
from ..common.connection_store import make_client as _make_client
from .base_wizard import HrBaseWizard
from ..pages.data_inputs_page import BaseDataInputsPage
from ..pages.sim_settings_page import HrSimSettingsPage
from ..dialogs.upload_dialog import HrUploadDialog

# ─────────────────────────────────────────────────────────────────────────────
PAGE_CONNECTION  = 0
PAGE_DATA_INPUTS = 1
PAGE_SIM         = 2
PAGE_EXTENT      = 3
PAGE_SUMMARY     = 4


# ─────────────────────────────────────────────────────────────────────────────
# Page 0 — Connection & Job wizard
# ─────────────────────────────────────────────────────────────────────────────

class HrJobSettingsPage(QWizardPage):
    """Page 0 — Job mode & prefix selection (auth from global connection store)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Step 1 — Job settings")
        self.setSubTitle(
            "Choose to create a new job or base it on an existing one."
        )

        layout = QVBoxLayout(self)

        self._mode_group = QGroupBox("Job Manager")
        mode_layout = QVBoxLayout(self._mode_group)

        self._rb_new  = QRadioButton("Create a new job")
        self._rb_edit = QRadioButton("From an existing job")
        self._rb_new.setChecked(True)
        self._btn_group = QButtonGroup(self)
        self._btn_group.addButton(self._rb_new,  0)
        self._btn_group.addButton(self._rb_edit, 1)

        # prefix row
        self._prefix = QLineEdit()
        self._prefix.setPlaceholderText("Auto-generated or type a name…")
        self._regen_btn = QPushButton("🔄")
        self._regen_btn.setFixedWidth(32)
        self._regen_btn.setToolTip("Generate a new prefix")
        self._regen_btn.clicked.connect(self._generate_prefix)
        prefix_form = QFormLayout()
        prefix_form.setContentsMargins(0, 0, 0, 0)
        prefix_row = QHBoxLayout()
        prefix_row.setContentsMargins(0, 0, 0, 0)
        prefix_row.addWidget(self._prefix, 1)
        prefix_row.addWidget(self._regen_btn)
        prefix_form.addRow("Job name:", prefix_row)
        mode_layout.addLayout(prefix_form)

        mode_layout.addWidget(self._rb_new)

        # Row 2: "From an existing job" + combo + delete
        self._job_combo = QComboBox()
        self._job_combo.setVisible(False)

        self._delete_btn = QPushButton("🗑")
        self._delete_btn.setFixedWidth(32)
        self._delete_btn.setToolTip("Delete selected job")
        self._delete_btn.setEnabled(False)
        self._delete_btn.setVisible(False)
        self._delete_btn.clicked.connect(self._delete_selected_job)

        self._mode_status = QLabel("")
        self._mode_status.setStyleSheet("color: gray;")

        edit_job_row = QHBoxLayout()
        edit_job_row.setContentsMargins(0, 0, 0, 0)
        edit_job_row.addWidget(self._rb_edit)
        edit_job_row.addWidget(self._job_combo, 1)
        edit_job_row.addWidget(self._delete_btn)
        edit_job_row.addWidget(self._mode_status)
        mode_layout.addLayout(edit_job_row)

        self._rb_edit.toggled.connect(self._on_mode_changed)
        self._job_combo.currentIndexChanged.connect(self._on_job_combo_changed)

        layout.addWidget(self._mode_group)
        layout.addStretch()

        self._jobs       = []
        self._db_info    = {}
        self._username   = ""
        self._last_stats = {}
        self._generate_prefix()

    def initializePage(self):
        from ..common.connection_store import store
        self._username = store.username
        client = _make_client()
        self._db_info = {}
        try:
            self._db_info = client.db_info()
        except Exception:
            pass
        self._populate_jobs(client)
        try:
            self._last_stats = client.user_stats()
        except Exception:
            pass

    def _on_mode_changed(self, edit_checked):
        self._job_combo.setVisible(edit_checked)
        self._delete_btn.setVisible(edit_checked)
        self._delete_btn.setEnabled(edit_checked and bool(self._jobs))
        self.completeChanged.emit()

    def _on_job_combo_changed(self, _index):
        self._delete_btn.setEnabled(
            self._rb_edit.isChecked() and bool(self._jobs) and self._job_combo.currentIndex() >= 0
        )
        self.completeChanged.emit()

    def _delete_selected_job(self):
        from qgis.PyQt.QtWidgets import QMessageBox
        idx = self._job_combo.currentIndex()
        if idx < 0 or idx >= len(self._jobs):
            return
        job     = self._jobs[idx]
        label   = job.get("prefix") or (job.get("id_hash") or "?")[:8]
        id_hash = job.get("id_hash", "")
        reply = QMessageBox.question(
            self, "Delete job",
            f"Delete job '{label}' ({id_hash[:8]})? This cannot be undone.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        try:
            _make_client().delete_job(id_hash)
            self._mode_status.setText(f"\u2705  Job '{label}' deleted.")
            self._mode_status.setStyleSheet("color: green;")
            self._populate_jobs(_make_client())
        except Exception as exc:
            self._mode_status.setText(f"❌  {exc}")
            self._mode_status.setStyleSheet("color: red;")

    def _generate_prefix(self):
        existing = {j.get("prefix", "") for j in self._jobs}
        while True:
            candidate = str(uuid.uuid4())
            if candidate not in existing:
                self._prefix.setText(candidate)
                return

    def _populate_jobs(self, client):
        """Fetch /jobs/list and populate the existing-job combo."""
        self._job_combo.clear()
        self._jobs = []
        try:
            self._jobs = client.list_jobs()
        except Exception:
            self._jobs = []
        if self._jobs:
            for j in self._jobs:
                label  = j.get("prefix") or (j.get("id_hash") or "?")[:8]
                status = j.get("status", "")
                self._job_combo.addItem(f"{label}  [{status}]")
            self._rb_edit.setEnabled(True)
            self._mode_status.setText(f"{len(self._jobs)} existing job(s) available.")
            self._mode_status.setStyleSheet("color: gray;")
        else:
            self._job_combo.addItem("— no jobs yet —")
            self._rb_edit.setEnabled(False)
            if self._rb_edit.isChecked():
                self._rb_new.setChecked(True)
            self._mode_status.setText("No existing jobs found.")
            self._mode_status.setStyleSheet("color: gray;")

    def db_connection(self):  return dict(self._db_info)
    def job_prefix(self):     return self._prefix.text().strip()
    def auth_username(self):  return self._username

    def is_new_job(self) -> bool:
        return self._rb_new.isChecked()

    def selected_seed(self) -> dict:
        """Config dict from the selected existing job, or {} for a new job."""
        if self.is_new_job() or not self._jobs:
            return {}
        idx = self._job_combo.currentIndex()
        if idx < 0 or idx >= len(self._jobs):
            return {}
        return self._jobs[idx].get("config") or {}

    def isComplete(self):
        if self._rb_edit.isChecked():
            return bool(self._jobs) and self._job_combo.currentIndex() >= 0
        return True

    def nextId(self):
        return PAGE_DATA_INPUTS


# ─────────────────────────────────────────────────────────────────────────────
# Page 1 — Data inputs  (HrUploadDialog imported from dialogs.upload_dialog)
# ─────────────────────────────────────────────────────────────────────────────

class HrDataInputsPage(BaseDataInputsPage):
    """
    Data inputs page with per-category upload button and usage statistics.
    Extends BaseDataInputsPage with upload support and seed pre-fill.
    """

    def __init__(self, parent=None):
        self._upload_btns = {}  # db_cat → QPushButton; must exist before super().__init__
        super().__init__(parent)
        self.setTitle("Step 2 — Data inputs")
        self.setSubTitle(
            "Check the categories you want to use and assign a dataset to each.\n"
            "Required inputs must be set; optional inputs can be skipped."
        )

    # ── Header: usage statistics ──────────────────────────────────────────
    def _setup_header(self, layout):
        self._stats_group = QGroupBox("Usage statistics")
        stats_form = QFormLayout(self._stats_group)
        self._stats_uploads_lbl = QLabel("—")
        self._stats_size_lbl    = QLabel("—")
        self._stats_last_lbl    = QLabel("—")
        stats_form.addRow("Total uploads:",  self._stats_uploads_lbl)
        stats_form.addRow("Total uploaded:", self._stats_size_lbl)
        stats_form.addRow("Last upload:",    self._stats_last_lbl)
        self._stats_group.setVisible(False)
        layout.addWidget(self._stats_group)

    def initializePage(self):
        # Update stats before catalog fetch (visible even if catalog fails)
        conn_page = self.wizard().page(PAGE_CONNECTION)
        stats = getattr(conn_page, "_last_stats", {})
        if stats:
            uc = stats.get("upload_count", 0) or 0
            ub = stats.get("upload_bytes", 0) or 0
            lu = stats.get("last_upload") or "—"
            self._stats_uploads_lbl.setText(str(uc))
            self._stats_size_lbl.setText(f"{ub / 1024 / 1024:.2f} MB")
            self._stats_last_lbl.setText(lu[:19] if lu != "—" else lu)
            self._stats_group.setVisible(True)
        else:
            self._stats_group.setVisible(False)
        super().initializePage()

    # ── Row widget: add upload button ─────────────────────────────────────
    def _build_row_widget(self, db_cat, combo, col_combo, cat_meta):
        upload_btn = QPushButton("⬆")
        upload_btn.setFixedWidth(28)
        upload_btn.setToolTip("Upload a new dataset for this category")
        self._upload_btns[db_cat] = upload_btn
        upload_btn.clicked.connect(lambda _, dc=db_cat: self._on_upload_clicked(dc))

        row = QWidget()
        rl  = QHBoxLayout(row)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(6)
        rl.addWidget(combo,      2)
        rl.addWidget(col_combo,  1)
        rl.addWidget(upload_btn)
        return row

    def _extra_clear(self):
        self._upload_btns.clear()

    # ── Seed pre-fill ────────────────────────────────────────────────────
    def _on_catalog_loaded(self, seed):
        if not seed:
            return
        seed_inputs = seed.get("source", {}).get("from", {}).get("what") or {}
        cfg_to_db = {
            meta.get("cfg_key", dc): dc
            for dc, meta in self._categories_meta.items()
        }
        for cfg_key, entry in seed_inputs.items():
            db_cat = cfg_to_db.get(cfg_key)
            if db_cat is None or db_cat not in self._combos:
                continue
            target_id = entry.get("id", "")
            combo = self._combos[db_cat]
            for i in range(combo.count()):
                ds = combo.itemData(i)
                if ds and ds.get("data_table") == target_id:
                    combo.setCurrentIndex(i)
                    if db_cat in self._checks and not self._checks[db_cat].isChecked():
                        self._checks[db_cat].setChecked(True)
                    break
            field_val = entry.get("field", "")
            if field_val and db_cat in self._fields:
                self._load_columns(db_cat)
                col_combo = self._fields[db_cat]
                for i in range(col_combo.count()):
                    if col_combo.itemText(i) == field_val:
                        col_combo.setCurrentIndex(i)
                        break

    # ── Upload click handler ──────────────────────────────────────────────
    def _on_upload_clicked(self, db_cat: str):
        cat_meta       = self._categories_meta.get(db_cat, {})
        cat_label      = cat_meta.get("desc") or db_cat.replace("_", " ").capitalize()
        formats        = cat_meta.get("format", [])
        folder_capable = db_cat in self._folder_categories
        dlg = HrUploadDialog(db_cat, cat_label, _make_client(), formats, self,
                             folder_capable=folder_capable)
        if dlg.exec() == QDialog.Accepted:
            new_table = dlg.uploaded_table()

            prev_checked  = {dc: cb.isChecked() for dc, cb in self._checks.items()}
            prev_datasets = {dc: combo.currentData() for dc, combo in self._combos.items()}
            prev_fields   = {
                dc: self._fields[dc].currentText()
                for dc in self._fields if self._fields[dc].isVisible()
            }

            self.initializePage()

            for dc, combo in self._combos.items():
                saved_ds = prev_datasets.get(dc)
                if saved_ds is None:
                    continue
                saved_table = saved_ds.get("data_table", "")
                for i in range(combo.count()):
                    ds = combo.itemData(i)
                    if ds and ds.get("data_table") == saved_table:
                        combo.setCurrentIndex(i)
                        break

            for dc, checked in prev_checked.items():
                cb = self._checks.get(dc)
                if cb and cb.isEnabled() and cb.isChecked() != checked:
                    cb.setChecked(checked)

            for dc, field_text in prev_fields.items():
                col_combo = self._fields.get(dc)
                if col_combo is None:
                    continue
                for i in range(col_combo.count()):
                    if col_combo.itemText(i) == field_text:
                        col_combo.setCurrentIndex(i)
                        break

            if new_table and db_cat in self._combos:
                combo = self._combos[db_cat]
                for i in range(combo.count()):
                    ds = combo.itemData(i)
                    if ds and ds.get("data_table") == new_table:
                        combo.setCurrentIndex(i)
                        if db_cat in self._checks:
                            self._checks[db_cat].setChecked(True)
                        break
            self._refresh_stats()

    def _refresh_stats(self):
        try:
            stats = _make_client().user_stats()
            self.wizard().page(PAGE_CONNECTION)._last_stats = stats
            uc = stats.get("upload_count", 0) or 0
            ub = stats.get("upload_bytes", 0) or 0
            lu = stats.get("last_upload") or "—"
            self._stats_uploads_lbl.setText(str(uc))
            self._stats_size_lbl.setText(f"{ub / 1024 / 1024:.2f} MB")
            self._stats_last_lbl.setText(lu[:19] if lu != "—" else lu)
            self._stats_group.setVisible(True)
        except Exception:
            pass

    def nextId(self):
        return PAGE_SIM


# HrSimSettingsPage is imported from pages.sim_settings_page


# ─────────────────────────────────────────────────────────────────────────────
# Page 3 — Extent (spatial + temporal)
# ─────────────────────────────────────────────────────────────────────────────

class HrExtentPage(_HrExtentPageBase):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Step 4 — Extent")
        self.setSubTitle(
            "Optionally restrict the simulation to a spatial and/or temporal window."
        )
        self._temporal_prefilled = False  # guard: auto-fill runs once only

    def initializePage(self):
        # Base handles seed pre-fill
        super().initializePage()
        # Infer temporal extent from selected inputs on first visit only.
        # Subsequent visits (Back/Next navigation) must not overwrite manual edits.
        if not self._temporal_prefilled:
            self._prefill_temporal_from_inputs()
            self._temporal_prefilled = True

    def _prefill_temporal_from_inputs(self):
        import json as _json
        from qgis.PyQt.QtCore import QDate, QTime, QDateTime

        data_page = self.wizard().page(PAGE_DATA_INPUTS)
        starts, ends = [], []

        for db_cat, combo in data_page._combos.items():
            cb = data_page._checks.get(db_cat)
            if cb is None or not cb.isChecked():
                continue
            ds = combo.currentData()
            if not ds:
                continue

            # Case 1: dataset has embedded timestamps (raster data)
            raw = ds.get("timestamps")
            if raw:
                try:
                    bands = _json.loads(raw) if isinstance(raw, str) else raw
                except Exception:
                    bands = []
                for band in bands:
                    s = band.get("start", "")
                    e = band.get("end",   "")
                    if s:
                        starts.append(s)
                    if e:
                        ends.append(e)
                continue

            # Case 2: dataset has a timestamps column selected — query API for min/max
            field_combo = data_page._fields.get(db_cat)
            if field_combo is None or not field_combo.isVisible():
                continue
            col = field_combo.currentText().strip()
            if not col or col.startswith("—"):
                continue
            data_table = ds.get("data_table", "")
            if not data_table:
                continue
            try:
                bounds = _make_client().temporal_bounds(data_table, col)
                if bounds.get("start") and bounds.get("end"):
                    starts.append(str(bounds["start"]).replace(" ", "T"))
                    ends.append(str(bounds["end"]).replace(" ", "T"))
            except Exception:
                pass

        if not starts or not ends:
            return

        fmt = "yyyy-MM-ddTHH:mm:ss"
        t_start = QDateTime.fromString(min(starts), fmt)
        t_end   = QDateTime.fromString(max(ends),   fmt)
        if not t_start.isValid() or not t_end.isValid():
            return

        self._temporal_cb.setChecked(True)
        self._date_start.setText(t_start.toString("yyyy-MM-dd"))
        self._time_start.setText(t_start.toString("HH:mm:ss"))
        self._date_end.setText(t_end.toString("yyyy-MM-dd"))
        self._time_end.setText(t_end.toString("HH:mm:ss"))

    def nextId(self):
        return PAGE_SUMMARY


# ─────────────────────────────────────────────────────────────────────────────
# Page 4 — Summary
# ─────────────────────────────────────────────────────────────────────────────

class HrSummaryPage(QWizardPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Step 5 — Summary")
        self.setSubTitle("Review the configuration and click Create job to submit.")
        self._cfg = {}

        layout = QVBoxLayout(self)

        # JSON preview (editable so the user can tweak the config before submitting)
        self._preview = QTextEdit()
        self._preview.setFont(QFont("Courier", 10))
        layout.addWidget(self._preview, 1)

        # Optional local file save — checkbox + path + browse on one row
        self._save_cb = QCheckBox("Save JSON to file:")
        out_row = QHBoxLayout()
        self._out_edit = QLineEdit()
        self._out_edit.setPlaceholderText("/path/to/output/run-xxx_config.json")
        self._out_edit.setEnabled(False)
        browse_btn = QPushButton("📂")
        browse_btn.setFixedWidth(32)
        browse_btn.setToolTip("Choose output file path")
        browse_btn.setEnabled(False)
        browse_btn.clicked.connect(self._browse_output)
        self._save_cb.toggled.connect(self._out_edit.setEnabled)
        self._save_cb.toggled.connect(browse_btn.setEnabled)
        out_row.addWidget(self._save_cb)
        out_row.addWidget(self._out_edit, 1)
        out_row.addWidget(browse_btn)
        layout.addLayout(out_row)

        self._status_lbl = QLabel("")
        layout.addWidget(self._status_lbl)

    def _browse_output(self):
        prefix  = self.wizard().page(PAGE_CONNECTION).job_prefix()
        default = os.path.join(os.path.expanduser("~"), f"{prefix}_config.json")
        path, _ = QFileDialog.getSaveFileName(
            self, "Save configuration file", default,
            "JSON files (*.json);;All files (*)"
        )
        if path:
            self._out_edit.setText(path)

    def initializePage(self):
        prefix = self.wizard().page(PAGE_CONNECTION).job_prefix()
        if not self._out_edit.text().strip():
            self._out_edit.setText(os.path.join(os.path.expanduser("~"), f"{prefix}_config.json"))

        self._cfg = self._build_config()
        self._preview.setPlainText(json.dumps(self._cfg, indent=4, ensure_ascii=False))
        self._status_lbl.setText("")

    def _build_config(self):
        conn_page = self.wizard().page(PAGE_CONNECTION)
        sim_page  = self.wizard().page(PAGE_SIM)
        ext_page  = self.wizard().page(PAGE_EXTENT)
        prefix    = conn_page.job_prefix()
        sim       = sim_page.values()
        inputs    = self.wizard().page(PAGE_DATA_INPUTS).get_inputs()
        spatial   = ext_page.extent_geojson()
        temporal  = ext_page.temporal_extent()

        source_extent = {"temporal": temporal}
        if spatial:
            source_extent["spatial"] = spatial

        return {
            "job": {
                "hash":   prefix,
                "json": {
                    "file":    "config.json",
                    "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                },
                "status": "todo",
                "usr":    conn_page.auth_username() or os.getenv("USER", "user"),
            },
            "source": {
                "extent": source_extent,
                "from": {
                    "db": conn_page.db_connection(),
                    "what": inputs,
                },
            },
            "general": {
                "instr": {
                    "dtype":   sim["precision"],
                    "backend": {"select": "device", "bits": 32, "distributed": False},
                    "time": {
                        "CFL":   0.5,
                        "span":  [0.001, 10.0],
                        "vmax":  20,
                        "adapt": True,
                        "ϵdry":  1e-6,
                    },
                    "plot":   {"cond": False, "what": "hs"},
                    "solver": {
                        "update":  "euler",
                        "rheo":    "newtonian",
                        "riemann": sim["riemann"],
                        "state":   sim["hydrostatic"],
                    },
                    "save": {
                        "cond": True,
                        "what": sim_page.save_what_list(),
                    },
                },
                "param": {"tC": sim["frequency"]},
            },
            "dest": {
                "prefix":  prefix,
                "initial": "input.h5",
                "final":   "output.h5",
            },
            "save": sim_page.build_save_structure(),
        }

    def submit_job(self):
        """POST config to /jobs/submit; optionally save to file. Returns job dict or None."""
        # Parse the (potentially edited) JSON from the preview widget
        try:
            self._cfg = json.loads(self._preview.toPlainText())
        except json.JSONDecodeError as exc:
            self._status_lbl.setText(f"❌  Invalid JSON: {exc}")
            self._status_lbl.setStyleSheet("color: red;")
            return None

        client = _make_client()
        try:
            job_record = client.submit_job(self._cfg)
        except Exception as exc:
            self._status_lbl.setText(f"❌  {exc}")
            self._status_lbl.setStyleSheet("color: red;")
            return None

        if self._save_cb.isChecked():
            path = self._out_edit.text().strip()
            if path:
                os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(self._cfg, f, indent=4, ensure_ascii=False)

        id_hash = job_record.get("id_hash", "?")
        self._status_lbl.setText(f"✅  Job submitted — id: {id_hash}")
        self._status_lbl.setStyleSheet("color: green;")
        return job_record

    def validatePage(self):
        return True

    def nextId(self):
        return -1


# ─────────────────────────────────────────────────────────────────────────────
# Wizard
# ─────────────────────────────────────────────────────────────────────────────

class HrJobWizard(HrBaseWizard):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hydrorisk – Job Manager")
        self.setMinimumSize(QSize(700, 580))
        self.setWizardStyle(QWizard.ModernStyle)

        self.setPage(PAGE_CONNECTION,  HrJobSettingsPage(self))
        self.setPage(PAGE_DATA_INPUTS, HrDataInputsPage(self))
        self.setPage(PAGE_SIM,         HrSimSettingsPage(self, next_page=PAGE_EXTENT))
        self.setPage(PAGE_EXTENT,      HrExtentPage(self))
        self.setPage(PAGE_SUMMARY,     HrSummaryPage(self))

        self.setOption(QWizard.NoDefaultButton, False)
        self.setButtonText(QWizard.FinishButton, "Create job")
        self.button(QWizard.FinishButton).clicked.connect(self._on_finish)

    def seed_config(self) -> dict:
        """Config dict from the selected existing job, or {} for a new job."""
        return self.page(PAGE_CONNECTION).selected_seed()

    def _on_finish(self):
        job_record = self.page(PAGE_SUMMARY).submit_job()
        if job_record:
            from qgis.PyQt.QtWidgets import QMessageBox
            id_hash = job_record.get("id_hash", "?")
            QMessageBox.information(self, "Done", "Job submitted successfully.")

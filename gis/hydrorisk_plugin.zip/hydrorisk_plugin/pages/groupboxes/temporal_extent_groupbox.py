# -*- coding: utf-8 -*-
"""
HrTemporalExtentGroupBox — temporal window selector group box.

Exposes:
    _temporal_cb    QCheckBox
    _date_start     _DatePicker  (.text() / .setText())
    _time_start     QLineEdit    (format: HH:mm:ss)
    _date_end       _DatePicker  (.text() / .setText())
    _time_end       QLineEdit    (format: HH:mm:ss)
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QFormLayout, QCheckBox, QLineEdit,
    QWidget, QHBoxLayout, QPushButton,
    QDialog, QVBoxLayout, QCalendarWidget, QDialogButtonBox,
)
from qgis.PyQt.QtCore import QDate
from datetime import datetime, timedelta, timezone


class _DatePicker(QWidget):
    """QLineEdit + calendar-popup button. Proxies text()/setText()/setEnabled()."""

    def __init__(self, default_text, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        self._edit = QLineEdit(default_text)
        self._edit.setPlaceholderText("yyyy-MM-dd")

        self._btn = QPushButton("📅")
        self._btn.setFixedWidth(28)
        self._btn.setToolTip("Pick a date from calendar")
        self._btn.clicked.connect(self._pick)

        layout.addWidget(self._edit, 1)
        layout.addWidget(self._btn)

    def _pick(self):
        # Parent to the top-level window so the dialog is properly modal
        top = self.window()
        dlg = QDialog(top)
        dlg.setWindowTitle("Pick date")
        vl = QVBoxLayout(dlg)

        cal = QCalendarWidget(dlg)
        current = QDate.fromString(self._edit.text().strip(), "yyyy-MM-dd")
        if current.isValid():
            cal.setSelectedDate(current)
        vl.addWidget(cal)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        vl.addWidget(bb)

        # Read + apply BEFORE the dialog is hidden so cal is still fully alive
        def _apply():
            d = cal.selectedDate()
            if d.isValid():
                self._edit.setText(d.toString("yyyy-MM-dd"))
            dlg.accept()

        bb.accepted.connect(_apply)
        bb.rejected.connect(dlg.reject)
        cal.activated.connect(lambda _d: _apply())   # double-click shortcut

        # Store on self to prevent premature garbage collection
        self._active_dlg = dlg
        dlg.open()   # window-modal, non-blocking — avoids exec() quirks on macOS

    # Proxy interface used by callers
    def text(self):          return self._edit.text()
    def setText(self, v):    self._edit.setText(v)
    def setEnabled(self, v): super().setEnabled(v)   # propagates to children automatically


class HrTemporalExtentGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Temporal extent", parent)
        form = QFormLayout(self)

        now     = datetime.now(timezone.utc)
        end_dt  = now + timedelta(hours=24)

        self._temporal_cb = QCheckBox("Restrict to temporal window")
        self._temporal_cb.setChecked(False)
        form.addRow("Active:", self._temporal_cb)

        self._date_start = _DatePicker(now.strftime("%Y-%m-%d"))
        self._date_start.setEnabled(False)
        form.addRow("Start date:", self._date_start)

        self._time_start = QLineEdit(now.strftime("%H:%M:%S"))
        self._time_start.setPlaceholderText("HH:mm:ss")
        self._time_start.setEnabled(False)
        form.addRow("Start time:", self._time_start)

        self._date_end = _DatePicker(end_dt.strftime("%Y-%m-%d"))
        self._date_end.setEnabled(False)
        form.addRow("End date:", self._date_end)

        self._time_end = QLineEdit(end_dt.strftime("%H:%M:%S"))
        self._time_end.setPlaceholderText("HH:mm:ss")
        self._time_end.setEnabled(False)
        form.addRow("End time:", self._time_end)

        for w in (self._date_start, self._time_start, self._date_end, self._time_end):
            self._temporal_cb.toggled.connect(w.setEnabled)

# -*- coding: utf-8 -*-
"""
HrExistingJobGroupBox — job search/filter + picker + info group box.

Exposes:
    _filter_text    QLineEdit
    _filter_status  QComboBox
    _refresh_btn    QPushButton
    _job_combo      QComboBox
    _info_status    QLabel
    _info_created   QLabel
    _status_lbl     QLabel
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QComboBox,
)
from qgis.PyQt.QtCore import Qt


class HrExistingJobGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Existing job", parent)
        form = QFormLayout(self)

        # ── Filter row ────────────────────────────────────────────────────
        self._filter_text = QLineEdit()
        self._filter_text.setPlaceholderText("Search by prefix or id…")
        self._filter_text.setClearButtonEnabled(True)

        self._filter_status = QComboBox()
        self._filter_status.addItem("All statuses", None)

        self._refresh_btn = QPushButton("🔄")
        self._refresh_btn.setFixedWidth(32)
        self._refresh_btn.setToolTip("Reload jobs list")

        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(0, 0, 0, 0)
        filter_row.addWidget(self._filter_text,   2)
        filter_row.addWidget(self._filter_status, 1)
        filter_row.addWidget(self._refresh_btn)
        form.addRow("Filter:", filter_row)

        # ── Job combo ─────────────────────────────────────────────────────
        self._job_combo = QComboBox()
        form.addRow("Job:", self._job_combo)

        # ── Info labels ───────────────────────────────────────────────────
        self._info_status  = QLabel("—")
        self._info_status.setTextFormat(Qt.RichText)
        self._info_created = QLabel("—")
        for lbl in (self._info_status, self._info_created):
            lbl.setStyleSheet("color: gray;")
        form.addRow("Status:",     self._info_status)
        form.addRow("Created at:", self._info_created)

        self._status_lbl = QLabel("")
        self._status_lbl.setStyleSheet("color: gray;")
        form.addRow(self._status_lbl)

# -*- coding: utf-8 -*-
"""
HrBaseWizard — common QWizard base for all Hydrorisk wizards.
"""
from qgis.PyQt.QtWidgets import QWizard


class HrBaseWizard(QWizard):
    """Thin QWizard subclass shared by all Hydrorisk wizards."""

    def __init__(self, parent=None):
        super().__init__(parent)

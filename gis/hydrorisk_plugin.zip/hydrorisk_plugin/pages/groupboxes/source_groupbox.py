# -*- coding: utf-8 -*-
"""
HrSourceGroupBox — radio selector for input source mode.

Exposes:
    is_api_mode()  → bool   True when "Hydrorisk API" is selected
    mode_changed   Signal   emitted with "api" | "file" when selection changes
"""
from qgis.PyQt.QtWidgets import QGroupBox, QVBoxLayout, QRadioButton, QButtonGroup
from qgis.PyQt.QtCore import pyqtSignal


class HrSourceGroupBox(QGroupBox):
    mode_changed = pyqtSignal(str)   # "api" or "file"

    def __init__(self, parent=None):
        super().__init__("Input source", parent)
        layout = QVBoxLayout(self)

        self._rb_api  = QRadioButton("Hydrorisk API  (fetch datasets from server catalog)")
        self._rb_file = QRadioButton("Local files  (provide paths to input files)")
        self._rb_api.setChecked(True)

        self._btn_group = QButtonGroup(self)
        self._btn_group.addButton(self._rb_api,  0)
        self._btn_group.addButton(self._rb_file, 1)

        layout.addWidget(self._rb_api)
        layout.addWidget(self._rb_file)

        self._rb_api.toggled.connect(
            lambda checked: self.mode_changed.emit("api" if checked else "file")
        )

    def is_api_mode(self) -> bool:
        return self._rb_api.isChecked()

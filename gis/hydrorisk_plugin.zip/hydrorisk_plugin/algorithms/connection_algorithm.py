# -*- coding: utf-8 -*-
"""
Thin QgsProcessingAlgorithm wrapper that opens the global HrConnectionWizard.

After a successful connection the Processing provider is refreshed so that the
other Hydrorisk algorithms become visible in the toolbox.
"""
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingAlgorithm


class HrConnectionAlgorithm(QgsProcessingAlgorithm):
    """Connect to the Hydrorisk server."""

    def tr(self, string):
        return QCoreApplication.translate("Processing", string)

    def createInstance(self):
        return HrConnectionAlgorithm()

    def name(self):
        return "hydrorisk_connect"

    def displayName(self):
        return self.tr("Connect")

    def group(self):
        return self.tr("")

    def groupId(self):
        return ""

    def shortHelpString(self):
        return self.tr(
            "Connect to a running Hydrorisk.jl server instance.\n\n"
            "Enter the API URL and bearer token and click 'Test connection'.\n"
            "Once authenticated, all other Hydrorisk tools become available "
            "in the toolbox.\n\n"
            "Credentials are stored for the current QGIS session so you only "
            "need to connect once."
        )

    def flags(self):
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def initAlgorithm(self, config=None):
        pass

    def processAlgorithm(self, parameters, context, feedback):
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.core import QgsApplication
        from ..wizard.connection_wizard import HrConnectionWizard

        parent = QApplication.activeWindow()
        wizard = HrConnectionWizard(parent)
        wizard.exec_()

        # Refresh the provider so algorithms hidden by FlagHideFromToolbox
        # are re-evaluated and appear (or disappear) in the Processing panel.
        registry = QgsApplication.processingRegistry()
        provider = registry.providerById("hydrorisk")
        if provider:
            provider.refreshAlgorithms()

        return {}

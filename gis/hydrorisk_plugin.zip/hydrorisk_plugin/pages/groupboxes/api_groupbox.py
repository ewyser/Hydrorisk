# -*- coding: utf-8 -*-
"""
HrApiGroupBox — URL + token authentication group box.

Exposes:
    _url_edit         QLineEdit
    _token_edit       QLineEdit
    _token_toggle     QPushButton
    _test_btn         QPushButton
    _test_msg         QLabel   — populated from server result["msg"]
    _test_msg_extra   QLabel   — populated from server result["msg_extra"] (hidden when empty)
    _api_form         QFormLayout   (for subclass row injection)
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton,
)


class HrApiGroupBox(QGroupBox):
    def __init__(self, default_url="http://localhost:8000", default_token="", parent=None):
        super().__init__("Hydrorisk API", parent)
        self._api_form = QFormLayout(self)

        self._url_edit   = QLineEdit(default_url)
        self._token_edit = QLineEdit(default_token)
        self._token_edit.setEchoMode(QLineEdit.Password)
        self._token_edit.setPlaceholderText("Bearer token")

        self._token_toggle = QPushButton("👁")
        self._token_toggle.setFixedWidth(32)
        self._token_toggle.setCheckable(True)
        self._token_toggle.setToolTip("Show / hide token")
        self._token_toggle.toggled.connect(
            lambda on: self._token_edit.setEchoMode(
                QLineEdit.Normal if on else QLineEdit.Password
            )
        )

        token_row = QHBoxLayout()
        token_row.setContentsMargins(0, 0, 0, 0)
        token_row.addWidget(self._token_edit, 1)
        token_row.addWidget(self._token_toggle)

        self._api_form.addRow("Base URL:", self._url_edit)
        self._api_form.addRow("Token:",    token_row)

        test_row = QHBoxLayout()
        self._test_btn = QPushButton("Test connection")
        self._test_msg = QLabel("")
        test_row.addWidget(self._test_btn)
        test_row.addWidget(self._test_msg, 1)
        self._api_form.addRow(test_row)

        self._test_msg_extra = QLabel("")
        self._test_msg_extra.setStyleSheet("color: gray; font-size: 10px;")
        self._api_form.addRow(self._test_msg_extra)

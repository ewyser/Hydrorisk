# -*- coding: utf-8 -*-
from .provider import HydroriskProvider


def classFactory(iface):
    return HydroriskPlugin(iface)


class HydroriskPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = HydroriskProvider()

    def initGui(self):
        from qgis.core import QgsApplication
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        from qgis.core import QgsApplication
        from .pages.connection_page import _remove_qgis_pg_connection
        from .common.connection_store import store as _conn_store
        _remove_qgis_pg_connection()
        _conn_store.pg_user     = ""
        _conn_store.pg_password = ""
        QgsApplication.processingRegistry().removeProvider(self.provider)

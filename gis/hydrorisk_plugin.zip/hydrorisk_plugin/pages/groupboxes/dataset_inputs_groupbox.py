# -*- coding: utf-8 -*-
"""
HrDatasetInputsGroupBox — scrollable dataset-input form group box.

Exposes:
    _status     QLabel          (status / error message)
    _form       QFormLayout     (rows added dynamically by BaseDataInputsPage)
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QVBoxLayout,
    QLabel, QScrollArea, QFormLayout, QWidget,
)


class HrDatasetInputsGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Dataset inputs", parent)
        vbox = QVBoxLayout(self)

        self._status = QLabel("Fetching catalog…")
        vbox.addWidget(self._status)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget()
        self._form = QFormLayout(inner)
        self._form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        scroll.setWidget(inner)
        vbox.addWidget(scroll, 1)

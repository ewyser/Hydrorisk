# -*- coding: utf-8 -*-
"""
ManagerUploadLayerPage — file/layer picker + category upload page for the Dataset Manager.

Also contains _DropFilter, a small QObject event filter that enables drag-and-drop
of file paths and QGIS layer IDs onto an editable QComboBox.
"""
import os

from qgis.PyQt.QtWidgets import (
    QWizard, QWizardPage,
    QVBoxLayout, QFileDialog,
)
from .groupboxes.upload_source_groupbox import HrUploadSourceGroupBox
from .groupboxes.log_groupbox import HrLogGroupBox
from qgis.PyQt.QtCore import Qt, QObject, QEvent, QThread, pyqtSignal
from qgis.core import QgsProject

from ..common.connection_store import make_client as _make_client
from ..common.upload_worker import UploadWorker


# ─────────────────────────────────────────────────────────────────────────────
# Drag-and-drop event filter for an editable QComboBox
# ─────────────────────────────────────────────────────────────────────────────

class _DropFilter(QObject):
    """Intercepts drag/drop events on a QLineEdit and populates a QComboBox."""

    def __init__(self, combo, parent=None):
        super().__init__(parent)
        self._combo = combo

    def eventFilter(self, obj, event):
        if event.type() == QEvent.DragEnter:
            if event.mimeData().hasUrls() or event.mimeData().hasText():
                event.acceptProposedAction()
                return True
        elif event.type() == QEvent.Drop:
            mime = event.mimeData()
            if mime.hasUrls():
                path = mime.urls()[0].toLocalFile()
                if path:
                    self._combo.setEditText(path)
                    event.acceptProposedAction()
                    return True
            if mime.hasText():
                text  = mime.text().strip()
                layer = QgsProject.instance().mapLayer(text)
                if layer:
                    self._combo.setEditText(layer.source().split("|")[0])
                    event.acceptProposedAction()
                    return True
        return super().eventFilter(obj, event)


# ─────────────────────────────────────────────────────────────────────────────
# Page
# ─────────────────────────────────────────────────────────────────────────────

class ManagerUploadLayerPage(QWizardPage):
    """
    File/layer picker and upload page for the Dataset Manager wizard.

    Supports local file browse, QGIS layer dropdown, and drag-and-drop.
    Upload is triggered by the wizard's CustomButton1.

    Constructor arguments
    ---------------------
    next_page : int
        Page ID to go to after this page (-1 = last / finish).
    connection_page : int
        Page ID of the connection page (default 0).
    """

    _log_line_received  = pyqtSignal(str)
    _sse_upload_complete = pyqtSignal()

    def __init__(self, parent=None, next_page=-1, connection_page=0):
        super().__init__(parent)
        self._next_page = next_page
        self.setTitle("Data & Category")
        self.setSubTitle(
            "Pick a loaded QGIS layer from the list, browse for a file, or drag & drop onto the field.\n"
            "The server will handle the import (raster, vector or CSV)."
        )
        self._categories_loaded = False
        self._folder_categories = {}  # {category: [accepted formats]}
        self._last_dir = os.path.expanduser("~")
        self._thread = None
        self._worker = None
        self._sse_thread = None

        layout = QVBoxLayout(self)

        source_group             = HrUploadSourceGroupBox(parent=self)
        self._source_group       = source_group
        self._path_combo         = source_group._path_combo
        self._browse_btn         = source_group._browse_btn
        self._browse_folder_btn  = source_group._browse_folder_btn
        self._refresh_layers_btn = source_group._refresh_layers_btn
        self._category_combo     = source_group._category_combo
        self._fetch_cats_btn     = source_group._fetch_cats_btn
        self._product_combo      = source_group._product_combo
        self._fetch_prods_btn    = source_group._fetch_prods_btn

        # Attach drag-and-drop filter to the editable line edit
        le = self._path_combo.lineEdit()
        self._drop_filter = _DropFilter(self._path_combo, self)
        le.installEventFilter(self._drop_filter)

        self._log_box = HrLogGroupBox(parent=self)
        self._log_box.setVisible(False)

        layout.addWidget(source_group)
        layout.addWidget(self._log_box)
        layout.addStretch()

        self._browse_btn.clicked.connect(self._browse_file)
        self._browse_folder_btn.clicked.connect(self._browse_folder)
        self._refresh_layers_btn.clicked.connect(self._populate_layers)
        self._path_combo.activated.connect(self._layer_selected)
        self._fetch_cats_btn.clicked.connect(self._fetch_categories)
        self._fetch_prods_btn.clicked.connect(self._fetch_categories)
        self._category_combo.currentTextChanged.connect(self._update_folder_availability)
        source_group.source_type_changed.connect(self._on_source_type_changed)
        self._log_line_received.connect(self._append_log_line)
        self._sse_upload_complete.connect(self._on_sse_complete)

    def isComplete(self):
        return True

    def initializePage(self):
        if self._sse_thread is not None:
            self._sse_thread.stop()
            self._sse_thread = None
        self._path_combo.clearEditText()
        self._categories_loaded = False
        self._log_box._log.clear()
        self._log_box.setVisible(False)
        self._populate_layers()
        wiz = self.wizard()
        wiz.button(QWizard.NextButton).setVisible(False)
        wiz.button(QWizard.NextButton).setEnabled(False)
        wiz.button(QWizard.FinishButton).setVisible(False)
        wiz.button(QWizard.FinishButton).setEnabled(False)
        wiz.button(QWizard.CustomButton1).setVisible(True)
        wiz.button(QWizard.CustomButton1).setEnabled(True)
        wiz._set_upload_status("")
        self._fetch_categories()

    def _on_source_type_changed(self, is_folder: bool):
        self._path_combo.clearEditText()
        if not is_folder:
            self._populate_layers()

    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select data file",
            self._last_dir,
            "Spatial files (*.tif *.tiff *.shp *.csv *.gpkg);;All files (*)",
        )
        if path:
            self._last_dir = os.path.dirname(path)
            self._path_combo.setEditText(path)

    def _browse_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select folder to import as multiband raster",
            self._last_dir,
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
        )
        if folder:
            self._last_dir = folder
            self._path_combo.setEditText(folder)

    def _populate_layers(self):
        current_text = self._path_combo.currentText()
        self._path_combo.blockSignals(True)
        self._path_combo.clear()
        self._path_combo.addItem("...", None)
        for layer in QgsProject.instance().mapLayers().values():
            src = layer.source().split("|")[0]
            if os.path.isfile(src):
                self._path_combo.addItem(layer.name(), src)
        self._path_combo.setEditText(current_text)
        self._path_combo.blockSignals(False)

    def _layer_selected(self, index):
        src = self._path_combo.itemData(index)
        if src:
            self._path_combo.setEditText(src)

    def _fetch_categories(self):
        try:
            client   = _make_client()
            cats     = client.db_categories()
            cat_keys = list(cats.keys()) if isinstance(cats, dict) else list(cats)
            self._folder_categories = client.db_folder_categories()  # {cat: [products]}
            self._category_combo.clear()
            for c in cat_keys:
                self._category_combo.addItem(c)
            # populate product combo from all folder-capable products
            all_products = sorted({p for prods in self._folder_categories.values() for p in prods})
            self._product_combo.clear()
            for p in all_products:
                self._product_combo.addItem(p)
            self._categories_loaded = True
            self._update_folder_availability()
        except Exception as exc:
            self._category_combo.clear()
            self._category_combo.addItem(f"Error: {exc}")
            self._product_combo.clear()
            self._folder_categories = {}
            self._source_group.set_folder_available(False)

    def _update_folder_availability(self):
        pass  # folder mode is always available; user selects via radio button

    def file_path(self): return self._path_combo.currentText().strip()
    def category(self):
        if self._source_group.is_folder_mode():
            return self._product_combo.currentText()
        return self._category_combo.currentText()

    def _do_upload(self):
        wiz = self.wizard()
        if not self.file_path():
            wiz._set_upload_status("⚠  Source path is required.", "orange")
            return
        if not self.category() or self.category().startswith("Error:"):
            wiz._set_upload_status("⚠  Valid category is required.", "orange")
            return

        is_folder = self._source_group.is_folder_mode()
        if is_folder and not os.path.isdir(self.file_path()):
            wiz._set_upload_status("⚠  Selected path is not a folder.", "orange")
            return
        if not is_folder and not os.path.isfile(self.file_path()):
            wiz._set_upload_status("⚠  File not found.", "orange")
            return

        upload_btn = wiz.button(QWizard.CustomButton1)
        upload_btn.setEnabled(False)
        wiz._set_upload_status("Uploading…  0%")

        client = _make_client()
        self._thread = QThread()
        self._worker = UploadWorker(
            client, self.file_path(), self.category(), folder_mode=is_folder
        )
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.upload_started.connect(self._on_upload_started)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_upload_done)
        self._worker.error.connect(self._on_upload_error)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._thread.finished.connect(self._worker.deleteLater)
        self._thread.finished.connect(self._thread.deleteLater)
        self._thread.start()

    def _on_upload_started(self, upload_id: str):
        self._log_box.setVisible(True)
        self._log_box._log.clear()
        try:
            client = _make_client()
            self._sse_thread = client.sse_upload_logs(
                upload_id,
                on_event=lambda ev: self._log_line_received.emit(
                    f"[{ev.get('level', 'info').upper()}] {ev.get('msg', '')}"),
                on_done=lambda: (
                    self._log_line_received.emit("[SSE] Stream closed."),
                    self._sse_upload_complete.emit(),
                ),
                on_error=lambda exc: self._log_line_received.emit(f"[SSE ERROR] {exc}"),
            )
        except Exception as exc:
            self._log_line_received.emit(f"[SSE] Could not start log stream: {exc}")

    def _append_log_line(self, line: str):
        self._log_box._log.append(line)
        sb = self._log_box._log.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _on_progress(self, sent, total):
        wiz = self.wizard()
        pct = int(sent * 100 / total) if total else 0
        sent_kb  = sent  // 1024
        total_kb = total // 1024
        label = f"Uploading…  {pct}%  ({sent_kb}/{total_kb} KB)"
        if pct == 100:
            label = "Importing on server…"
        wiz._set_upload_status(label)

    def _on_upload_done(self, result):
        # 202 — server accepted the file; async processing is starting.
        # Keep the SSE thread alive; _on_sse_complete will signal when done.
        wiz = self.wizard()
        wiz._set_upload_status("Importing on server…")
        self._path_combo.clearEditText()

    def _on_sse_complete(self):
        wiz        = self.wizard()
        upload_btn = wiz.button(QWizard.CustomButton1)
        wiz._set_upload_status("✅  Import complete.", "green")
        upload_btn.setEnabled(True)
        self._sse_thread = None

    def _on_upload_error(self, msg):
        wiz        = self.wizard()
        upload_btn = wiz.button(QWizard.CustomButton1)
        wiz._set_upload_status(f"❌  {msg}", "red")
        upload_btn.setEnabled(True)
        if self._sse_thread:
            self._sse_thread.stop()
            self._sse_thread = None

    def validatePage(self):
        return True

    def nextId(self):
        return self._next_page

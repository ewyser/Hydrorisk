# -*- coding: utf-8 -*-
"""
HrJobLaunchGroupBox — job summary + launch button group box.

Exposes:
    _summary_lbl    QLabel
    _launch_btn     QPushButton
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton,
)


class HrJobLaunchGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Job", parent)
        vbox = QVBoxLayout(self)

        btn_row = QHBoxLayout()
        self._launch_btn = QPushButton("▶  Launch")
        self._launch_btn.setFixedHeight(32)
        self._summary_lbl = QLabel("—")
        self._summary_lbl.setStyleSheet("color: gray;")
        btn_row.addWidget(self._launch_btn)
        btn_row.addWidget(self._summary_lbl)
        btn_row.addStretch()
        vbox.addLayout(btn_row)

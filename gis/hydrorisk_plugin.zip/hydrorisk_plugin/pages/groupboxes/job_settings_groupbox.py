# -*- coding: utf-8 -*-
"""
HrJobSettingsGroupBox — run prefix, output folder and export frequency.

Exposes:
    _prefix   QLineEdit
    _folder   QLineEdit
    _freq     QSpinBox
    values()  → {prefix, folder, frequency}
"""
from qgis.PyQt.QtWidgets import (
    QGroupBox, QFormLayout, QHBoxLayout,
    QLineEdit, QPushButton, QSpinBox,
    QFileDialog,
)


class HrJobSettingsGroupBox(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Job settings", parent)
        layout = QFormLayout(self)

        self._prefix = QLineEdit("run-nameoftherun")
        layout.addRow("Run prefix:", self._prefix)

        folder_row = QHBoxLayout()
        folder_row.setContentsMargins(0, 0, 0, 0)
        self._folder = QLineEdit()
        self._folder.setPlaceholderText("Output folder")
        self._browse_btn = QPushButton("📂")
        self._browse_btn.setFixedWidth(32)
        self._browse_btn.setToolTip("Choose output folder")
        self._browse_btn.clicked.connect(self._browse_folder)
        folder_row.addWidget(self._folder, 1)
        folder_row.addWidget(self._browse_btn)
        layout.addRow("Output folder:", folder_row)

        self._freq = QSpinBox()
        self._freq.setRange(1, 999999)
        self._freq.setValue(60)
        self._freq.setSuffix(" s")
        layout.addRow("Export interval (tC):", self._freq)

    def _browse_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select output folder")
        if path:
            self._folder.setText(path)

    def values(self):
        return {
            "prefix":    self._prefix.text().strip(),
            "folder":    self._folder.text().strip(),
            "frequency": self._freq.value(),
        }

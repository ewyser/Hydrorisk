# -*- coding: utf-8 -*-
"""
Module-level singleton that persists API credentials across wizard sessions.

Usage::

    from ..common.connection_store import store as _conn_store
    _conn_store.url   = "http://..."
    _conn_store.token = "abc"
"""


class _ConnectionStore:
    def __init__(self):
        self.url          = ""
        self.token        = ""
        self.username     = ""
        self.badge        = ""   # pre-formatted badge string from /auth
        self.msg_extra    = ""   # upload stats line from /auth
        self.connected_at = None  # datetime of last successful auth
        # Direct PostgreSQL access (per-user PG role returned by /auth)
        self.db_host     = ""
        self.db_port     = 5432
        self.db_name     = ""
        self.pg_user     = ""
        self.pg_password = ""


#: Single shared instance for the entire plugin lifetime.
store = _ConnectionStore()


def make_client():
    """Create a HydroriskClient from the stored session credentials."""
    from .api_client import HydroriskClient
    return HydroriskClient(store.url, store.token)

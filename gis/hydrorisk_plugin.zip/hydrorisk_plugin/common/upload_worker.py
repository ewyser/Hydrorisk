# -*- coding: utf-8 -*-
"""
Shared background upload worker for Hydrorisk wizards.

Both DbManagerWizard and HrJobWizard use the same upload logic; this module
provides a single implementation to avoid duplication.
"""
import uuid
from qgis.PyQt.QtCore import QObject, pyqtSignal


class UploadWorker(QObject):
    """
    Runs a file or folder upload in a background QThread via the Hydrorisk API client.

    Signals
    -------
    upload_started(upload_id)
        Emitted as soon as the upload_id is known, before bytes are sent.
        Use this to start an SSE log stream on /data/upload/{upload_id}/stream.
    progress(bytes_sent, bytes_total)
    finished(result_dict)
    error(error_message)
    """

    upload_started = pyqtSignal(str)
    progress       = pyqtSignal(int, int)
    finished       = pyqtSignal(dict)
    error          = pyqtSignal(str)

    def __init__(self, client, local_path: str, category: str, folder_mode: bool = False):
        super().__init__()
        self._client      = client
        self._local_path  = local_path
        self._category    = category
        self._folder_mode = folder_mode

    def run(self):
        upload_id = str(uuid.uuid4())
        self.upload_started.emit(upload_id)
        try:
            if self._folder_mode:
                result = self._client.upload_folder_content(
                    self._local_path,
                    self._category,
                    progress_cb=lambda sent, total: self.progress.emit(sent, total),
                    upload_id=upload_id,
                )
            else:
                result = self._client.upload_file_content(
                    self._local_path,
                    self._category,
                    progress_cb=lambda sent, total: self.progress.emit(sent, total),
                    upload_id=upload_id,
                )
            self.finished.emit(result)
        except Exception as exc:
            self.error.emit(str(exc))

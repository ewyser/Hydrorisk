# -*- coding: utf-8 -*-
"""
DbManagerWizard — combined browse + upload wizard for Hydrorisk.jl.

Flow:
  Page 0  ManagerConnectionPage  — URL + token → goes directly to Catalog
  Page 1  ManagerUploadLayerPage — server-side file path + category + upload
  Page 2  ManagerCatalogPage     — shows existing datasets; ⬆ Upload / 🗑 Remove buttons
"""
from qgis.PyQt.QtWidgets import (
    QWizard, QWizardPage,
    QVBoxLayout, QPushButton, QFormLayout,
)
from qgis.PyQt.QtCore import Qt, QSize

from ..pages.catalog_page import ManagerCatalogPage
from ..pages.upload_layer_page import ManagerUploadLayerPage
from .base_wizard import HrBaseWizard

# ─────────────────────────────────────────────────────────────────────────────
PAGE_CATALOG = 0
PAGE_LAYER   = 1

# ─────────────────────────────────────────────────────────────────────────────
# Wizard
# ─────────────────────────────────────────────────────────────────────────────


class DbManagerWizard(HrBaseWizard):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hydrorisk – Dataset Manager")
        self.setMinimumSize(680, 520)
        self.setWizardStyle(QWizard.ModernStyle)

        self.setPage(PAGE_CATALOG, ManagerCatalogPage(self, next_page=PAGE_LAYER))
        self.setPage(PAGE_LAYER,   ManagerUploadLayerPage(self, next_page=-1))

        self.setOption(QWizard.HaveCustomButton1, True)
        self.setButtonText(QWizard.CustomButton1, "⬆  Upload")
        self.button(QWizard.CustomButton1).setVisible(False)

        self.setOption(QWizard.HaveCustomButton2, True)
        _status_btn = self.button(QWizard.CustomButton2)
        _status_btn.setFlat(True)
        _status_btn.setFocusPolicy(Qt.NoFocus)
        _status_btn.setVisible(False)

        self.setButtonLayout([
            QWizard.BackButton,
            QWizard.Stretch,
            QWizard.CustomButton2,
            QWizard.CustomButton1,
            QWizard.NextButton,
            QWizard.FinishButton,
            QWizard.CancelButton,
        ])

        self.currentIdChanged.connect(self._update_back_button)
        self.customButtonClicked.connect(self._on_custom_button_clicked)

    def _on_custom_button_clicked(self, which):
        if which == QWizard.CustomButton1 and self.currentId() == PAGE_LAYER:
            self.page(PAGE_LAYER)._do_upload()

    def _set_upload_status(self, text, color=""):
        btn = self.button(QWizard.CustomButton2)
        if text:
            style = f"border: none; background: transparent; padding: 0 8px;"
            if color:
                style += f" color: {color};"
            btn.setStyleSheet(f"QPushButton {{ {style} }}")
            self.setButtonText(QWizard.CustomButton2, text)
            btn.setVisible(True)
        else:
            btn.setVisible(False)

    def _update_back_button(self, page_id):
        if page_id == PAGE_LAYER:
            self.setButtonText(QWizard.BackButton, "Catalog")
            self.button(QWizard.FinishButton).setVisible(False)
            self.button(QWizard.FinishButton).setEnabled(False)
            # CustomButton1 visibility is managed by initializePage
        elif page_id == PAGE_CATALOG:
            self.setButtonText(QWizard.BackButton, "Back")
            self.setButtonText(QWizard.FinishButton, "Finish")
            self.button(QWizard.FinishButton).setVisible(True)
            self.button(QWizard.FinishButton).setEnabled(True)
            self.button(QWizard.NextButton).setVisible(False)
            self.button(QWizard.NextButton).setEnabled(False)
            self.button(QWizard.CustomButton1).setVisible(False)
            self.button(QWizard.CustomButton2).setVisible(False)
        else:
            self.setButtonText(QWizard.BackButton, "Back")
            self.button(QWizard.CustomButton1).setVisible(False)
            self.button(QWizard.CustomButton2).setVisible(False)

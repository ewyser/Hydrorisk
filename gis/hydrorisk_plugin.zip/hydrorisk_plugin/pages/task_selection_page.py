# -*- coding: utf-8 -*-
"""
HrTmTaskSelectionPage — job picker + pipeline stage selector for the Runner wizard.
"""
from qgis.PyQt.QtWidgets import QWizardPage, QVBoxLayout
from qgis.PyQt.QtCore import Qt
from .groupboxes.existing_job_groupbox import HrExistingJobGroupBox
from .groupboxes.pipeline_stages_groupbox import HrPipelineStagesGroupBox
from ..common.connection_store import make_client as _make_client

# ─────────────────────────────────────────────────────────────────────────────
# Page
# ─────────────────────────────────────────────────────────────────────────────

class HrTmTaskSelectionPage(QWizardPage):
    """
    Job-picker and pipeline-stage selector.

    Constructor arguments
    ---------------------
    next_page : int
        Page ID to advance to after this page (-1 = last page).
    """

    def __init__(self, parent=None, next_page=-1):
        super().__init__(parent)
        self._next_page = next_page
        self.setTitle("Job & Pipeline")
        self.setSubTitle("Select a job and choose which workflow tasks to run.")

        self._jobs              = []
        self._filtered          = []
        self._stages            = []
        self._task_icons        = {}
        self._terminal_statuses = set()
        self._active_statuses   = set()
        self._connected         = False

        layout = QVBoxLayout(self)

        # ── Job picker ────────────────────────────────────────────────────
        job_group           = HrExistingJobGroupBox(parent=self)
        self._filter_text   = job_group._filter_text
        self._filter_status = job_group._filter_status
        self._refresh_btn   = job_group._refresh_btn
        self._job_combo     = job_group._job_combo
        self._info_status   = job_group._info_status
        self._info_created  = job_group._info_created
        self._status_lbl    = job_group._status_lbl
        self._refresh_btn.clicked.connect(self._load_jobs)
        self._filter_text.textChanged.connect(self._apply_filters)
        self._filter_status.currentIndexChanged.connect(self._apply_filters)
        layout.addWidget(job_group)

        # ── Pipeline stages ───────────────────────────────────────────────
        self._stages_layout = QVBoxLayout()
        self._stages_layout.setContentsMargins(0, 0, 0, 0)
        self._stages_group  = None
        self._stage_checks  = {}
        self._stage_legend  = None
        self._rebuild_stages_groupbox(self._stages)
        layout.addLayout(self._stages_layout)
        layout.addStretch()

        self._job_combo.currentIndexChanged.connect(self._on_job_changed)

    def _rebuild_stages_groupbox(self, stages: list):
        """(Re)build HrPipelineStagesGroupBox for the given stage list."""
        # Preserve current mode across rebuilds
        was_custom = (
            self._stages_group is not None
            and self._stages_group._mode_custom.isChecked()
        )
        if self._stages_group is not None:
            self._stages_layout.removeWidget(self._stages_group)
            self._stages_group.deleteLater()
        self._stages_group = HrPipelineStagesGroupBox(stages, parent=self)
        self._stage_checks = self._stages_group._stage_checks
        self._stage_legend = self._stages_group._stage_legend
        if was_custom:
            self._stages_group._mode_custom.setChecked(True)
        # Emit completeChanged whenever mode or any checkbox changes
        self._stages_group._mode_full.toggled.connect(self.completeChanged.emit)
        self._stages_group._mode_custom.toggled.connect(self.completeChanged.emit)
        for cb in self._stage_checks.values():
            cb.toggled.connect(self.completeChanged.emit)
        self._stages_layout.addWidget(self._stages_group)

    def _fetch_task_config(self):
        """Fetch stages + status_icons + terminal/active statuses from API."""
        try:
            config     = _make_client().task_config()
            stages     = config.get("stages") or []
            icons_raw  = config.get("status_icons") or {}
            if stages:
                changed = stages != self._stages
                self._stages = stages
                if icons_raw:
                    self._task_icons = {
                        k: (v["icon"], v["color"]) for k, v in icons_raw.items()
                    }
                if changed:
                    self._rebuild_stages_groupbox(self._stages)
            terminal = config.get("terminal_statuses") or []
            active   = config.get("active_statuses")   or []
            if terminal:
                self._terminal_statuses = set(terminal)
            if active:
                self._active_statuses = set(active)
        except Exception:
            pass  # keep current state

    def initializePage(self):
        if not self._connected:
            self.wizard().currentIdChanged.connect(self._on_page_changed)
            self._connected = True
        self._fetch_task_config()
        self._load_jobs()

    def _on_page_changed(self, page_id):
        if self.wizard().currentPage() is self:
            self._fetch_task_config()
            self._load_jobs()

    def _load_jobs(self):
        self._jobs = []
        try:
            self._jobs = _make_client().list_jobs()
        except Exception as exc:
            self._status_lbl.setText(f"❌  Could not load jobs: {exc}")
            self._status_lbl.setStyleSheet("color: red;")
            return

        if not self._jobs:
            self._status_lbl.setText(
                "No jobs available. Use Job Manager to create one first."
            )
            self._status_lbl.setStyleSheet("color: orange;")

        # Rebuild status filter from actual data
        seen = []
        for j in self._jobs:
            s = j.get("status") or ""
            if s and s not in seen:
                seen.append(s)
        self._filter_status.blockSignals(True)
        prev_status = self._filter_status.currentData()
        self._filter_status.clear()
        self._filter_status.addItem("All statuses", None)
        for s in seen:
            self._filter_status.addItem(s, s)
        idx = self._filter_status.findData(prev_status)
        self._filter_status.setCurrentIndex(max(idx, 0))
        self._filter_status.blockSignals(False)

        self._apply_filters()

    def _apply_filters(self):
        text_filter   = self._filter_text.text().strip().lower()
        status_filter = self._filter_status.currentData()

        self._filtered = [
            j for j in self._jobs
            if (not text_filter or
                text_filter in (j.get("prefix") or "").lower() or
                text_filter in (j.get("id_hash") or "").lower())
            and (status_filter is None or j.get("status") == status_filter)
        ]

        self._job_combo.blockSignals(True)
        self._job_combo.clear()
        for j in self._filtered:
            label  = j.get("prefix") or (j.get("id_hash") or "?")[:8]
            status = j.get("status") or ""
            self._job_combo.addItem(f"{label}  [{status}]")
        if not self._filtered:
            self._job_combo.addItem("— no matching jobs —")
        self._job_combo.blockSignals(False)

        total   = len(self._jobs)
        matched = len(self._filtered)
        self._status_lbl.setText(
            f"{matched} of {total} job(s) shown." if self._jobs else "No jobs found."
        )
        self._status_lbl.setStyleSheet("color: gray;" if matched else "color: orange;")

        self._on_job_changed(self._job_combo.currentIndex())
        self.completeChanged.emit()

    def _task_summary(self, tasks: list) -> str:
        """Compact HTML like  ✓ prepare  ⟳ execute  ○ post using live stages/icons."""
        task_status = {t["name"]: t.get("status") for t in (tasks or []) if t.get("name")}
        parts = []
        for name in self._stages:
            ts = task_status.get(name)
            icon, colour = self._task_icons.get(ts or "unknown", self._task_icons.get("unknown", ("?", "gray")))
            parts.append(f"<span style='color:{colour}'>{icon} {name}</span>")
        return "&nbsp;&nbsp;".join(parts)

    def _on_job_changed(self, index):
        if 0 <= index < len(self._filtered):
            j       = self._filtered[index]
            status  = str(j.get("status") or "—")
            created = (j.get("created_at") or "—")[:19]
            colour  = self._task_icons.get(status, self._task_icons.get("unknown", ("?", "gray")))[1]
            summary = self._task_summary(j.get("tasks"))
            self._info_status.setText(
                f"<span style='color:{colour}; font-weight:bold'>{status}</span>"
                f"&nbsp;&nbsp;{summary}"
            )
            self._info_status.setStyleSheet("")
            self._info_created.setText(created)

            task_status = {t["name"]: t.get("status") for t in (j.get("tasks") or []) if t.get("name")}
            for stage, cb in self._stage_checks.items():
                ts = task_status.get(stage)
                c = self._task_icons.get(ts or "unknown", self._task_icons.get("unknown", ("?", "gray")))[1]
                cb.setEnabled(True)
                cb.setStyleSheet(f"color: {c}; font-weight: bold;")
            self._stage_legend.setText("")
        else:
            for lbl in (self._info_status, self._info_created):
                lbl.setText("—")
                lbl.setStyleSheet("color: gray;")
            for cb in self._stage_checks.values():
                cb.setStyleSheet("")
                cb.setEnabled(True)
            self._stage_legend.setText("")
        self.completeChanged.emit()

    def selected_job(self) -> dict:
        idx = self._job_combo.currentIndex()
        if 0 <= idx < len(self._filtered):
            return self._filtered[idx]
        return {}

    def selected_stages(self) -> list:
        if self._stages_group and self._stages_group._mode_full.isChecked():
            return list(self._stages)
        return [s for s, cb in self._stage_checks.items() if cb.isChecked()]

    def isComplete(self):
        if not self._filtered or self._job_combo.currentIndex() < 0:
            return False
        if self._stages_group and self._stages_group._mode_full.isChecked():
            return bool(self._stages)
        return bool(self.selected_stages())

    def nextId(self):
        return self._next_page
